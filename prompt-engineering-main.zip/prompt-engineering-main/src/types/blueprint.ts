/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type RequirementType = 'functional' | 'non-functional' | 'security' | 'integration' | 'data' | 'constraint';
export type RequirementPriority = 'critical' | 'high' | 'medium' | 'low';
export type RequirementSource = 'user_prompt' | 'ai_inferred' | 'clarification' | 'assumption';
export type RequirementStatus = 'approved' | 'draft' | 'needs_review' | 'modified' | 'archived';

export interface Requirement {
  id: string; // e.g. REQ-001
  title: string;
  description: string;
  type: RequirementType;
  priority: RequirementPriority;
  source: RequirementSource;
  confidence: number; // 0.0 to 1.0
  status: RequirementStatus;
  category: string;
  version: number;
  tags?: string[];
}

export interface ClarificationQuestion {
  id: string;
  category: 'role' | 'auth' | 'data_ownership' | 'business_rule' | 'error_handling' | 'security';
  question: string;
  options: string[];
  selectedOption?: string;
  userAnswer?: string;
  assumedDefault: string;
  isSkipped: boolean;
  explanation: string;
}

export interface UserStory {
  id: string; // e.g. US-001
  role: string;
  action: string;
  benefit: string;
  acceptanceCriteria: string[];
  relatedReqIds: string[];
}

export interface SystemModule {
  id: string;
  name: string;
  description: string;
  components: string[];
  relatedReqIds: string[];
}

export interface ArchitectureComponent {
  id: string; // e.g. ARCH-001
  name: string;
  layer: 'frontend' | 'backend' | 'database' | 'auth' | 'external_service' | 'cache';
  description: string;
  technology: string;
  dependencies: string[]; // references ARCH-xxx
  relatedReqIds: string[];
}

export interface ArchitectureDesign {
  summary: string;
  style: string;
  mermaidCode: string;
  components: ArchitectureComponent[];
  dataFlow: {
    from: string;
    to: string;
    description: string;
    protocol: string;
  }[];
}

export interface DatabaseField {
  name: string;
  type: string;
  isPrimary: boolean;
  isForeign: boolean;
  references?: {
    table: string;
    field: string;
  };
  isNullable: boolean;
  isUnique: boolean;
  defaultValue?: string;
  description: string;
}

export interface DatabaseEntity {
  id: string; // e.g. DB-001
  tableName: string;
  description: string;
  fields: DatabaseField[];
  indexes: string[];
  constraints: string[];
  normalizationNotes: string;
  relatedReqIds: string[];
}

export interface DatabaseRelationship {
  fromTable: string;
  fromField: string;
  toTable: string;
  toField: string;
  cardinality: 'one-to-one' | 'one-to-many' | 'many-to-many' | 'many-to-one';
  onDelete: 'CASCADE' | 'SET NULL' | 'RESTRICT' | 'NO ACTION';
}

export interface DatabaseBlueprint {
  entities: DatabaseEntity[];
  relationships: DatabaseRelationship[];
  sqlDdl: string;
  erdMermaid: string;
}

export interface ApiParameter {
  name: string;
  in: 'path' | 'query' | 'header';
  type: string;
  required: boolean;
  description: string;
}

export interface ApiResponse {
  statusCode: number;
  description: string;
  schema?: string;
}

export interface ApiEndpoint {
  id: string; // e.g. API-001
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  summary: string;
  description: string;
  authRequired: boolean;
  rolesAllowed: string[];
  parameters: ApiParameter[];
  requestBodySchema?: string;
  responses: ApiResponse[];
  validationRules: string[];
  errorCases: {
    code: string;
    message: string;
    statusCode: number;
  }[];
  relatedReqIds: string[];
  relatedDbEntityIds: string[];
}

export interface TestCase {
  id: string; // e.g. TEST-001
  title: string;
  type: 'functional' | 'security' | 'boundary' | 'api' | 'db_constraint' | 'integration';
  priority: RequirementPriority;
  preconditions: string[];
  inputData: string;
  steps: string[];
  expectedResult: string;
  executionStatus: 'spec_defined' | 'passed' | 'failed' | 'unexecuted';
  relatedReqIds: string[];
  relatedApiIds: string[];
}

export interface ImplementationTask {
  id: string; // e.g. TASK-001
  title: string;
  phase: 'Setup' | 'Database' | 'Backend' | 'Frontend' | 'Integration' | 'Testing';
  promptInstructions: string;
  acceptanceCriteria: string[];
  relatedReqIds: string[];
}

export interface FullBlueprint {
  id: string;
  projectId: string;
  version: string;
  createdAt: string;
  updatedAt: string;
  overview: {
    title: string;
    description: string;
    scope: string;
    targetAudience: string[];
    keyAssumptions: string[];
  };
  rolesMatrix: {
    role: string;
    description: string;
    permissions: string[];
  }[];
  requirements: Requirement[];
  userStories: UserStory[];
  businessRules: {
    id: string;
    rule: string;
    relatedReqIds: string[];
  }[];
  systemModules: SystemModule[];
  architecture: ArchitectureDesign;
  database: DatabaseBlueprint;
  apiEndpoints: ApiEndpoint[];
  testCases: TestCase[];
  implementationTasks: ImplementationTask[];
  securityRequirements: {
    id: string;
    title: string;
    description: string;
    mitigationStrategy: string;
    relatedReqIds: string[];
  }[];
}

export type TraceNodeType =
  | 'requirement'
  | 'user_story'
  | 'architecture'
  | 'database'
  | 'api'
  | 'test_case'
  | 'task';

export type TraceEdgeType =
  | 'satisfies'
  | 'implemented_by'
  | 'stored_in'
  | 'exposed_through'
  | 'verified_by'
  | 'depends_on';

export interface TraceNode {
  id: string;
  type: TraceNodeType;
  label: string;
  subLabel: string;
  status: string;
  category?: string;
  data: any;
}

export interface TraceEdge {
  id: string;
  source: string;
  target: string;
  type: TraceEdgeType;
  label: string;
}

export interface TraceGraph {
  nodes: TraceNode[];
  edges: TraceEdge[];
}

export interface ValidationFinding {
  id: string;
  ruleId: string;
  category: 'traceability' | 'relational_integrity' | 'api_consistency' | 'test_coverage' | 'syntax' | 'semantic';
  severity: 'critical' | 'error' | 'warning' | 'info';
  title: string;
  description: string;
  affectedNodeIds: string[];
  status: 'passed' | 'failed' | 'needs_review' | 'not_executed';
  suggestedFix?: string;
  ruleDescription?: string;
}

export interface CoverageMetrics {
  totalRequirements: number;
  approvedCount: number;
  draftCount: number;
  specCoveragePercent: number; // Reqs mapped to at least one tech artifact (arch, db, or api)
  testCoveragePercent: number; // Reqs mapped to at least one test case
  apiCoveragePercent: number;
  dbCoveragePercent: number;
  orphanedRequirements: string[]; // Reqs with zero technical links
  untestedRequirements: string[]; // Reqs with zero test cases
  brokenReferences: number;
  inconsistentEndpoints: number;
  rulePassRate: number;
}

export interface ChangeImpactReport {
  changedReqId: string;
  previousVersion: Requirement;
  newVersion: Requirement;
  diffSummary: string;
  blastRadiusScore: number; // 0-100
  directlyAffectedArtifacts: {
    id: string;
    type: TraceNodeType;
    title: string;
    currentStatus: string;
    impactReason: string;
  }[];
  indirectlyAffectedArtifacts: {
    id: string;
    type: TraceNodeType;
    title: string;
    dependencyPath: string[];
  }[];
  suggestedRegressionTests: string[];
  proposedModifications: {
    artifactId: string;
    artifactType: string;
    proposedChange: string;
    confidence: number;
  }[];
  timestamp: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  status: 'draft' | 'discovered' | 'generating' | 'generated' | 'verified' | 'archived';
  currentVersion: string;
  tags: string[];
  clarifications?: ClarificationQuestion[];
  blueprint?: FullBlueprint;
  versions?: {
    version: string;
    createdAt: string;
    commitMessage: string;
    snapshot: FullBlueprint;
  }[];
}

export interface PromptTemplate {
  id: string;
  name: string;
  category: 'discovery' | 'requirements' | 'architecture' | 'database' | 'api' | 'testcase' | 'critique';
  version: string;
  template: string;
  description: string;
}

export interface ResearchExperimentResult {
  datasetName: string;
  datasetDescription: string;
  projectDescription: string;
  baseline: {
    totalRequirements: number;
    specCoveragePercent: number;
    testCoveragePercent: number;
    missingLinkDetectionRecall: number;
    invalidReferenceDetection: number;
    unresolvedInconsistencies: number;
    processingTimeMs: number;
  };
  tracespec: {
    totalRequirements: number;
    specCoveragePercent: number;
    testCoveragePercent: number;
    missingLinkDetectionRecall: number;
    invalidReferenceDetection: number;
    unresolvedInconsistencies: number;
    processingTimeMs: number;
  };
  improvementSummary: string;
}
