/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PromptTemplate } from '../types/blueprint';

export const SYSTEM_PROMPT_TEMPLATES: PromptTemplate[] = [
  {
    id: 'TPL-DISCOVERY-V1',
    name: 'Smart Requirement Discovery & Ambiguity Detector',
    category: 'discovery',
    version: '1.2.0',
    description: 'Analyzes user natural language idea to extract initial scope, detect missing roles, auth, data ownership, and formulate clarification questions.',
    template: `You are an elite Software Requirements Engineer.
Analyze the user's natural language software idea:
"{{USER_PROMPT}}"

Identify:
1. Missing stakeholder roles and permissions.
2. Authentication & authorization assumptions.
3. Data persistence, tenancy, and ownership boundaries.
4. Ambiguous business rules and edge-case exceptions.

Generate 3-5 targeted, actionable clarification questions with multiple-choice choices and recommended defaults.`
  },
  {
    id: 'TPL-REQ-SPEC-V1',
    name: 'Formal Requirement Decomposition & Traceability',
    category: 'requirements',
    version: '2.1.0',
    description: 'Decomposes software scope into formal atomic requirements with IDs (REQ-001...), priority, category, confidence, and user stories.',
    template: `You are a Lead Systems Analyst.
Given the verified project description and clarification answers:
Project: {{PROJECT_TITLE}}
Description: {{PROJECT_DESCRIPTION}}
Clarifications: {{CLARIFICATIONS_JSON}}

Generate:
1. Atomic Functional and Non-Functional Requirements with IDs (REQ-001, REQ-002, etc.).
2. User Stories with Role, Action, Benefit, and Acceptance Criteria.
3. User Roles Matrix with explicit permissions.
4. System Modules.`
  },
  {
    id: 'TPL-ARCH-DESIGN-V1',
    name: 'Modular Architecture & Mermaid Designer',
    category: 'architecture',
    version: '1.5.0',
    description: 'Generates tiered architecture components with explicit dependency links and valid Mermaid flowchart diagram.',
    template: `You are a Principal Software Architect.
Given requirements: {{REQUIREMENTS_JSON}}

Design a clean, modern component architecture:
1. Define architectural layers: Frontend, Backend API, Database, Auth Provider, External Services.
2. Assign IDs (ARCH-001, ARCH-002...) and specify dependencies.
3. Map every component to the related requirement IDs (relatedReqIds).
4. Provide a valid Mermaid flowchart TD diagram showing data flow and protocol.`
  },
  {
    id: 'TPL-DB-SCHEMA-V1',
    name: 'Relational Database Schema & Constraint Generator',
    category: 'database',
    version: '2.0.0',
    description: 'Produces 3NF normalized tables, primary keys, foreign key references, constraints, indexes, and PostgreSQL DDL.',
    template: `You are a Senior Database Architect.
Given requirements: {{REQUIREMENTS_JSON}}

Design a production-grade relational database schema:
1. Entities with unique IDs (DB-001, DB-002...).
2. Fields with exact SQL types, nullability, primary key, and foreign key references.
3. Relational integrity constraints (CASCADE/RESTRICT).
4. SQL DDL code.
5. Entity-Relationship Mermaid diagram.`
  },
  {
    id: 'TPL-API-OPENAPI-V1',
    name: 'RESTful API Specification & OpenAPI Generator',
    category: 'api',
    version: '1.8.0',
    description: 'Defines REST endpoints with methods, query/path parameters, request/response JSON schemas, error codes, and RBAC.',
    template: `You are a Senior Backend API Architect.
Given requirements {{REQUIREMENTS_JSON}} and database entities {{ENTITIES_JSON}}:

Define RESTful endpoints (API-001, API-002...):
1. HTTP method, URL path, auth requirement, allowed roles.
2. Request body JSON schema, parameters.
3. Success (200/201) and error responses (400, 401, 403, 404, 409).
4. Link each endpoint to its supporting REQ-xxx and DB-xxx IDs.`
  },
  {
    id: 'TPL-TEST-MATRIX-V1',
    name: 'Verification Matrix & Test Case Generator',
    category: 'testcase',
    version: '2.2.0',
    description: 'Generates functional, boundary, security, and database constraint test cases tied to requirement IDs.',
    template: `You are a Senior QA Automation Architect.
Given requirements {{REQUIREMENTS_JSON}} and API endpoints {{APIS_JSON}}:

Produce comprehensive test cases (TEST-001, TEST-002...):
1. Category: functional, security, boundary, db_constraint.
2. Preconditions, input test data, step-by-step instructions, expected outcome.
3. Link every test to relatedReqIds and relatedApiIds.`
  },
  {
    id: 'TPL-CRITIQUE-V1',
    name: 'Critique & Requirement-Preservation Checker',
    category: 'critique',
    version: '1.4.0',
    description: 'Evaluates the generated specification against user intent to verify no requirements were dropped or hallucinated.',
    template: `You are an AI Verification & Safety Inspector.
Compare original user prompt: "{{ORIGINAL_PROMPT}}"
Against generated specification: {{SUMMARY_JSON}}

Check for:
1. Dropped user requirements.
2. Unwarranted scope creep.
3. Inconsistencies between API endpoints and database tables.
4. Missing error handling paths.`
  }
];

export class PromptPipelineService {
  /**
   * Returns active prompt templates.
   */
  public static getTemplates(): PromptTemplate[] {
    return SYSTEM_PROMPT_TEMPLATES;
  }

  /**
   * Formats prompt with parameters.
   */
  public static formatPrompt(templateId: string, params: Record<string, string>): string {
    const tpl = SYSTEM_PROMPT_TEMPLATES.find(t => t.id === templateId);
    if (!tpl) return '';
    let rendered = tpl.template;
    for (const [key, val] of Object.entries(params)) {
      rendered = rendered.replace(new RegExp(`{{${key}}}`, 'g'), val);
    }
    return rendered;
  }
}
