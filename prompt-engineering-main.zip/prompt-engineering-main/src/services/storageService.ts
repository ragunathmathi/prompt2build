/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Project, FullBlueprint, Requirement } from '../types/blueprint';
import { SAMPLE_PROJECT_ATTENDANCE } from './sampleProjects';

const STORAGE_KEY = 'prompt2blueprint_projects_v1';
const ACTIVE_PROJECT_ID_KEY = 'prompt2blueprint_active_id';

export class StorageService {
  public static getProjects(): Project[] {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) {
        const initial = [SAMPLE_PROJECT_ATTENDANCE];
        this.saveProjects(initial);
        return initial;
      }
      const parsed: Project[] = JSON.parse(data);
      if (!parsed || parsed.length === 0) {
        const initial = [SAMPLE_PROJECT_ATTENDANCE];
        this.saveProjects(initial);
        return initial;
      }
      return parsed;
    } catch {
      return [SAMPLE_PROJECT_ATTENDANCE];
    }
  }

  public static saveProjects(projects: Project[]): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    } catch (e) {
      console.error('Failed to save projects to storage', e);
    }
  }

  public static getActiveProjectId(): string {
    return localStorage.getItem(ACTIVE_PROJECT_ID_KEY) || SAMPLE_PROJECT_ATTENDANCE.id;
  }

  public static setActiveProjectId(id: string): void {
    localStorage.setItem(ACTIVE_PROJECT_ID_KEY, id);
  }

  public static getProject(id: string): Project | undefined {
    const list = this.getProjects();
    return list.find(p => p.id === id);
  }

  public static saveProject(project: Project): void {
    const list = this.getProjects();
    const idx = list.findIndex(p => p.id === project.id);
    if (idx >= 0) {
      list[idx] = { ...project, updatedAt: new Date().toISOString() };
    } else {
      list.unshift({ ...project, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    }
    this.saveProjects(list);
  }

  public static deleteProject(id: string): void {
    const list = this.getProjects().filter(p => p.id !== id);
    this.saveProjects(list);
  }

  /**
   * Commits a new version snapshot for a project.
   */
  public static createVersionSnapshot(projectId: string, commitMessage: string): Project | undefined {
    const project = this.getProject(projectId);
    if (!project || !project.blueprint) return undefined;

    const currentVer = project.blueprint.version;
    // Increment minor version, e.g., 1.1 -> 1.2
    const parts = currentVer.split('.');
    const nextVer = parts.length === 2 ? `${parts[0]}.${parseInt(parts[1], 10) + 1}` : `${currentVer}.1`;

    const snapshot: FullBlueprint = JSON.parse(JSON.stringify(project.blueprint));
    snapshot.version = nextVer;
    snapshot.updatedAt = new Date().toISOString();

    const versions = project.versions || [];
    versions.unshift({
      version: currentVer,
      createdAt: new Date().toISOString(),
      commitMessage: commitMessage || `Snapshot ${currentVer}`,
      snapshot: JSON.parse(JSON.stringify(project.blueprint))
    });

    project.blueprint = snapshot;
    project.currentVersion = `v${nextVer}`;
    project.versions = versions;
    project.updatedAt = new Date().toISOString();

    this.saveProject(project);
    return project;
  }

  /**
   * Restores a past blueprint version.
   */
  public static restoreVersion(projectId: string, targetVersion: string): Project | undefined {
    const project = this.getProject(projectId);
    if (!project || !project.versions) return undefined;

    const target = project.versions.find(v => v.version === targetVersion);
    if (!target) return undefined;

    // Archive current version into history first
    if (project.blueprint) {
      project.versions.unshift({
        version: project.blueprint.version,
        createdAt: new Date().toISOString(),
        commitMessage: `Auto-saved prior to restoring ${targetVersion}`,
        snapshot: JSON.parse(JSON.stringify(project.blueprint))
      });
    }

    const restoredSnapshot = JSON.parse(JSON.stringify(target.snapshot));
    project.blueprint = restoredSnapshot;
    project.currentVersion = `v${restoredSnapshot.version || '1.0'}`;
    project.updatedAt = new Date().toISOString();

    this.saveProject(project);
    return project;
  }

  /**
   * Updates an individual requirement and triggers version history / status update.
   */
  public static updateRequirement(projectId: string, updatedReq: Requirement): Project | undefined {
    const project = this.getProject(projectId);
    if (!project || !project.blueprint) return undefined;

    const idx = project.blueprint.requirements.findIndex(r => r.id === updatedReq.id);
    if (idx >= 0 && project.blueprint) {
      project.blueprint.requirements[idx] = {
        ...updatedReq,
        version: (project.blueprint.requirements[idx].version || 1) + 1,
        status: updatedReq.status || 'modified'
      };
      project.blueprint.updatedAt = new Date().toISOString();
      this.saveProject(project);
    }
    return project;
  }
}
