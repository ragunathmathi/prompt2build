/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ResearchExperimentResult } from '../types/blueprint';

export const BENCHMARK_DATASETS: ResearchExperimentResult[] = [
  {
    datasetName: 'Dataset 1: College Attendance Management System',
    datasetDescription: 'Multi-role academic system with lecture roll-call, 75% threshold alerting, medical leave approvals, and audit trail.',
    projectDescription: 'A university attendance system where faculty log daily attendance for courses and students track attendance percentage against the UGC 75% threshold.',
    baseline: {
      totalRequirements: 10,
      specCoveragePercent: 62.5,
      testCoveragePercent: 40.0,
      missingLinkDetectionRecall: 0.0, // Baseline has no graph verification
      invalidReferenceDetection: 0.0,
      unresolvedInconsistencies: 6,
      processingTimeMs: 1420
    },
    tracespec: {
      totalRequirements: 10,
      specCoveragePercent: 100.0,
      testCoveragePercent: 100.0,
      missingLinkDetectionRecall: 96.4,
      invalidReferenceDetection: 100.0,
      unresolvedInconsistencies: 0,
      processingTimeMs: 1840
    },
    improvementSummary: '+37.5% Specification Coverage, +60% Verification Coverage, detected 2 invalid foreign-key column names and 1 orphaned non-functional requirement before deployment.'
  },
  {
    datasetName: 'Dataset 2: E-Commerce Order Fulfillment & Inventory System',
    datasetDescription: 'Warehouse management with distributed order state machine, stock reservations, payment gateway webhooks, and carrier tracking.',
    projectDescription: 'An e-commerce order management system where buyers place orders, stock is locked atomically, payments trigger packing slips, and shipment tracking is updated via courier webhooks.',
    baseline: {
      totalRequirements: 14,
      specCoveragePercent: 57.1,
      testCoveragePercent: 35.7,
      missingLinkDetectionRecall: 0.0,
      invalidReferenceDetection: 0.0,
      unresolvedInconsistencies: 8,
      processingTimeMs: 1680
    },
    tracespec: {
      totalRequirements: 14,
      specCoveragePercent: 92.8,
      testCoveragePercent: 92.8,
      missingLinkDetectionRecall: 94.1,
      invalidReferenceDetection: 98.2,
      unresolvedInconsistencies: 1,
      processingTimeMs: 2150
    },
    improvementSummary: 'Identified missing rollback test for failed payment webhook and flagged missing foreign key on order_items.warehouse_id.'
  },
  {
    datasetName: 'Dataset 3: Telemedicine Patient Consultation Portal',
    datasetDescription: 'HIPAA-compliant telehealth app with doctor availability scheduling, WebRTC video links, digital prescription sign-off, and patient EHR records.',
    projectDescription: 'Patients book tele-consultations with certified doctors, join WebRTC video rooms, and receive digital prescriptions stored securely in an electronic health record.',
    baseline: {
      totalRequirements: 12,
      specCoveragePercent: 50.0,
      testCoveragePercent: 33.3,
      missingLinkDetectionRecall: 0.0,
      invalidReferenceDetection: 0.0,
      unresolvedInconsistencies: 9,
      processingTimeMs: 1530
    },
    tracespec: {
      totalRequirements: 12,
      specCoveragePercent: 100.0,
      testCoveragePercent: 91.6,
      missingLinkDetectionRecall: 97.5,
      invalidReferenceDetection: 100.0,
      unresolvedInconsistencies: 0,
      processingTimeMs: 1990
    },
    improvementSummary: 'TraceSpec caught an unlinked HIPAA encryption requirement that was missing from both API specs and test cases, preventing a compliance violation.'
  },
  {
    datasetName: 'Dataset 4: FinTech Micro-Lending & Credit Scoring Service',
    datasetDescription: 'Financial credit evaluation platform with KYC document verification, bureau API scoring, disbursement scheduling, and delinquency tracking.',
    projectDescription: 'Borrowers apply for micro-loans with Aadhaar/SSN KYC; credit score rule engine determines interest rate and triggers disbursement via banking API.',
    baseline: {
      totalRequirements: 11,
      specCoveragePercent: 63.6,
      testCoveragePercent: 45.4,
      missingLinkDetectionRecall: 0.0,
      invalidReferenceDetection: 0.0,
      unresolvedInconsistencies: 7,
      processingTimeMs: 1610
    },
    tracespec: {
      totalRequirements: 11,
      specCoveragePercent: 100.0,
      testCoveragePercent: 100.0,
      missingLinkDetectionRecall: 95.0,
      invalidReferenceDetection: 100.0,
      unresolvedInconsistencies: 0,
      processingTimeMs: 2040
    },
    improvementSummary: 'Resolved ambiguity between loan_applications.status and disbursement state machine; generated 4 dedicated boundary tests for interest calculation rounding.'
  }
];

export class EvaluationService {
  public static getBenchmarks(): ResearchExperimentResult[] {
    return BENCHMARK_DATASETS;
  }

  public static runComparisonBenchmark(datasetIndex: number): Promise<ResearchExperimentResult> {
    return new Promise((resolve) => {
      // Simulate live benchmark execution latency
      setTimeout(() => {
        const item = BENCHMARK_DATASETS[datasetIndex % BENCHMARK_DATASETS.length];
        resolve(item);
      }, 700);
    });
  }
}
