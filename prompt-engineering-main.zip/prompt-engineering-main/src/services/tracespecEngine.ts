/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  FullBlueprint,
  Requirement,
  TraceGraph,
  TraceNode,
  TraceEdge,
  ValidationFinding,
  CoverageMetrics,
  ChangeImpactReport,
  TraceNodeType
} from '../types/blueprint';

/**
 * TraceSpec Engine
 * Core research contribution: Deterministic verification and end-to-end requirement traceability.
 */
export class TraceSpecEngine {
  /**
   * Builds an explicit traceability graph from a software blueprint.
   */
  public static buildGraph(blueprint: FullBlueprint): TraceGraph {
    const nodes: TraceNode[] = [];
    const edges: TraceEdge[] = [];
    const edgeSet = new Set<string>();

    const addEdge = (source: string, target: string, type: TraceEdge['type'], label: string) => {
      const key = `${source}->${target}:${type}`;
      if (!edgeSet.has(key)) {
        edgeSet.add(key);
        edges.push({
          id: `edge-${source}-${target}-${type}`,
          source,
          target,
          type,
          label
        });
      }
    };

    // 1. Requirement Nodes
    for (const req of blueprint.requirements) {
      nodes.push({
        id: req.id,
        type: 'requirement',
        label: req.id,
        subLabel: req.title,
        status: req.status,
        category: req.category,
        data: req
      });
    }

    // 2. User Story Nodes & Edges
    for (const us of blueprint.userStories) {
      nodes.push({
        id: us.id,
        type: 'user_story',
        label: us.id,
        subLabel: `As a ${us.role}`,
        status: 'approved',
        category: us.role,
        data: us
      });

      for (const reqId of us.relatedReqIds || []) {
        addEdge(us.id, reqId, 'satisfies', 'satisfies');
      }
    }

    // 3. Architecture Component Nodes & Edges
    for (const comp of blueprint.architecture.components) {
      nodes.push({
        id: comp.id,
        type: 'architecture',
        label: comp.id,
        subLabel: comp.name,
        status: 'active',
        category: comp.layer,
        data: comp
      });

      for (const reqId of comp.relatedReqIds || []) {
        addEdge(comp.id, reqId, 'implemented_by', 'implements');
      }

      // Architecture-to-architecture dependencies
      for (const depId of comp.dependencies || []) {
        addEdge(comp.id, depId, 'depends_on', 'depends on');
      }
    }

    // 4. Database Entity Nodes & Edges
    for (const entity of blueprint.database.entities) {
      nodes.push({
        id: entity.id,
        type: 'database',
        label: entity.id,
        subLabel: entity.tableName,
        status: 'defined',
        category: 'Relational Entity',
        data: entity
      });

      for (const reqId of entity.relatedReqIds || []) {
        addEdge(entity.id, reqId, 'stored_in', 'stores data for');
      }
    }

    // 5. API Endpoint Nodes & Edges
    for (const api of blueprint.apiEndpoints) {
      nodes.push({
        id: api.id,
        type: 'api',
        label: `${api.method} ${api.path}`,
        subLabel: api.summary,
        status: 'active',
        category: api.method,
        data: api
      });

      for (const reqId of api.relatedReqIds || []) {
        addEdge(api.id, reqId, 'exposed_through', 'exposes');
      }

      for (const dbId of api.relatedDbEntityIds || []) {
        addEdge(api.id, dbId, 'depends_on', 'queries entity');
      }
    }

    // 6. Test Case Nodes & Edges
    for (const test of blueprint.testCases) {
      nodes.push({
        id: test.id,
        type: 'test_case',
        label: test.id,
        subLabel: test.title,
        status: test.executionStatus,
        category: test.type,
        data: test
      });

      for (const reqId of test.relatedReqIds || []) {
        addEdge(test.id, reqId, 'verified_by', 'verifies');
      }

      for (const apiId of test.relatedApiIds || []) {
        addEdge(test.id, apiId, 'verified_by', 'tests endpoint');
      }
    }

    // 7. Implementation Task Nodes & Edges
    for (const task of blueprint.implementationTasks) {
      nodes.push({
        id: task.id,
        type: 'task',
        label: task.id,
        subLabel: task.title,
        status: 'todo',
        category: task.phase,
        data: task
      });

      for (const reqId of task.relatedReqIds || []) {
        addEdge(task.id, reqId, 'implemented_by', 'develops');
      }
    }

    return { nodes, edges };
  }

  /**
   * Deterministic Validation Suite: Executes 10 formal checks without relying solely on LLM.
   */
  public static validateBlueprint(blueprint: FullBlueprint, graph?: TraceGraph): ValidationFinding[] {
    const findings: ValidationFinding[] = [];
    const g = graph || this.buildGraph(blueprint);

    const reqMap = new Map<string, Requirement>();
    blueprint.requirements.forEach(r => reqMap.set(r.id, r));

    const dbMap = new Map<string, string>(); // id -> tableName
    const tableFieldMap = new Map<string, Set<string>>();
    blueprint.database.entities.forEach(e => {
      dbMap.set(e.id, e.tableName);
      const fields = new Set<string>(e.fields.map(f => f.name));
      tableFieldMap.set(e.tableName, fields);
    });

    const archIdSet = new Set(blueprint.architecture.components.map(c => c.id));

    // CHECK 1: Requirement Completeness & Format
    blueprint.requirements.forEach(req => {
      if (!req.title || req.title.trim().length < 5) {
        findings.push({
          id: `FND-REQ-TITLE-${req.id}`,
          ruleId: 'RULE-01',
          category: 'traceability',
          severity: 'error',
          title: `Requirement title too short: ${req.id}`,
          description: `Requirement ${req.id} title "${req.title}" does not meet minimum quality threshold (5+ chars).`,
          affectedNodeIds: [req.id],
          status: 'failed',
          suggestedFix: 'Provide an explicit, testable requirement title.'
        });
      }
      if (!req.description || req.description.trim().length < 15) {
        findings.push({
          id: `FND-REQ-DESC-${req.id}`,
          ruleId: 'RULE-01',
          category: 'traceability',
          severity: 'warning',
          title: `Requirement description underspecified: ${req.id}`,
          description: `Requirement ${req.id} description is vague or short.`,
          affectedNodeIds: [req.id],
          status: 'needs_review',
          suggestedFix: 'Clarify actors, pre-conditions, and expected behavior.'
        });
      }
    });

    // CHECK 2: Duplicate Identifier & Title Collision Detection
    const titleSeen = new Map<string, string>();
    blueprint.requirements.forEach(req => {
      const normalized = req.title.toLowerCase().trim();
      if (titleSeen.has(normalized)) {
        findings.push({
          id: `FND-DUP-${req.id}`,
          ruleId: 'RULE-07',
          category: 'semantic',
          severity: 'warning',
          title: `Potential duplicate requirement detected`,
          description: `${req.id} appears duplicate of ${titleSeen.get(normalized)} ("${req.title}").`,
          affectedNodeIds: [req.id, titleSeen.get(normalized)!],
          status: 'needs_review',
          suggestedFix: 'Merge the duplicate requirements or differentiate their scopes.'
        });
      } else {
        titleSeen.set(normalized, req.id);
      }
    });

    // CHECK 3: Orphaned Requirements (No technical implementation link: arch, db, or api)
    const reqImplementationCount = new Map<string, number>();
    blueprint.requirements.forEach(r => reqImplementationCount.set(r.id, 0));

    g.edges.forEach(e => {
      if (['satisfies', 'implemented_by', 'stored_in', 'exposed_through'].includes(e.type)) {
        if (reqImplementationCount.has(e.target)) {
          reqImplementationCount.set(e.target, (reqImplementationCount.get(e.target) || 0) + 1);
        }
      }
    });

    blueprint.requirements.forEach(req => {
      const count = reqImplementationCount.get(req.id) || 0;
      if (count === 0 && req.type === 'functional') {
        findings.push({
          id: `FND-ORPHAN-${req.id}`,
          ruleId: 'RULE-02',
          category: 'traceability',
          severity: 'critical',
          title: `Orphan Functional Requirement: ${req.id}`,
          description: `Functional requirement ${req.id} has no mapped technical artifact (Architecture, Database entity, or API endpoint).`,
          affectedNodeIds: [req.id],
          status: 'failed',
          suggestedFix: `Generate or link an API endpoint or Database Entity to fulfill ${req.id}.`
        });
      }
    });

    // CHECK 4: Missing Test Coverage (Testable requirements must have at least one test case)
    const reqTestCount = new Map<string, number>();
    blueprint.requirements.forEach(r => reqTestCount.set(r.id, 0));

    blueprint.testCases.forEach(tc => {
      (tc.relatedReqIds || []).forEach(rId => {
        if (reqTestCount.has(rId)) {
          reqTestCount.set(rId, (reqTestCount.get(rId) || 0) + 1);
        }
      });
    });

    blueprint.requirements.forEach(req => {
      const testCount = reqTestCount.get(req.id) || 0;
      if (testCount === 0 && (req.type === 'functional' || req.type === 'security')) {
        findings.push({
          id: `FND-NOTEST-${req.id}`,
          ruleId: 'RULE-03',
          category: 'test_coverage',
          severity: 'error',
          title: `Missing Verification Coverage: ${req.id}`,
          description: `Requirement ${req.id} ("${req.title}") has no corresponding test case in test specification.`,
          affectedNodeIds: [req.id],
          status: 'failed',
          suggestedFix: `Generate unit/API or functional test case targeting requirement ${req.id}.`
        });
      }
    });

    // CHECK 5: Relational Integrity (Foreign Keys must point to existing entities and fields)
    blueprint.database.entities.forEach(entity => {
      entity.fields.forEach(field => {
        if (field.isForeign && field.references) {
          const targetTable = field.references.table;
          const targetField = field.references.field;

          if (!tableFieldMap.has(targetTable)) {
            findings.push({
              id: `FND-FK-TABLE-${entity.tableName}-${field.name}`,
              ruleId: 'RULE-05',
              category: 'relational_integrity',
              severity: 'critical',
              title: `Invalid Foreign Key Target Table in ${entity.tableName}.${field.name}`,
              description: `Foreign key references table "${targetTable}", which does not exist in schema.`,
              affectedNodeIds: [entity.id],
              status: 'failed',
              suggestedFix: `Declare target table "${targetTable}" or fix typo in foreign key reference.`
            });
          } else {
            const fieldsOfTarget = tableFieldMap.get(targetTable)!;
            if (!fieldsOfTarget.has(targetField)) {
              findings.push({
                id: `FND-FK-FIELD-${entity.tableName}-${field.name}`,
                ruleId: 'RULE-05',
                category: 'relational_integrity',
                severity: 'critical',
                title: `Invalid Foreign Key Target Column in ${entity.tableName}.${field.name}`,
                description: `Table "${targetTable}" exists, but column "${targetField}" is missing.`,
                affectedNodeIds: [entity.id],
                status: 'failed',
                suggestedFix: `Ensure column "${targetField}" is defined on table "${targetTable}".`
              });
            }
          }
        }
      });
    });

    // CHECK 6: Database Relationships Integrity
    blueprint.database.relationships.forEach((rel, idx) => {
      if (!tableFieldMap.has(rel.fromTable)) {
        findings.push({
          id: `FND-REL-FROM-${idx}`,
          ruleId: 'RULE-05',
          category: 'relational_integrity',
          severity: 'error',
          title: `Relationship references non-existent origin table: ${rel.fromTable}`,
          description: `Relationship ${rel.fromTable}.${rel.fromField} -> ${rel.toTable}.${rel.toField} origin is missing.`,
          affectedNodeIds: [],
          status: 'failed'
        });
      }
      if (!tableFieldMap.has(rel.toTable)) {
        findings.push({
          id: `FND-REL-TO-${idx}`,
          ruleId: 'RULE-05',
          category: 'relational_integrity',
          severity: 'error',
          title: `Relationship references non-existent target table: ${rel.toTable}`,
          description: `Relationship ${rel.fromTable}.${rel.fromField} -> ${rel.toTable}.${rel.toField} target is missing.`,
          affectedNodeIds: [],
          status: 'failed'
        });
      }
    });

    // CHECK 7: API Reference Validity (Endpoint referencing nonexistent DB entity or Req)
    blueprint.apiEndpoints.forEach(api => {
      // Check invalid req IDs
      (api.relatedReqIds || []).forEach(rId => {
        if (!reqMap.has(rId)) {
          findings.push({
            id: `FND-API-REQ-${api.id}-${rId}`,
            ruleId: 'RULE-04',
            category: 'api_consistency',
            severity: 'error',
            title: `Invalid Requirement Reference in ${api.id}`,
            description: `API endpoint ${api.method} ${api.path} references non-existent requirement ID "${rId}".`,
            affectedNodeIds: [api.id],
            status: 'failed',
            suggestedFix: `Update relatedReqIds to match valid requirements.`
          });
        }
      });

      // Check invalid db entity IDs
      (api.relatedDbEntityIds || []).forEach(dbId => {
        if (!dbMap.has(dbId)) {
          findings.push({
            id: `FND-API-DB-${api.id}-${dbId}`,
            ruleId: 'RULE-04',
            category: 'api_consistency',
            severity: 'warning',
            title: `Invalid Database Reference in ${api.id}`,
            description: `API endpoint ${api.method} ${api.path} references non-existent DB entity ID "${dbId}".`,
            affectedNodeIds: [api.id],
            status: 'needs_review',
            suggestedFix: `Link endpoint to an existing entity or remove reference.`
          });
        }
      });

      // Check for error responses
      if (!api.responses.some(r => r.statusCode >= 400)) {
        findings.push({
          id: `FND-API-ERR-${api.id}`,
          ruleId: 'RULE-08',
          category: 'api_consistency',
          severity: 'warning',
          title: `Missing Client/Server Error Response in ${api.id}`,
          description: `Endpoint ${api.method} ${api.path} does not specify error status codes (e.g. 400, 401, 404, 500).`,
          affectedNodeIds: [api.id],
          status: 'needs_review',
          suggestedFix: 'Add explicit 4xx and 5xx error responses for robustness.'
        });
      }
    });

    // CHECK 8: Architecture Dependency Integrity
    blueprint.architecture.components.forEach(comp => {
      (comp.dependencies || []).forEach(depId => {
        if (!archIdSet.has(depId)) {
          findings.push({
            id: `FND-ARCH-DEP-${comp.id}-${depId}`,
            ruleId: 'RULE-06',
            category: 'syntax',
            severity: 'error',
            title: `Missing Architecture Dependency Target in ${comp.id}`,
            description: `Component ${comp.name} (${comp.id}) specifies dependency on unknown component "${depId}".`,
            affectedNodeIds: [comp.id],
            status: 'failed',
            suggestedFix: `Define component "${depId}" or remove from dependencies.`
          });
        }
      });
    });

    // CHECK 9: Mermaid Syntax Deterministic Check
    const mermaid = blueprint.architecture.mermaidCode || '';
    if (!mermaid.includes('graph ') && !mermaid.includes('flowchart ') && !mermaid.includes('classDiagram') && !mermaid.includes('erDiagram')) {
      findings.push({
        id: `FND-MERMAID-SYNTAX`,
        ruleId: 'RULE-09',
        category: 'syntax',
        severity: 'warning',
        title: 'Unrecognized Mermaid Diagram Declaration',
        description: 'Architecture diagram must begin with graph, flowchart, or classDiagram.',
        affectedNodeIds: [],
        status: 'needs_review',
        suggestedFix: 'Prepend "flowchart TD" or valid Mermaid header.'
      });
    }

    // CHECK 10: Role-Based Access Control Coverage
    const rolesDefined = new Set(blueprint.rolesMatrix.map(r => r.role.toLowerCase()));
    blueprint.apiEndpoints.forEach(api => {
      if (api.authRequired) {
        if (!api.rolesAllowed || api.rolesAllowed.length === 0) {
          findings.push({
            id: `FND-AUTH-NO-ROLE-${api.id}`,
            ruleId: 'RULE-10',
            category: 'api_consistency',
            severity: 'warning',
            title: `Auth required without assigned roles: ${api.id}`,
            description: `Endpoint ${api.method} ${api.path} requires authentication but allows no specific roles.`,
            affectedNodeIds: [api.id],
            status: 'needs_review',
            suggestedFix: `Specify allowed roles such as [${Array.from(rolesDefined).join(', ')}].`
          });
        } else {
          api.rolesAllowed.forEach(role => {
            if (!rolesDefined.has(role.toLowerCase()) && role !== '*' && role !== 'authenticated') {
              findings.push({
                id: `FND-AUTH-UNKNOWN-ROLE-${api.id}-${role}`,
                ruleId: 'RULE-10',
                category: 'api_consistency',
                severity: 'warning',
                title: `Endpoint uses undefined role: "${role}"`,
                description: `Endpoint ${api.id} references role "${role}", not found in Role Matrix.`,
                affectedNodeIds: [api.id],
                status: 'needs_review',
                suggestedFix: `Add "${role}" to the Role Matrix or update endpoint role.`
              });
            }
          });
        }
      }
    });

    return findings;
  }

  /**
   * Computes coverage metrics mathematically from stored graph edges.
   */
  public static computeCoverage(blueprint: FullBlueprint, graph?: TraceGraph): CoverageMetrics {
    const g = graph || this.buildGraph(blueprint);
    const totalRequirements = blueprint.requirements.length;

    if (totalRequirements === 0) {
      return {
        totalRequirements: 0,
        approvedCount: 0,
        draftCount: 0,
        specCoveragePercent: 0,
        testCoveragePercent: 0,
        apiCoveragePercent: 0,
        dbCoveragePercent: 0,
        orphanedRequirements: [],
        untestedRequirements: [],
        brokenReferences: 0,
        inconsistentEndpoints: 0,
        rulePassRate: 100
      };
    }

    const approvedCount = blueprint.requirements.filter(r => r.status === 'approved').length;
    const draftCount = blueprint.requirements.filter(r => r.status === 'draft').length;

    // Track which requirements have tech links
    const reqWithTech = new Set<string>();
    const reqWithTest = new Set<string>();
    const reqWithApi = new Set<string>();
    const reqWithDb = new Set<string>();

    g.edges.forEach(edge => {
      if (['satisfies', 'implemented_by', 'stored_in', 'exposed_through'].includes(edge.type)) {
        reqWithTech.add(edge.target);
      }
      if (edge.type === 'verified_by') {
        reqWithTest.add(edge.target);
      }
      if (edge.type === 'exposed_through') {
        reqWithApi.add(edge.target);
      }
      if (edge.type === 'stored_in') {
        reqWithDb.add(edge.target);
      }
    });

    const orphanedRequirements = blueprint.requirements
      .filter(r => !reqWithTech.has(r.id))
      .map(r => r.id);

    const untestedRequirements = blueprint.requirements
      .filter(r => !reqWithTest.has(r.id))
      .map(r => r.id);

    const findings = this.validateBlueprint(blueprint, g);
    const brokenReferences = findings.filter(f => f.category === 'relational_integrity' && f.status === 'failed').length;
    const inconsistentEndpoints = findings.filter(f => f.category === 'api_consistency' && f.status === 'failed').length;

    const passedChecks = findings.filter(f => f.status === 'passed').length;
    const totalChecks = findings.length || 1;
    const rulePassRate = Math.round(
      ((totalChecks - findings.filter(f => f.severity === 'critical' || f.severity === 'error').length) /
        totalChecks) *
        100
    );

    const specCoveragePercent = Math.min(100, Math.round((reqWithTech.size / totalRequirements) * 100));
    const testCoveragePercent = Math.min(100, Math.round((reqWithTest.size / totalRequirements) * 100));
    const apiCoveragePercent = Math.min(100, Math.round((reqWithApi.size / totalRequirements) * 100));
    const dbCoveragePercent = Math.min(100, Math.round((reqWithDb.size / totalRequirements) * 100));

    return {
      totalRequirements,
      approvedCount,
      draftCount,
      specCoveragePercent,
      testCoveragePercent,
      apiCoveragePercent,
      dbCoveragePercent,
      orphanedRequirements,
      untestedRequirements,
      brokenReferences,
      inconsistentEndpoints,
      rulePassRate: Math.max(0, rulePassRate)
    };
  }

  /**
   * Deterministic Change Impact Analysis (Blast Radius & Revalidation Generator)
   */
  public static analyzeChangeImpact(
    blueprint: FullBlueprint,
    previousReq: Requirement,
    newReq: Requirement
  ): ChangeImpactReport {
    const graph = this.buildGraph(blueprint);

    // Textual & Semantic Diff Summary
    const changes: string[] = [];
    if (previousReq.title !== newReq.title) {
      changes.push(`Title changed from "${previousReq.title}" to "${newReq.title}"`);
    }
    if (previousReq.priority !== newReq.priority) {
      changes.push(`Priority changed from ${previousReq.priority} to ${newReq.priority}`);
    }
    if (previousReq.type !== newReq.type) {
      changes.push(`Requirement type changed from ${previousReq.type} to ${newReq.type}`);
    }
    if (previousReq.description !== newReq.description) {
      changes.push(`Description updated (${previousReq.description.length} chars -> ${newReq.description.length} chars)`);
    }

    const diffSummary = changes.length > 0 ? changes.join('; ') : 'Specification wording or parameters modified.';

    // 1. Direct Forward Traversal: Find artifacts directly connected to this requirement
    const directArtifactsMap = new Map<string, { id: string; type: TraceNodeType; title: string; currentStatus: string; impactReason: string }>();

    graph.edges.forEach(edge => {
      if (edge.target === newReq.id) {
        // e.g. UserStory -> REQ, API -> REQ, Comp -> REQ, Test -> REQ
        const sourceNode = graph.nodes.find(n => n.id === edge.source);
        if (sourceNode) {
          directArtifactsMap.set(sourceNode.id, {
            id: sourceNode.id,
            type: sourceNode.type,
            title: sourceNode.subLabel || sourceNode.label,
            currentStatus: sourceNode.status || 'review_needed',
            impactReason: `Directly satisfies/implements/verifies ${newReq.id} via edge '${edge.type}'.`
          });
        }
      }
    });

    const directlyAffectedArtifacts = Array.from(directArtifactsMap.values());

    // 2. Secondary Traversal: If DB table directly affected, APIs using that DB table are indirectly affected.
    // If API directly affected, tests for that API are indirectly affected.
    const indirectArtifactsMap = new Map<string, { id: string; type: TraceNodeType; title: string; dependencyPath: string[] }>();

    directlyAffectedArtifacts.forEach(direct => {
      if (direct.type === 'database') {
        // Find APIs depending on this database entity
        graph.edges.forEach(e => {
          if (e.target === direct.id && e.type === 'depends_on') {
            const apiNode = graph.nodes.find(n => n.id === e.source);
            if (apiNode && !directArtifactsMap.has(apiNode.id)) {
              indirectArtifactsMap.set(apiNode.id, {
                id: apiNode.id,
                type: apiNode.type,
                title: apiNode.subLabel || apiNode.label,
                dependencyPath: [newReq.id, direct.id, apiNode.id]
              });
            }
          }
        });
      } else if (direct.type === 'api') {
        // Find Tests depending on this API endpoint
        graph.edges.forEach(e => {
          if (e.target === direct.id && e.type === 'verified_by') {
            const testNode = graph.nodes.find(n => n.id === e.source);
            if (testNode && !directArtifactsMap.has(testNode.id)) {
              indirectArtifactsMap.set(testNode.id, {
                id: testNode.id,
                type: testNode.type,
                title: testNode.subLabel || testNode.label,
                dependencyPath: [newReq.id, direct.id, testNode.id]
              });
            }
          }
        });
      }
    });

    const indirectlyAffectedArtifacts = Array.from(indirectArtifactsMap.values());

    // Blast Radius Score Calculation (0-100) based on fan-out
    const fanOut = directlyAffectedArtifacts.length * 12 + indirectlyAffectedArtifacts.length * 8;
    const priorityWeight = newReq.priority === 'critical' ? 25 : newReq.priority === 'high' ? 18 : 10;
    const blastRadiusScore = Math.min(100, Math.max(10, fanOut + priorityWeight));

    // Suggested Regression Tests
    const suggestedRegressionTests: string[] = [];
    blueprint.testCases.forEach(tc => {
      if (
        (tc.relatedReqIds || []).includes(newReq.id) ||
        directlyAffectedArtifacts.some(a => a.id === tc.id) ||
        indirectlyAffectedArtifacts.some(a => a.id === tc.id)
      ) {
        suggestedRegressionTests.push(tc.id);
      }
    });

    // Proposed Technical Modifications
    const proposedModifications: ChangeImpactReport['proposedModifications'] = [];
    directlyAffectedArtifacts.forEach(art => {
      if (art.type === 'api') {
        proposedModifications.push({
          artifactId: art.id,
          artifactType: 'API Endpoint',
          proposedChange: `Review request validation, auth roles, and response status codes to accommodate changes in ${newReq.id}.`,
          confidence: 0.92
        });
      } else if (art.type === 'database') {
        proposedModifications.push({
          artifactId: art.id,
          artifactType: 'Database Entity',
          proposedChange: `Inspect table schema and check constraints for ${art.title} to support updated criteria in ${newReq.id}.`,
          confidence: 0.88
        });
      } else if (art.type === 'test_case') {
        proposedModifications.push({
          artifactId: art.id,
          artifactType: 'Test Case',
          proposedChange: `Re-run assertions and update boundary conditions in ${art.id} to verify ${newReq.id}.`,
          confidence: 0.95
        });
      }
    });

    return {
      changedReqId: newReq.id,
      previousVersion: previousReq,
      newVersion: newReq,
      diffSummary,
      blastRadiusScore,
      directlyAffectedArtifacts,
      indirectlyAffectedArtifacts,
      suggestedRegressionTests,
      proposedModifications,
      timestamp: new Date().toISOString()
    };
  }
}
