/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import JSZip from 'jszip';
import { FullBlueprint, ValidationFinding, CoverageMetrics } from '../types/blueprint';
import { TraceSpecEngine } from './tracespecEngine';

export class ExportService {
  /**
   * Generates comprehensive Markdown document of entire blueprint.
   */
  public static generateMarkdown(blueprint: FullBlueprint): string {
    const lines: string[] = [];

    lines.push(`# ${blueprint.overview.title}`);
    lines.push(`**Version:** ${blueprint.version} | **Generated At:** ${blueprint.createdAt}`);
    lines.push('');
    lines.push('## 1. Project Overview & Scope');
    lines.push(blueprint.overview.description);
    lines.push('');
    lines.push('### Scope');
    lines.push(blueprint.overview.scope);
    lines.push('');
    lines.push('### Target Audience');
    blueprint.overview.targetAudience.forEach(a => lines.push(`- ${a}`));
    lines.push('');
    lines.push('### Key Assumptions');
    blueprint.overview.keyAssumptions.forEach(a => lines.push(`- ${a}`));
    lines.push('');

    lines.push('## 2. User Roles & Permission Matrix');
    lines.push('| Role | Description | Permissions |');
    lines.push('|---|---|---|');
    blueprint.rolesMatrix.forEach(r => {
      lines.push(`| **${r.role}** | ${r.description} | ${r.permissions.join(', ')} |`);
    });
    lines.push('');

    lines.push('## 3. Formal Requirements');
    lines.push('| ID | Title | Type | Priority | Source | Status |');
    lines.push('|---|---|---|---|---|---|');
    blueprint.requirements.forEach(r => {
      lines.push(`| **${r.id}** | ${r.title} | ${r.type} | ${r.priority} | ${r.source} | ${r.status} |`);
    });
    lines.push('');

    lines.push('## 4. User Stories & Acceptance Criteria');
    blueprint.userStories.forEach(us => {
      lines.push(`### ${us.id}: As a ${us.role}`);
      lines.push(`**I want to** ${us.action}`);
      lines.push(`**So that** ${us.benefit}`);
      lines.push(`*Related Requirements:* ${us.relatedReqIds.join(', ')}`);
      lines.push('**Acceptance Criteria:**');
      us.acceptanceCriteria.forEach(ac => lines.push(`- [ ] ${ac}`));
      lines.push('');
    });

    lines.push('## 5. System Architecture');
    lines.push(blueprint.architecture.summary);
    lines.push('');
    lines.push('```mermaid');
    lines.push(blueprint.architecture.mermaidCode);
    lines.push('```');
    lines.push('');

    lines.push('## 6. Database Schema & Entities');
    blueprint.database.entities.forEach(ent => {
      lines.push(`### Table: \`${ent.tableName}\` (${ent.id})`);
      lines.push(ent.description);
      lines.push('| Column | Type | PK | FK | Nullable | Description |');
      lines.push('|---|---|---|---|---|---|');
      ent.fields.forEach(f => {
        lines.push(`| \`${f.name}\` | \`${f.type}\` | ${f.isPrimary ? '✅' : '-'} | ${f.isForeign ? `FK (${f.references?.table}.${f.references?.field})` : '-'} | ${f.isNullable ? 'YES' : 'NO'} | ${f.description} |`);
      });
      lines.push('');
    });

    lines.push('## 7. REST API Endpoints');
    blueprint.apiEndpoints.forEach(api => {
      lines.push(`### \`${api.method} ${api.path}\` (${api.id})`);
      lines.push(api.description);
      lines.push(`- **Auth Required:** ${api.authRequired ? 'Yes' : 'No'} | **Roles:** ${api.rolesAllowed.join(', ')}`);
      lines.push(`- **Related Requirements:** ${api.relatedReqIds.join(', ')}`);
      if (api.requestBodySchema) {
        lines.push('**Request Body:**');
        lines.push('```json');
        lines.push(api.requestBodySchema);
        lines.push('```');
      }
      lines.push('');
    });

    lines.push('## 8. Verification & Test Suite');
    lines.push('| Test ID | Title | Type | Priority | Related Reqs | Expected Result |');
    lines.push('|---|---|---|---|---|---|');
    blueprint.testCases.forEach(tc => {
      lines.push(`| **${tc.id}** | ${tc.title} | ${tc.type} | ${tc.priority} | ${tc.relatedReqIds.join(', ')} | ${tc.expectedResult} |`);
    });
    lines.push('');

    lines.push('## 9. Implementation Tasks & Prompts');
    blueprint.implementationTasks.forEach(task => {
      lines.push(`### ${task.id}: ${task.title} [${task.phase}]`);
      lines.push(`**Prompt Instructions:**`);
      lines.push(`> ${task.promptInstructions}`);
      lines.push(`*Linked Requirements:* ${task.relatedReqIds.join(', ')}`);
      lines.push('');
    });

    return lines.join('\n');
  }

  /**
   * Generates OpenAPI 3.0.0 JSON specification.
   */
  public static generateOpenApiJson(blueprint: FullBlueprint): string {
    const paths: Record<string, any> = {};

    blueprint.apiEndpoints.forEach(api => {
      if (!paths[api.path]) {
        paths[api.path] = {};
      }
      const methodKey = api.method.toLowerCase();
      paths[api.path][methodKey] = {
        summary: api.summary,
        description: `${api.description} (Satisfies: ${api.relatedReqIds.join(', ')})`,
        operationId: api.id,
        security: api.authRequired ? [{ BearerAuth: [] }] : [],
        parameters: (api.parameters || []).map(p => ({
          name: p.name,
          in: p.in,
          required: p.required,
          description: p.description,
          schema: { type: p.type.toLowerCase() }
        })),
        responses: {
          ...api.responses.reduce((acc, curr) => {
            acc[curr.statusCode] = {
              description: curr.description,
              content: curr.schema ? { 'application/json': { example: curr.schema } } : undefined
            };
            return acc;
          }, {} as Record<string, any>)
        }
      };
    });

    const openApiDoc = {
      openapi: '3.0.0',
      info: {
        title: blueprint.overview.title,
        version: blueprint.version,
        description: blueprint.overview.description
      },
      servers: [{ url: 'https://api.example.com/v1', description: 'Production Server' }],
      paths,
      components: {
        securitySchemes: {
          BearerAuth: {
            type: 'http',
            scheme: 'bearer',
            bearerFormat: 'JWT'
          }
        }
      }
    };

    return JSON.stringify(openApiDoc, null, 2);
  }

  /**
   * Generates Requirements CSV.
   */
  public static generateRequirementsCsv(blueprint: FullBlueprint): string {
    const headers = ['ID', 'Title', 'Description', 'Type', 'Priority', 'Source', 'Status', 'Confidence', 'Category'];
    const rows = blueprint.requirements.map(r => [
      `"${r.id}"`,
      `"${r.title.replace(/"/g, '""')}"`,
      `"${r.description.replace(/"/g, '""')}"`,
      `"${r.type}"`,
      `"${r.priority}"`,
      `"${r.source}"`,
      `"${r.status}"`,
      r.confidence,
      `"${r.category}"`
    ]);
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  /**
   * Generates Test Cases CSV.
   */
  public static generateTestCasesCsv(blueprint: FullBlueprint): string {
    const headers = ['Test ID', 'Title', 'Type', 'Priority', 'Status', 'Related Reqs', 'Expected Result'];
    const rows = blueprint.testCases.map(t => [
      `"${t.id}"`,
      `"${t.title.replace(/"/g, '""')}"`,
      `"${t.type}"`,
      `"${t.priority}"`,
      `"${t.executionStatus}"`,
      `"${t.relatedReqIds.join(';')}"`,
      `"${t.expectedResult.replace(/"/g, '""')}"`
    ]);
    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  /**
   * Generates 2D Traceability Matrix as CSV.
   */
  public static generateTraceMatrixCsv(blueprint: FullBlueprint): string {
    const headers = ['Requirement ID', 'Requirement Title', 'User Stories', 'Architecture Components', 'Database Entities', 'API Endpoints', 'Test Cases', 'Spec Covered', 'Test Covered'];

    const graph = TraceSpecEngine.buildGraph(blueprint);

    const rows = blueprint.requirements.map(req => {
      const stories: string[] = [];
      const archs: string[] = [];
      const dbs: string[] = [];
      const apis: string[] = [];
      const tests: string[] = [];

      graph.edges.forEach(e => {
        if (e.target === req.id) {
          if (e.source.startsWith('US-')) stories.push(e.source);
          if (e.source.startsWith('ARCH-')) archs.push(e.source);
          if (e.source.startsWith('DB-')) dbs.push(e.source);
          if (e.source.startsWith('API-')) apis.push(e.source);
          if (e.source.startsWith('TEST-')) tests.push(e.source);
        }
      });

      const isSpecCovered = archs.length > 0 || dbs.length > 0 || apis.length > 0 ? 'YES' : 'NO';
      const isTestCovered = tests.length > 0 ? 'YES' : 'NO';

      return [
        `"${req.id}"`,
        `"${req.title.replace(/"/g, '""')}"`,
        `"${stories.join(';')}"`,
        `"${archs.join(';')}"`,
        `"${dbs.join(';')}"`,
        `"${apis.join(';')}"`,
        `"${tests.join(';')}"`,
        `"${isSpecCovered}"`,
        `"${isTestCovered}"`
      ];
    });

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  /**
   * Generates Full ZIP Package with all artifact files.
   */
  public static async generateZipPackage(
    blueprint: FullBlueprint,
    findings: ValidationFinding[],
    metrics: CoverageMetrics
  ): Promise<Blob> {
    const zip = new JSZip();

    // 1. Root Readme and Complete Blueprint
    zip.file('README.md', `# ${blueprint.overview.title}\n\nGenerated with Prompt2Blueprint & TraceSpec Engine.\n\nVersion: ${blueprint.version}\nSpecification Coverage: ${metrics.specCoveragePercent}%\nTest Coverage: ${metrics.testCoveragePercent}%`);
    zip.file('specification/BLUEPRINT.md', this.generateMarkdown(blueprint));
    zip.file('specification/blueprint.json', JSON.stringify(blueprint, null, 2));

    // 2. Requirements folder
    zip.file('requirements/requirements.csv', this.generateRequirementsCsv(blueprint));
    zip.file('requirements/requirements.json', JSON.stringify(blueprint.requirements, null, 2));

    // 3. Architecture folder
    zip.file('architecture/system_architecture.mmd', blueprint.architecture.mermaidCode);
    zip.file('architecture/components.json', JSON.stringify(blueprint.architecture.components, null, 2));

    // 4. Database folder
    zip.file('database/schema.sql', blueprint.database.sqlDdl);
    zip.file('database/erd.mmd', blueprint.database.erdMermaid);
    zip.file('database/entities.json', JSON.stringify(blueprint.database.entities, null, 2));

    // 5. API folder
    zip.file('api/openapi.json', this.generateOpenApiJson(blueprint));
    zip.file('api/endpoints.json', JSON.stringify(blueprint.apiEndpoints, null, 2));

    // 6. Test Suite folder
    zip.file('testing/test_cases.csv', this.generateTestCasesCsv(blueprint));
    zip.file('testing/test_cases.json', JSON.stringify(blueprint.testCases, null, 2));

    // 7. Traceability folder
    zip.file('traceability/traceability_matrix.csv', this.generateTraceMatrixCsv(blueprint));
    zip.file('traceability/validation_report.json', JSON.stringify({ metrics, findings }, null, 2));

    return await zip.generateAsync({ type: 'blob' });
  }

  /**
   * Helper to trigger client-side file download.
   */
  public static downloadFile(filename: string, content: string | Blob, contentType: string = 'text/plain') {
    const blob = typeof content === 'string' ? new Blob([content], { type: contentType }) : content;
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }
}
