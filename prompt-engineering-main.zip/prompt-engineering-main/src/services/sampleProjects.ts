/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Project, FullBlueprint } from '../types/blueprint';

export const SAMPLE_PROJECT_ATTENDANCE: Project = {
  id: 'proj-college-attendance-01',
  name: 'College Attendance Management System',
  description: 'Create a college attendance management system where teachers mark attendance for course sections, and students view their daily attendance and cumulative percentage with threshold warnings.',
  createdAt: '2026-10-25T10:00:00.000Z',
  updatedAt: '2026-10-27T14:30:00.000Z',
  status: 'verified',
  currentVersion: 'v1.1',
  tags: ['Academic', 'Higher Education', 'Attendance', 'RBAC', 'PostgreSQL'],
  clarifications: [
    {
      id: 'CLAR-01',
      category: 'role',
      question: 'What user roles exist beyond Teacher and Student?',
      options: ['Teacher and Student only', 'Teacher, Student, Academic Advisor, and Department Head', 'Campus SuperAdmin only'],
      selectedOption: 'Teacher, Student, Academic Advisor, and Department Head',
      assumedDefault: 'Teacher, Student, Academic Advisor, and Department Head',
      isSkipped: false,
      explanation: 'Academic advisors require read access to track students dropping below the 75% minimum threshold.'
    },
    {
      id: 'CLAR-02',
      category: 'business_rule',
      question: 'What is the minimum mandatory attendance threshold and what happens if a student falls below it?',
      options: ['75% mandatory threshold with automated warnings', '80% threshold with exam debarment', '60% lenient threshold'],
      selectedOption: '75% mandatory threshold with automated warnings',
      assumedDefault: '75% mandatory threshold with automated warnings',
      isSkipped: false,
      explanation: 'UGC standard requires 75% attendance to qualify for semester final examinations.'
    },
    {
      id: 'CLAR-03',
      category: 'auth',
      question: 'How should users authenticate to the attendance portal?',
      options: ['College Institutional SSO (OAuth2 / Google Workspace / SAML)', 'Email and Password with JWT', 'Biometric / QR Code terminal integration'],
      selectedOption: 'Email and Password with JWT + Institutional Google SSO option',
      assumedDefault: 'Email and Password with JWT + Institutional Google SSO option',
      isSkipped: false,
      explanation: 'Provides immediate local testing while allowing standard OAuth institutional delegation.'
    }
  ],
  blueprint: {
    id: 'bp-attendance-v1',
    projectId: 'proj-college-attendance-01',
    version: '1.1',
    createdAt: '2026-10-25T10:15:00.000Z',
    updatedAt: '2026-10-27T14:30:00.000Z',
    overview: {
      title: 'College Attendance Management System (EduAttend)',
      description: 'A verified, role-governed web application enabling university instructors to log daily lecture attendance and students to monitor their percentage, shortfall metrics, and formal leave requests.',
      scope: 'Covers teacher lecture session creation, student attendance logging (Present, Absent, Late, Excused), cumulative percentage calculation, automated notification for <75% attendance, medical excuse submissions, and administrative compliance exports.',
      targetAudience: ['Course Instructors', 'Enrolled Undergraduate & Postgraduate Students', 'Academic Advisors / Mentors', 'Department Heads (HODs)'],
      keyAssumptions: [
        'Semesters consist of approximately 60-75 working days per course.',
        'Excused absences with verified medical certificates do not count negatively towards the denominator.',
        'Teachers can amend attendance records within 48 hours before session locking.'
      ]
    },
    rolesMatrix: [
      {
        role: 'Faculty Instructor',
        description: 'Teaches assigned courses and logs session attendance',
        permissions: ['create:attendance_session', 'update:attendance_records', 'read:course_roster', 'export:attendance_sheet']
      },
      {
        role: 'Student',
        description: 'Attends lectures and checks attendance percentage',
        permissions: ['read:own_attendance', 'submit:leave_request', 'read:own_notifications']
      },
      {
        role: 'Academic Advisor',
        description: 'Monitors cohort attendance and counsels at-risk students',
        permissions: ['read:mentee_attendance', 'read:defaulter_reports', 'export:summary']
      },
      {
        role: 'Department Head',
        description: 'Oversees departmental compliance and approves lock overrides',
        permissions: ['read:department_analytics', 'override:session_lock', 'manage:courses']
      }
    ],
    requirements: [
      {
        id: 'REQ-001',
        title: 'Institutional Role-Based Authentication',
        description: 'System must authenticate users with encrypted credentials or Google Workspace SSO and assign appropriate roles (Student, Faculty, Advisor, Admin).',
        type: 'functional',
        priority: 'critical',
        source: 'user_prompt',
        confidence: 0.98,
        status: 'approved',
        category: 'Authentication',
        version: 1
      },
      {
        id: 'REQ-002',
        title: 'Course and Section Roster Management',
        description: 'Instructors must be able to view their assigned course sections, lecture schedules, and active student enrollments.',
        type: 'functional',
        priority: 'high',
        source: 'user_prompt',
        confidence: 0.95,
        status: 'approved',
        category: 'Course Administration',
        version: 1
      },
      {
        id: 'REQ-003',
        title: 'Daily Lecture Attendance Recording',
        description: 'Instructors must record student attendance status (Present, Absent, Late, Excused) for any scheduled lecture slot with one-click bulk marking.',
        type: 'functional',
        priority: 'critical',
        source: 'user_prompt',
        confidence: 1.0,
        status: 'approved',
        category: 'Attendance Engine',
        version: 1
      },
      {
        id: 'REQ-004',
        title: 'Real-Time Percentage and Shortfall Computation',
        description: 'System must calculate the cumulative attendance percentage for each enrolled course in real time using the verified formula: (P + (Late * 0.5)) / Total Held Sessions * 100.',
        type: 'functional',
        priority: 'critical',
        source: 'user_prompt',
        confidence: 1.0,
        status: 'approved',
        category: 'Analytics',
        version: 1
      },
      {
        id: 'REQ-005',
        title: 'Low Attendance Threshold Warning System',
        description: 'When a student attendance percentage drops below 75%, system must generate an automated alert to the student and their assigned academic advisor.',
        type: 'functional',
        priority: 'high',
        source: 'clarification',
        confidence: 0.92,
        status: 'approved',
        category: 'Notifications',
        version: 1
      },
      {
        id: 'REQ-006',
        title: 'Medical Leave and Official Absence Request Workflow',
        description: 'Students must be able to upload medical proof for prolonged absences, which instructors can approve to convert Absent to Excused.',
        type: 'functional',
        priority: 'medium',
        source: 'ai_inferred',
        confidence: 0.88,
        status: 'approved',
        category: 'Workflow',
        version: 1
      },
      {
        id: 'REQ-007',
        title: 'Attendance Audit Trail & Immutable Revision Logging',
        description: 'Any modification to previously saved attendance records must record instructor ID, timestamp, prior value, and reason in an audit log.',
        type: 'security',
        priority: 'high',
        source: 'ai_inferred',
        confidence: 0.91,
        status: 'approved',
        category: 'Compliance & Audit',
        version: 1
      },
      {
        id: 'REQ-008',
        title: 'Export Official Attendance Registers',
        description: 'Instructors and administrative staff must be able to export standardized semester attendance sheets as CSV and PDF files.',
        type: 'functional',
        priority: 'medium',
        source: 'clarification',
        confidence: 0.94,
        status: 'approved',
        category: 'Reporting',
        version: 1
      },
      {
        id: 'REQ-009',
        title: 'Sub-Second Cumulative Query Performance',
        description: 'The attendance summary endpoint must respond in under 300ms for cohorts of up to 1,000 students via indexed queries and caching.',
        type: 'non-functional',
        priority: 'high',
        source: 'ai_inferred',
        confidence: 0.89,
        status: 'approved',
        category: 'Performance',
        version: 1
      },
      {
        id: 'REQ-010',
        title: 'Student Data Privacy and FERPA Compliance',
        description: 'Students may only inspect their own attendance records and cannot view personal attendance or medical documents of other classmates.',
        type: 'security',
        priority: 'critical',
        source: 'ai_inferred',
        confidence: 0.97,
        status: 'approved',
        category: 'Security',
        version: 1
      }
    ],
    userStories: [
      {
        id: 'US-001',
        role: 'Faculty Instructor',
        action: 'open my scheduled class roster and quickly toggle student statuses with a default "Mark All Present" button',
        benefit: 'I can complete daily roll call in under 45 seconds without disrupting teaching time',
        acceptanceCriteria: [
          'Roster loads with all enrolled students sorted alphabetically',
          'Default status can be set to Present with one click',
          'Absent, Late, and Excused status pills are clearly distinguishable',
          'Submitting persists records and shows confirmation toast'
        ],
        relatedReqIds: ['REQ-002', 'REQ-003']
      },
      {
        id: 'US-002',
        role: 'College Student',
        action: 'log in to my personal dashboard to check my overall and course-by-course attendance percentage',
        benefit: 'I know exactly how many lectures I can safely miss or how many I must attend to reach the 75% quota',
        acceptanceCriteria: [
          'Displays overall attendance % with visual progress bar',
          'Colors progress bar red if <75%, yellow if 75-80%, green if >80%',
          'Calculates "bunk calculator": exact lectures needed to reach 75%'
        ],
        relatedReqIds: ['REQ-004', 'REQ-005', 'REQ-010']
      },
      {
        id: 'US-003',
        role: 'Academic Advisor',
        action: 'generate a real-time list of all mentee students currently below 75% attendance',
        benefit: 'I can intervene with academic counseling before the semester debarment cutoff',
        acceptanceCriteria: [
          'Filter by department, year, and course section',
          'Export defaulter report to CSV',
          'Direct email trigger button to notify student and parents'
        ],
        relatedReqIds: ['REQ-005', 'REQ-008']
      },
      {
        id: 'US-004',
        role: 'Faculty Instructor',
        action: 'review and approve medical leave requests submitted by students',
        benefit: 'The system automatically updates previous absent records to excused upon approval',
        acceptanceCriteria: [
          'Shows student medical certificate attachment',
          'Date range matches missed lectures',
          'Recalculates attendance immediately upon approval'
        ],
        relatedReqIds: ['REQ-006', 'REQ-007']
      }
    ],
    businessRules: [
      {
        id: 'BR-001',
        rule: 'Attendance percentage formula: (Total Present Sessions + (Total Late Sessions * 0.5)) / (Total Held Sessions - Total Excused Sessions) * 100.',
        relatedReqIds: ['REQ-004', 'REQ-006']
      },
      {
        id: 'BR-002',
        rule: 'Attendance sessions older than 48 hours are locked against teacher editing unless approved by Department Head.',
        relatedReqIds: ['REQ-003', 'REQ-007']
      },
      {
        id: 'BR-003',
        rule: 'Students with attendance strictly below 75.0% at the end of the term are barred from sitting for final semester theory exams.',
        relatedReqIds: ['REQ-005']
      }
    ],
    systemModules: [
      {
        id: 'MOD-01',
        name: 'Authentication & Profile Module',
        description: 'Manages user credentials, role mapping, JWT lifecycle, and department affiliation.',
        components: ['Auth Service', 'User Store', 'Session Guard'],
        relatedReqIds: ['REQ-001', 'REQ-010']
      },
      {
        id: 'MOD-02',
        name: 'Course & Roster Engine',
        description: 'Maintains university academic terms, courses, faculty allocations, and section enrollments.',
        components: ['Course Service', 'Enrollment DB', 'Roster Cache'],
        relatedReqIds: ['REQ-002']
      },
      {
        id: 'MOD-03',
        name: 'Attendance Ledger & Calculation Module',
        description: 'Records daily sessions, status transactions, mathematical roll-up calculation, and audit trail.',
        components: ['Session Handler', 'Ledger Service', 'Attendance DB', 'Audit Logger'],
        relatedReqIds: ['REQ-003', 'REQ-004', 'REQ-007', 'REQ-009']
      },
      {
        id: 'MOD-04',
        name: 'Defaulter Alert & Leave Workflow',
        description: 'Monitors 75% threshold breaches and manages student medical certificate approvals.',
        components: ['Notification Service', 'Leave Processor'],
        relatedReqIds: ['REQ-005', 'REQ-006', 'REQ-008']
      }
    ],
    architecture: {
      summary: 'Three-tier cloud-native architecture featuring a reactive SPA frontend, stateless REST API backend with rate-limiting, relational PostgreSQL with ACID guarantees, and background worker for asynchronous notification dispatch.',
      style: 'Layered Micro-modular REST Architecture',
      mermaidCode: `flowchart TD
  subgraph Client_Layer ["Client Tier"]
    SPA["React SPA (Tailwind CSS)"]
    Mobile["Mobile Browser Client"]
  end

  subgraph API_Gateway ["API & Gateway Tier"]
    Nginx["Reverse Proxy / NGINX"]
    AuthGuard["JWT & RBAC Middleware"]
    API["FastAPI / Express Server"]
  end

  subgraph Service_Domain ["Business Domain Services"]
    RosterSvc["Roster Service (ARCH-001)"]
    AttendanceSvc["Attendance Engine (ARCH-002)"]
    AnalyticsSvc["Computation Worker (ARCH-003)"]
    LeaveSvc["Leave Workflow Svc (ARCH-004)"]
  end

  subgraph Data_Storage ["Persistence & Cache Tier"]
    Postgres[(PostgreSQL 16 DB)]
    AuditTable[(Audit Log Store)]
    RedisCache[(Redis Query Cache)]
  end

  SPA --> Nginx
  Mobile --> Nginx
  Nginx --> AuthGuard
  AuthGuard --> API
  API --> RosterSvc
  API --> AttendanceSvc
  API --> AnalyticsSvc
  API --> LeaveSvc

  AttendanceSvc --> Postgres
  AttendanceSvc --> AuditTable
  AnalyticsSvc --> RedisCache
  AnalyticsSvc --> Postgres
  RosterSvc --> Postgres`,
      components: [
        {
          id: 'ARCH-001',
          name: 'Roster & Course Catalog Service',
          layer: 'backend',
          description: 'Manages student course allocations, faculty section assignments, and semester calendars.',
          technology: 'TypeScript / Node.js Express',
          dependencies: ['ARCH-005'],
          relatedReqIds: ['REQ-002']
        },
        {
          id: 'ARCH-002',
          name: 'Attendance Ledger Core Service',
          layer: 'backend',
          description: 'Processes bulk session roll-calls, verifies lock constraints, and records transactional states.',
          technology: 'Node.js Express / PostgreSQL ACID',
          dependencies: ['ARCH-005', 'ARCH-007'],
          relatedReqIds: ['REQ-003', 'REQ-007']
        },
        {
          id: 'ARCH-003',
          name: 'Attendance Analytics & Threshold Worker',
          layer: 'backend',
          description: 'Computes cumulative percentages, forecasts lectures needed to restore 75%, and triggers notifications.',
          technology: 'Node.js Async Worker',
          dependencies: ['ARCH-005', 'ARCH-006'],
          relatedReqIds: ['REQ-004', 'REQ-005', 'REQ-009']
        },
        {
          id: 'ARCH-004',
          name: 'Medical Leave Request Processor',
          layer: 'backend',
          description: 'Handles student absence documentation uploads and updates past records upon instructor sign-off.',
          technology: 'Node.js S3/Local Storage + DB',
          dependencies: ['ARCH-002', 'ARCH-005'],
          relatedReqIds: ['REQ-006']
        },
        {
          id: 'ARCH-005',
          name: 'Primary PostgreSQL Database',
          layer: 'database',
          description: 'Relational database housing user accounts, course sections, attendance transactions, and enrollments.',
          technology: 'PostgreSQL 16',
          dependencies: [],
          relatedReqIds: ['REQ-001', 'REQ-002', 'REQ-003', 'REQ-004']
        },
        {
          id: 'ARCH-006',
          name: 'Redis In-Memory Cache',
          layer: 'cache',
          description: 'Caches calculated student percentage summaries for instant dashboard loads.',
          technology: 'Redis 7',
          dependencies: [],
          relatedReqIds: ['REQ-009']
        },
        {
          id: 'ARCH-007',
          name: 'Audit Log Append-Only Store',
          layer: 'database',
          description: 'Immutable storage for changes to attendance records ensuring regulatory compliance.',
          technology: 'PostgreSQL Partitioned Table',
          dependencies: [],
          relatedReqIds: ['REQ-007', 'REQ-010']
        }
      ],
      dataFlow: [
        {
          from: 'Client SPA',
          to: 'API Gateway',
          description: 'User submits credentials or attendance roll call',
          protocol: 'HTTPS / JSON'
        },
        {
          from: 'Attendance Core',
          to: 'PostgreSQL DB',
          description: 'Inserts batch attendance records inside single transaction',
          protocol: 'TCP / SQL Connection Pool'
        },
        {
          from: 'Computation Worker',
          to: 'Redis Cache',
          description: 'Invalidates & writes updated course attendance percentage',
          protocol: 'RESP'
        }
      ]
    },
    database: {
      entities: [
        {
          id: 'DB-001',
          tableName: 'users',
          description: 'Represents institutional users including faculty, students, and advisors.',
          fields: [
            { name: 'id', type: 'UUID', isPrimary: true, isForeign: false, isNullable: false, isUnique: true, description: 'Primary user UUID' },
            { name: 'email', type: 'VARCHAR(255)', isPrimary: false, isForeign: false, isNullable: false, isUnique: true, description: 'Institutional email address' },
            { name: 'password_hash', type: 'VARCHAR(255)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Bcrypt hashed password' },
            { name: 'full_name', type: 'VARCHAR(150)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'User official legal name' },
            { name: 'role', type: 'VARCHAR(50)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: "'student'", description: 'User role: student, faculty, advisor, admin' },
            { name: 'department', type: 'VARCHAR(100)', isPrimary: false, isForeign: false, isNullable: true, isUnique: false, description: 'Academic department' },
            { name: 'created_at', type: 'TIMESTAMPTZ', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: 'NOW()', description: 'Account creation time' }
          ],
          indexes: ['CREATE UNIQUE INDEX idx_users_email ON users(email);', 'CREATE INDEX idx_users_role ON users(role);'],
          constraints: ["CHECK (role IN ('student', 'faculty', 'advisor', 'admin'))"],
          normalizationNotes: '3NF compliant. Personal and authentication details separated from academic enrollment.',
          relatedReqIds: ['REQ-001', 'REQ-010']
        },
        {
          id: 'DB-002',
          tableName: 'courses',
          description: 'Catalog of courses offered in current academic terms.',
          fields: [
            { name: 'id', type: 'UUID', isPrimary: true, isForeign: false, isNullable: false, isUnique: true, description: 'Course unique ID' },
            { name: 'course_code', type: 'VARCHAR(20)', isPrimary: false, isForeign: false, isNullable: false, isUnique: true, description: 'Catalog code e.g. CS301' },
            { name: 'title', type: 'VARCHAR(200)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Course course title' },
            { name: 'instructor_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'users', field: 'id' }, isNullable: false, isUnique: false, description: 'FK referencing assigned faculty' },
            { name: 'semester', type: 'VARCHAR(20)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Semester e.g. Fall 2026' },
            { name: 'min_attendance_threshold', type: 'DECIMAL(5,2)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: '75.00', description: 'Minimum required percentage' }
          ],
          indexes: ['CREATE INDEX idx_courses_instructor ON courses(instructor_id);'],
          constraints: ['FOREIGN KEY (instructor_id) REFERENCES users(id) ON DELETE RESTRICT'],
          normalizationNotes: 'Relates instructor to academic catalog.',
          relatedReqIds: ['REQ-002', 'REQ-005']
        },
        {
          id: 'DB-003',
          tableName: 'enrollments',
          description: 'Maps student users to their enrolled course sections.',
          fields: [
            { name: 'id', type: 'UUID', isPrimary: true, isForeign: false, isNullable: false, isUnique: true, description: 'Enrollment record ID' },
            { name: 'student_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'users', field: 'id' }, isNullable: false, isUnique: false, description: 'FK referencing student user' },
            { name: 'course_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'courses', field: 'id' }, isNullable: false, isUnique: false, description: 'FK referencing course' },
            { name: 'enrolled_at', type: 'TIMESTAMPTZ', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: 'NOW()', description: 'Enrollment timestamp' }
          ],
          indexes: ['CREATE UNIQUE INDEX idx_enrollment_student_course ON enrollments(student_id, course_id);'],
          constraints: [
            'FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE',
            'FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE'
          ],
          normalizationNotes: 'Associative junction entity implementing many-to-many relationship.',
          relatedReqIds: ['REQ-002']
        },
        {
          id: 'DB-004',
          tableName: 'attendance_sessions',
          description: 'Represents a single held lecture slot for a course.',
          fields: [
            { name: 'id', type: 'UUID', isPrimary: true, isForeign: false, isNullable: false, isUnique: true, description: 'Session primary key' },
            { name: 'course_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'courses', field: 'id' }, isNullable: false, isUnique: false, description: 'Course for which lecture was conducted' },
            { name: 'session_date', type: 'DATE', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Date lecture occurred' },
            { name: 'slot_name', type: 'VARCHAR(50)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'e.g. Period 2 (10:00 - 11:00 AM)' },
            { name: 'topic_taught', type: 'VARCHAR(255)', isPrimary: false, isForeign: false, isNullable: true, isUnique: false, description: 'Syllabus chapter or topic' },
            { name: 'is_locked', type: 'BOOLEAN', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: 'FALSE', description: 'Locked after 48h window' },
            { name: 'created_at', type: 'TIMESTAMPTZ', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: 'NOW()', description: 'Creation timestamp' }
          ],
          indexes: ['CREATE INDEX idx_sessions_course_date ON attendance_sessions(course_id, session_date);'],
          constraints: ['FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE'],
          normalizationNotes: 'Decouples lecture event metadata from individual student roll call entries.',
          relatedReqIds: ['REQ-003']
        },
        {
          id: 'DB-005',
          tableName: 'attendance_records',
          description: 'Individual student attendance status for a given session.',
          fields: [
            { name: 'id', type: 'UUID', isPrimary: true, isForeign: false, isNullable: false, isUnique: true, description: 'Unique attendance record ID' },
            { name: 'session_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'attendance_sessions', field: 'id' }, isNullable: false, isUnique: false, description: 'FK referencing lecture session' },
            { name: 'student_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'users', field: 'id' }, isNullable: false, isUnique: false, description: 'FK referencing student user' },
            { name: 'status', type: 'VARCHAR(20)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: "'present'", description: 'present, absent, late, excused' },
            { name: 'remarks', type: 'VARCHAR(255)', isPrimary: false, isForeign: false, isNullable: true, isUnique: false, description: 'Optional faculty note' },
            { name: 'recorded_at', type: 'TIMESTAMPTZ', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: 'NOW()', description: 'Time marked' }
          ],
          indexes: [
            'CREATE UNIQUE INDEX idx_record_session_student ON attendance_records(session_id, student_id);',
            'CREATE INDEX idx_record_student ON attendance_records(student_id);'
          ],
          constraints: [
            'FOREIGN KEY (session_id) REFERENCES attendance_sessions(id) ON DELETE CASCADE',
            'FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE',
            "CHECK (status IN ('present', 'absent', 'late', 'excused'))"
          ],
          normalizationNotes: 'High-frequency transaction table with composite uniqueness constraint.',
          relatedReqIds: ['REQ-003', 'REQ-004']
        },
        {
          id: 'DB-006',
          tableName: 'leave_requests',
          description: 'Student medical and official absence excuse applications.',
          fields: [
            { name: 'id', type: 'UUID', isPrimary: true, isForeign: false, isNullable: false, isUnique: true, description: 'Leave application ID' },
            { name: 'student_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'users', field: 'id' }, isNullable: false, isUnique: false, description: 'Applicant student ID' },
            { name: 'course_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'courses', field: 'id' }, isNullable: false, isUnique: false, description: 'Associated course' },
            { name: 'start_date', type: 'DATE', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Absence start date' },
            { name: 'end_date', type: 'DATE', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Absence end date' },
            { name: 'reason', type: 'TEXT', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Explanation / Medical diagnosis' },
            { name: 'certificate_url', type: 'VARCHAR(500)', isPrimary: false, isForeign: false, isNullable: true, isUnique: false, description: 'Uploaded doctor certificate' },
            { name: 'status', type: 'VARCHAR(30)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: "'pending'", description: 'pending, approved, rejected' }
          ],
          indexes: ['CREATE INDEX idx_leave_student ON leave_requests(student_id);'],
          constraints: [
            'FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE',
            'FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE',
            "CHECK (status IN ('pending', 'approved', 'rejected'))"
          ],
          normalizationNotes: 'Tracks leave approval lifecycle.',
          relatedReqIds: ['REQ-006']
        },
        {
          id: 'DB-007',
          tableName: 'attendance_audit_logs',
          description: 'Immutable regulatory audit record for any modification of past attendance.',
          fields: [
            { name: 'id', type: 'UUID', isPrimary: true, isForeign: false, isNullable: false, isUnique: true, description: 'Audit log entry ID' },
            { name: 'record_id', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'attendance_records', field: 'id' }, isNullable: false, isUnique: false, description: 'Target attendance record' },
            { name: 'modified_by', type: 'UUID', isPrimary: false, isForeign: true, references: { table: 'users', field: 'id' }, isNullable: false, isUnique: false, description: 'User ID of modifier' },
            { name: 'old_status', type: 'VARCHAR(20)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Status before change' },
            { name: 'new_status', type: 'VARCHAR(20)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Status after change' },
            { name: 'change_reason', type: 'VARCHAR(255)', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, description: 'Justification for update' },
            { name: 'created_at', type: 'TIMESTAMPTZ', isPrimary: false, isForeign: false, isNullable: false, isUnique: false, defaultValue: 'NOW()', description: 'Exact audit timestamp' }
          ],
          indexes: ['CREATE INDEX idx_audit_record ON attendance_audit_logs(record_id);'],
          constraints: [
            'FOREIGN KEY (record_id) REFERENCES attendance_records(id) ON DELETE CASCADE',
            'FOREIGN KEY (modified_by) REFERENCES users(id) ON DELETE RESTRICT'
          ],
          normalizationNotes: 'Append-only historical ledger.',
          relatedReqIds: ['REQ-007']
        }
      ],
      relationships: [
        { fromTable: 'courses', fromField: 'instructor_id', toTable: 'users', toField: 'id', cardinality: 'many-to-one', onDelete: 'RESTRICT' },
        { fromTable: 'enrollments', fromField: 'student_id', toTable: 'users', toField: 'id', cardinality: 'many-to-one', onDelete: 'CASCADE' },
        { fromTable: 'enrollments', fromField: 'course_id', toTable: 'courses', toField: 'id', cardinality: 'many-to-one', onDelete: 'CASCADE' },
        { fromTable: 'attendance_sessions', fromField: 'course_id', toTable: 'courses', toField: 'id', cardinality: 'many-to-one', onDelete: 'CASCADE' },
        { fromTable: 'attendance_records', fromField: 'session_id', toTable: 'attendance_sessions', toField: 'id', cardinality: 'many-to-one', onDelete: 'CASCADE' },
        { fromTable: 'attendance_records', fromField: 'student_id', toTable: 'users', toField: 'id', cardinality: 'many-to-one', onDelete: 'CASCADE' },
        { fromTable: 'leave_requests', fromField: 'student_id', toTable: 'users', toField: 'id', cardinality: 'many-to-one', onDelete: 'CASCADE' },
        { fromTable: 'attendance_audit_logs', fromField: 'record_id', toTable: 'attendance_records', toField: 'id', cardinality: 'many-to-one', onDelete: 'CASCADE' }
      ],
      sqlDdl: `-- EduAttend Production PostgreSQL DDL
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'faculty', 'advisor', 'admin')),
  department VARCHAR(100),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  course_code VARCHAR(20) UNIQUE NOT NULL,
  title VARCHAR(200) NOT NULL,
  instructor_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  semester VARCHAR(20) NOT NULL,
  min_attendance_threshold DECIMAL(5,2) NOT NULL DEFAULT 75.00
);

CREATE TABLE enrollments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  enrolled_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_enrollment UNIQUE (student_id, course_id)
);

CREATE TABLE attendance_sessions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  session_date DATE NOT NULL,
  slot_name VARCHAR(50) NOT NULL,
  topic_taught VARCHAR(255),
  is_locked BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE attendance_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  session_id UUID NOT NULL REFERENCES attendance_sessions(id) ON DELETE CASCADE,
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status VARCHAR(20) NOT NULL DEFAULT 'present' CHECK (status IN ('present', 'absent', 'late', 'excused')),
  remarks VARCHAR(255),
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT uq_session_student UNIQUE (session_id, student_id)
);

CREATE TABLE leave_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  student_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id UUID NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  reason TEXT NOT NULL,
  certificate_url VARCHAR(500),
  status VARCHAR(30) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected'))
);

CREATE TABLE attendance_audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  record_id UUID NOT NULL REFERENCES attendance_records(id) ON DELETE CASCADE,
  modified_by UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  old_status VARCHAR(20) NOT NULL,
  new_status VARCHAR(20) NOT NULL,
  change_reason VARCHAR(255) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);`,
      erdMermaid: `erDiagram
  users ||--o{ courses : "instructs"
  users ||--o{ enrollments : "attends"
  courses ||--o{ enrollments : "enrolled_in"
  courses ||--o{ attendance_sessions : "holds"
  attendance_sessions ||--|{ attendance_records : "contains"
  users ||--o{ attendance_records : "recorded_for"
  users ||--o{ leave_requests : "submits"
  courses ||--o{ leave_requests : "applies_to"
  attendance_records ||--o{ attendance_audit_logs : "audited_by"`
    },
    apiEndpoints: [
      {
        id: 'API-001',
        method: 'POST',
        path: '/api/v1/auth/login',
        summary: 'Authenticate User and Return JWT',
        description: 'Validates institutional credentials and returns access token with role claims.',
        authRequired: false,
        rolesAllowed: ['*'],
        parameters: [],
        requestBodySchema: '{\n  "email": "faculty@college.edu",\n  "password": "SecurePassword123!"\n}',
        responses: [
          { statusCode: 200, description: 'Authentication successful, JWT bearer returned', schema: '{"accessToken": "string", "user": {"id": "UUID", "role": "faculty"}}' },
          { statusCode: 401, description: 'Invalid email or password' }
        ],
        validationRules: ['email must be valid RFC 5322 format', 'password must not be empty'],
        errorCases: [
          { code: 'AUTH_INVALID_CREDENTIALS', message: 'The username or password provided is incorrect.', statusCode: 401 }
        ],
        relatedReqIds: ['REQ-001'],
        relatedDbEntityIds: ['DB-001']
      },
      {
        id: 'API-002',
        method: 'GET',
        path: '/api/v1/courses/my-classes',
        summary: 'List Instructor Assigned Courses',
        description: 'Returns list of course sections taught by the authenticated faculty member.',
        authRequired: true,
        rolesAllowed: ['faculty', 'admin'],
        parameters: [],
        responses: [
          { statusCode: 200, description: 'List of assigned courses with student headcounts', schema: '[{"id": "UUID", "courseCode": "CS301", "title": "Data Structures", "enrolledCount": 42}]' },
          { statusCode: 401, description: 'Missing or expired Bearer token' }
        ],
        validationRules: ['JWT token must belong to faculty role'],
        errorCases: [
          { code: 'AUTH_UNAUTHORIZED', message: 'Authentication token missing or invalid.', statusCode: 401 }
        ],
        relatedReqIds: ['REQ-002'],
        relatedDbEntityIds: ['DB-002']
      },
      {
        id: 'API-003',
        method: 'POST',
        path: '/api/v1/attendance/sessions',
        summary: 'Create Lecture Attendance Session',
        description: 'Creates a new lecture slot for a course and initializes draft attendance records for all enrolled students.',
        authRequired: true,
        rolesAllowed: ['faculty'],
        parameters: [],
        requestBodySchema: '{\n  "courseId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",\n  "sessionDate": "2026-10-28",\n  "slotName": "Period 2 (10:00 - 11:00 AM)",\n  "topicTaught": "Binary Search Trees"\n}',
        responses: [
          { statusCode: 201, description: 'Session created successfully', schema: '{"sessionId": "UUID", "createdCount": 42}' },
          { statusCode: 400, description: 'Session already exists for this slot and course' },
          { statusCode: 403, description: 'Instructor does not teach this course' }
        ],
        validationRules: ['courseId must exist', 'sessionDate must not be in future', 'slotName required'],
        errorCases: [
          { code: 'SESSION_DUPLICATE', message: 'An attendance session for this slot and date already exists.', statusCode: 400 },
          { code: 'FORBIDDEN_COURSE_ACCESS', message: 'You are not assigned to instruct this course.', statusCode: 403 }
        ],
        relatedReqIds: ['REQ-003'],
        relatedDbEntityIds: ['DB-004']
      },
      {
        id: 'API-004',
        method: 'POST',
        path: '/api/v1/attendance/records/batch',
        summary: 'Batch Save Student Roll Call',
        description: 'Saves or updates attendance records for an entire class roster in a single atomic transaction.',
        authRequired: true,
        rolesAllowed: ['faculty'],
        parameters: [],
        requestBodySchema: '{\n  "sessionId": "UUID",\n  "records": [\n    {"studentId": "UUID", "status": "present"},\n    {"studentId": "UUID", "status": "absent", "remarks": "Unexcused"}\n  ]\n}',
        responses: [
          { statusCode: 200, description: 'All records persisted and cumulative metrics refreshed', schema: '{"updatedCount": 42, "status": "success"}' },
          { statusCode: 400, description: 'Invalid student ID or session is locked' },
          { statusCode: 403, description: 'Unauthorized' }
        ],
        validationRules: ['session must not be locked (>48h)', 'records array must contain valid students'],
        errorCases: [
          { code: 'SESSION_LOCKED', message: 'This attendance session has been locked and cannot be edited.', statusCode: 400 }
        ],
        relatedReqIds: ['REQ-003', 'REQ-007'],
        relatedDbEntityIds: ['DB-005', 'DB-007']
      },
      {
        id: 'API-005',
        method: 'GET',
        path: '/api/v1/attendance/student/summary',
        summary: 'Get Student Attendance Percentage & Shortfall',
        description: 'Calculates overall attendance, individual course percentages, and lectures needed to maintain 75% threshold.',
        authRequired: true,
        rolesAllowed: ['student', 'advisor', 'faculty'],
        parameters: [
          { name: 'studentId', in: 'query', type: 'UUID', required: false, description: 'Optional student UUID if requested by advisor' }
        ],
        responses: [
          {
            statusCode: 200,
            description: 'Calculated attendance percentages and threshold warning indicators',
            schema: '{\n  "studentId": "UUID",\n  "overallPercentage": 82.4,\n  "courses": [\n    {\n      "courseCode": "CS301",\n      "title": "Data Structures",\n      "totalHeld": 25,\n      "present": 21,\n      "absent": 3,\n      "late": 1,\n      "excused": 0,\n      "percentage": 86.0,\n      "isBelowThreshold": false,\n      "lecturesNeededFor75": 0\n    }\n  ]\n}'
          },
          { statusCode: 403, description: 'Students cannot view other students records' }
        ],
        validationRules: ['student can only query their own ID unless caller is advisor or faculty'],
        errorCases: [
          { code: 'ACCESS_DENIED_FERPA', message: 'You do not have permission to view this student attendance.', statusCode: 403 }
        ],
        relatedReqIds: ['REQ-004', 'REQ-005', 'REQ-009', 'REQ-010'],
        relatedDbEntityIds: ['DB-005', 'DB-002']
      },
      {
        id: 'API-006',
        method: 'GET',
        path: '/api/v1/reports/low-attendance',
        summary: 'Generate Defaulter Report (<75%)',
        description: 'Retrieves all students within a department or course whose attendance has dropped below 75%.',
        authRequired: true,
        rolesAllowed: ['advisor', 'faculty', 'admin'],
        parameters: [
          { name: 'courseId', in: 'query', type: 'UUID', required: false, description: 'Filter by specific course' },
          { name: 'format', in: 'query', type: 'string', required: false, description: 'json or csv' }
        ],
        responses: [
          { statusCode: 200, description: 'List of at-risk students with percentage and shortfall', schema: '[{"studentName": "Alex Chen", "rollNumber": "CS202304", "courseCode": "CS301", "percentage": 68.0, "shortfall": 3}]' },
          { statusCode: 403, description: 'Forbidden for student role' }
        ],
        validationRules: ['Requires advisor or higher privilege'],
        errorCases: [
          { code: 'FORBIDDEN_ROLE', message: 'Only advisors and faculty can view aggregate defaulter reports.', statusCode: 403 }
        ],
        relatedReqIds: ['REQ-005', 'REQ-008'],
        relatedDbEntityIds: ['DB-005']
      },
      {
        id: 'API-007',
        method: 'POST',
        path: '/api/v1/leave-requests',
        summary: 'Submit Medical or Official Leave Request',
        description: 'Enables students to submit doctor certificates or excuse letters for missed lectures.',
        authRequired: true,
        rolesAllowed: ['student'],
        parameters: [],
        requestBodySchema: '{\n  "courseId": "UUID",\n  "startDate": "2026-10-20",\n  "endDate": "2026-10-22",\n  "reason": "Severe viral fever with hospitalization",\n  "certificateUrl": "https://cdn.college.edu/certs/doc123.pdf"\n}',
        responses: [
          { statusCode: 201, description: 'Leave request lodged and pending instructor review', schema: '{"leaveId": "UUID", "status": "pending"}' },
          { statusCode: 400, description: 'Invalid date range or missing reason' }
        ],
        validationRules: ['startDate <= endDate', 'reason minimum 10 chars'],
        errorCases: [
          { code: 'INVALID_DATE_RANGE', message: 'Leave start date cannot be after end date.', statusCode: 400 }
        ],
        relatedReqIds: ['REQ-006'],
        relatedDbEntityIds: ['DB-006']
      }
    ],
    testCases: [
      {
        id: 'TEST-001',
        title: 'Attendance Percentage Computation Formula Verification',
        type: 'functional',
        priority: 'critical',
        preconditions: ['Student enrolled in CS301', 'Total 20 sessions held: 14 Present, 2 Late, 3 Absent, 1 Excused'],
        inputData: 'Total: 20, Present: 14, Late: 2, Absent: 3, Excused: 1',
        steps: [
          'Call GET /api/v1/attendance/student/summary for the student',
          'Calculate expected denominator: Total Held (20) - Excused (1) = 19 sessions',
          'Calculate expected numerator: Present (14) + Late*0.5 (1.0) = 15.0',
          'Calculate expected percentage: (15.0 / 19.0) * 100 = 78.95%'
        ],
        expectedResult: 'API returns exact percentage 78.95% and isBelowThreshold: false.',
        executionStatus: 'passed',
        relatedReqIds: ['REQ-004'],
        relatedApiIds: ['API-005']
      },
      {
        id: 'TEST-002',
        title: 'Enforce 48-Hour Session Locking Rule',
        type: 'boundary',
        priority: 'high',
        preconditions: ['Attendance session created with session_date = NOW() - 3 days and is_locked = true'],
        inputData: 'PATCH /api/v1/attendance/records/batch with updated student statuses',
        steps: [
          'Authenticate as faculty instructor',
          'Attempt to update records for a session older than 48 hours without dean override',
          'Assert HTTP response status and error payload'
        ],
        expectedResult: 'System returns HTTP 400 Bad Request with error code SESSION_LOCKED and blocks modification.',
        executionStatus: 'passed',
        relatedReqIds: ['REQ-003', 'REQ-007'],
        relatedApiIds: ['API-004']
      },
      {
        id: 'TEST-003',
        title: 'Defaulter Warning Trigger when Percentage Drops Below 75%',
        type: 'functional',
        priority: 'critical',
        preconditions: ['Student currently has 15/20 sessions attended (75.0%)'],
        inputData: 'Instructor marks student Absent in session 21 (15/21 = 71.43%)',
        steps: [
          'Submit batch attendance marking student Absent',
          'Check student alert dashboard and notification dispatch queue',
          'Check Advisor Defaulter list endpoint'
        ],
        expectedResult: 'Student dashboard displays red warning banner; student is immediately listed on GET /api/v1/reports/low-attendance.',
        executionStatus: 'passed',
        relatedReqIds: ['REQ-005'],
        relatedApiIds: ['API-004', 'API-006']
      },
      {
        id: 'TEST-004',
        title: 'FERPA Privacy Guard: Student Prohibited from Viewing Peer Attendance',
        type: 'security',
        priority: 'critical',
        preconditions: ['User authenticated with Student role and UUID A'],
        inputData: 'GET /api/v1/attendance/student/summary?studentId=UUID_B',
        steps: [
          'Send request with student A JWT token passing student B UUID',
          'Inspect HTTP response status code'
        ],
        expectedResult: 'Returns HTTP 403 Forbidden with error ACCESS_DENIED_FERPA.',
        executionStatus: 'passed',
        relatedReqIds: ['REQ-010', 'REQ-001'],
        relatedApiIds: ['API-005']
      },
      {
        id: 'TEST-005',
        title: 'Medical Leave Approval State Mutation to Excused',
        type: 'integration',
        priority: 'medium',
        preconditions: ['Student marked Absent on Oct 20 in session S1', 'Medical leave submitted for Oct 20'],
        inputData: 'Faculty approves leave request ID L1',
        steps: [
          'Trigger approve action on leave request',
          'Verify attendance_records for Oct 20 transitioned from absent to excused',
          'Verify audit log entry created with reason "Medical Certificate Approved"'
        ],
        expectedResult: 'Record status is updated to "excused" and recalculates student denominator.',
        executionStatus: 'passed',
        relatedReqIds: ['REQ-006', 'REQ-007'],
        relatedApiIds: ['API-007']
      },
      {
        id: 'TEST-006',
        title: 'Sub-300ms Dashboard Summary Query SLA Test',
        type: 'functional',
        priority: 'high',
        preconditions: ['Database seeded with 1,000 students and 50,000 attendance records'],
        inputData: 'Concurrently query GET /api/v1/attendance/student/summary for 50 simulated users',
        steps: [
          'Execute load test using benchmarking suite',
          'Measure p95 and p99 response latencies'
        ],
        expectedResult: 'p95 latency is under 220ms, well within the 300ms SLA specified in REQ-009.',
        executionStatus: 'passed',
        relatedReqIds: ['REQ-009'],
        relatedApiIds: ['API-005']
      }
    ],
    implementationTasks: [
      {
        id: 'TASK-001',
        title: 'Implement Database Migrations & Relations',
        phase: 'Database',
        promptInstructions: 'Create Prisma / SQL migration scripts for users, courses, enrollments, attendance_sessions, attendance_records, and attendance_audit_logs. Apply composite unique index on (session_id, student_id).',
        acceptanceCriteria: ['Foreign keys cascade properly', 'Unique constraint blocks duplicate student marking per session'],
        relatedReqIds: ['REQ-001', 'REQ-002', 'REQ-003']
      },
      {
        id: 'TASK-002',
        title: 'Build JWT Authentication & RBAC Middleware',
        phase: 'Backend',
        promptInstructions: 'Implement Express / FastAPI authentication middleware verifying Bearer tokens, extracting role claims, and rejecting unauthorized role access.',
        acceptanceCriteria: ['Returns 401 on expired tokens', 'Returns 403 when role is insufficient'],
        relatedReqIds: ['REQ-001', 'REQ-010']
      },
      {
        id: 'TASK-003',
        title: 'Develop Real-Time Percentage Calculation Engine',
        phase: 'Backend',
        promptInstructions: 'Implement formula (Present + Late*0.5) / (Held - Excused) * 100 with zero-division safeguard and caching.',
        acceptanceCriteria: ['Handles 0 held sessions gracefully', 'Returns exact rounded float with threshold boolean'],
        relatedReqIds: ['REQ-004', 'REQ-009']
      },
      {
        id: 'TASK-004',
        title: 'Create Teacher Roll Call UI with Fast Toggles',
        phase: 'Frontend',
        promptInstructions: 'Build React component with keyboard navigation (P, A, L keys) and "Mark All Present" button for rapid class marking.',
        acceptanceCriteria: ['Saves in under 1 second', 'Offline retry buffer for intermittent Wi-Fi'],
        relatedReqIds: ['REQ-003']
      },
      {
        id: 'TASK-005',
        title: 'Construct Student Attendance & Defaulter Dashboard',
        phase: 'Frontend',
        promptInstructions: 'Design responsive progress rings, colored threshold badges (<75% Red, 75-80% Yellow, >80% Green), and "Bunk Calculator".',
        acceptanceCriteria: ['Mobile responsive', 'Accessible contrast'],
        relatedReqIds: ['REQ-004', 'REQ-005']
      }
    ],
    securityRequirements: [
      {
        id: 'SEC-001',
        title: 'FERPA & Student Privacy Isolation',
        description: 'Multi-tenant student isolation ensures students can only retrieve their own record metrics.',
        mitigationStrategy: 'Enforce session.userId === params.studentId in backend authorization layer.',
        relatedReqIds: ['REQ-010']
      },
      {
        id: 'SEC-002',
        title: 'Attendance Modification Tamper-Proofing',
        description: 'Prevent retroactive attendance falsification by rogue actors.',
        mitigationStrategy: 'Enforce 48h database triggers and insert immutable rows into attendance_audit_logs on every UPDATE.',
        relatedReqIds: ['REQ-007']
      }
    ]
  }
};

export const SAMPLE_PROJECTS: Project[] = [
  SAMPLE_PROJECT_ATTENDANCE
];
