/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FullBlueprint, ValidationFinding, CoverageMetrics } from '../../types/blueprint';
import { ExportService } from '../../services/exportService';
import { Download, FileText, Database, Globe, CheckCircle2, Archive, Table, Code2, Printer } from 'lucide-react';

interface ExportCenterViewProps {
  blueprint: FullBlueprint;
  findings: ValidationFinding[];
  metrics: CoverageMetrics;
}

export const ExportCenterView: React.FC<ExportCenterViewProps> = ({
  blueprint,
  findings,
  metrics
}) => {
  const [isZipping, setIsZipping] = useState(false);

  const handleDownloadZip = async () => {
    setIsZipping(true);
    try {
      const blob = await ExportService.generateZipPackage(blueprint, findings, metrics);
      ExportService.downloadFile(`${blueprint.projectId}_blueprint_package.zip`, blob);
    } catch (e) {
      console.error('ZIP generation failed', e);
    } finally {
      setIsZipping(false);
    }
  };

  const handleDownloadMarkdown = () => {
    const md = ExportService.generateMarkdown(blueprint);
    ExportService.downloadFile(`${blueprint.projectId}_BLUEPRINT.md`, md);
  };

  const handleDownloadOpenApi = () => {
    const json = ExportService.generateOpenApiJson(blueprint);
    ExportService.downloadFile('openapi.json', json, 'application/json');
  };

  const handleDownloadSql = () => {
    ExportService.downloadFile('schema.sql', blueprint.database.sqlDdl, 'text/sql');
  };

  const handleDownloadReqsCsv = () => {
    const csv = ExportService.generateRequirementsCsv(blueprint);
    ExportService.downloadFile('requirements.csv', csv, 'text/csv');
  };

  const handleDownloadTestsCsv = () => {
    const csv = ExportService.generateTestCasesCsv(blueprint);
    ExportService.downloadFile('test_cases.csv', csv, 'text/csv');
  };

  const handleDownloadTraceCsv = () => {
    const csv = ExportService.generateTraceMatrixCsv(blueprint);
    ExportService.downloadFile('traceability_matrix.csv', csv, 'text/csv');
  };

  const handlePrintValidationReport = () => {
    window.print();
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Banner & Complete ZIP Bundle */}
      <div className="p-8 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/60 border border-blue-900/60 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2 text-center md:text-left">
          <div className="flex items-center gap-2 justify-center md:justify-start">
            <Archive size={20} className="text-blue-400" />
            <h3 className="text-lg font-bold text-white">Export Complete Software Specification Package</h3>
          </div>
          <p className="text-xs text-slate-300 max-w-xl">
            Download the entire project bundle as a single ZIP archive containing Markdown specifications,
            PostgreSQL SQL DDL, OpenAPI 3.0 schema, test cases, Mermaid diagrams, and Traceability Matrix.
          </p>
          <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-1 justify-center md:justify-start">
            <span>Project: <strong className="text-white">{blueprint.overview.title}</strong></span>
            <span>Version: <strong className="text-blue-400">{blueprint.version}</strong></span>
          </div>
        </div>

        <button
          onClick={handleDownloadZip}
          disabled={isZipping}
          className="flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold shadow-xl shadow-blue-600/30 transition shrink-0 cursor-pointer"
        >
          <Archive size={16} />
          <span>{isZipping ? 'Assembling ZIP Package...' : 'Download Full Project ZIP (.zip)'}</span>
        </button>
      </div>

      {/* Individual Artifact Downloads Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Full Blueprint Markdown */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs text-slate-400">BLUEPRINT.md</span>
              <FileText size={16} className="text-blue-400" />
            </div>
            <h4 className="text-sm font-bold text-white">Full Blueprint Document</h4>
            <p className="text-xs text-slate-400 mt-1">Complete system scope, requirements, architecture, schemas, and test suite.</p>
          </div>
          <button
            onClick={handleDownloadMarkdown}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white transition"
          >
            <Download size={13} />
            <span>Download Markdown</span>
          </button>
        </div>

        {/* Database SQL DDL */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs text-slate-400">schema.sql</span>
              <Database size={16} className="text-amber-400" />
            </div>
            <h4 className="text-sm font-bold text-white">PostgreSQL SQL DDL</h4>
            <p className="text-xs text-slate-400 mt-1">Ready-to-execute relational table definitions with foreign keys and indexes.</p>
          </div>
          <button
            onClick={handleDownloadSql}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white transition"
          >
            <Download size={13} />
            <span>Download SQL</span>
          </button>
        </div>

        {/* OpenAPI 3.0 Spec */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs text-slate-400">openapi.json</span>
              <Globe size={16} className="text-emerald-400" />
            </div>
            <h4 className="text-sm font-bold text-white">OpenAPI 3.0 Specification</h4>
            <p className="text-xs text-slate-400 mt-1">Standard OAS 3.0 specification compatible with Swagger, Postman, and code generators.</p>
          </div>
          <button
            onClick={handleDownloadOpenApi}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white transition"
          >
            <Download size={13} />
            <span>Download OpenAPI JSON</span>
          </button>
        </div>

        {/* Requirements CSV */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs text-slate-400">requirements.csv</span>
              <Table size={16} className="text-indigo-400" />
            </div>
            <h4 className="text-sm font-bold text-white">Requirements Register</h4>
            <p className="text-xs text-slate-400 mt-1">Atomic requirements structured with IDs, types, priorities, and confidence scores.</p>
          </div>
          <button
            onClick={handleDownloadReqsCsv}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white transition"
          >
            <Download size={13} />
            <span>Download CSV</span>
          </button>
        </div>

        {/* Test Cases CSV */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs text-slate-400">test_cases.csv</span>
              <CheckCircle2 size={16} className="text-purple-400" />
            </div>
            <h4 className="text-sm font-bold text-white">Verification Test Suite</h4>
            <p className="text-xs text-slate-400 mt-1">QA specifications with preconditions, procedural steps, and assertions.</p>
          </div>
          <button
            onClick={handleDownloadTestsCsv}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white transition"
          >
            <Download size={13} />
            <span>Download CSV</span>
          </button>
        </div>

        {/* Traceability Matrix CSV */}
        <div className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3">
          <div>
            <div className="flex items-center justify-between mb-1">
              <span className="font-mono text-xs text-slate-400">traceability_matrix.csv</span>
              <Table size={16} className="text-cyan-400" />
            </div>
            <h4 className="text-sm font-bold text-white">2D Traceability Matrix</h4>
            <p className="text-xs text-slate-400 mt-1">End-to-end requirement mapping to stories, components, tables, APIs, and tests.</p>
          </div>
          <button
            onClick={handleDownloadTraceCsv}
            className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white transition"
          >
            <Download size={13} />
            <span>Download CSV</span>
          </button>
        </div>
      </div>
    </div>
  );
};
