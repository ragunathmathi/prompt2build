/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { DatabaseBlueprint, DatabaseEntity } from '../../types/blueprint';
import { MermaidViewer } from '../common/MermaidViewer';
import { Database, Download, Copy, Check, Table, Key, Link2, FileCode } from 'lucide-react';
import { ExportService } from '../../services/exportService';

interface DatabaseBlueprintViewProps {
  database: DatabaseBlueprint;
  onUpdateDatabase: (db: DatabaseBlueprint) => void;
}

export const DatabaseBlueprintView: React.FC<DatabaseBlueprintViewProps> = ({
  database
}) => {
  const [activeTab, setActiveTab] = useState<'entities' | 'erd' | 'sql'>('entities');
  const [copiedSql, setCopiedSql] = useState(false);
  const [selectedEntityId, setSelectedEntityId] = useState<string>(database.entities[0]?.id || '');

  const selectedEntity = database.entities.find(e => e.id === selectedEntityId) || database.entities[0];

  const handleCopySql = () => {
    navigator.clipboard.writeText(database.sqlDdl);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  const handleDownloadSql = () => {
    ExportService.downloadFile('schema.sql', database.sqlDdl, 'text/sql');
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <Database size={18} className="text-amber-400" />
            <h3 className="text-base font-bold text-white">Relational Database Blueprint (PostgreSQL DDL)</h3>
          </div>
          <p className="text-xs text-slate-400">
            3NF normalized schema with primary keys, foreign-key cascades, index recommendations, and ER diagrams.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopySql}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 transition"
          >
            {copiedSql ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
            <span>{copiedSql ? 'Copied SQL' : 'Copy DDL'}</span>
          </button>
          <button
            onClick={handleDownloadSql}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md transition"
          >
            <Download size={13} />
            <span>Download .sql</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('entities')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
            activeTab === 'entities' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Table size={14} />
          <span>Entities &amp; Schema ({database.entities.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('erd')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
            activeTab === 'erd' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Link2 size={14} />
          <span>Entity-Relationship Diagram</span>
        </button>
        <button
          onClick={() => setActiveTab('sql')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
            activeTab === 'sql' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <FileCode size={14} />
          <span>Raw SQL DDL</span>
        </button>
      </div>

      {/* ENTITIES TAB */}
      {activeTab === 'entities' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Table List Sidebar */}
          <div className="lg:col-span-1 flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">Tables</span>
            {database.entities.map(ent => (
              <button
                key={ent.id}
                onClick={() => setSelectedEntityId(ent.id)}
                className={`p-3 rounded-xl border text-left transition flex flex-col gap-1 ${
                  selectedEntity?.id === ent.id
                    ? 'bg-amber-950/40 border-amber-500/80 text-white shadow-md'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-amber-300">{ent.tableName}</span>
                  <span className="text-[10px] text-slate-500 font-mono">{ent.id}</span>
                </div>
                <span className="text-[11px] text-slate-400 truncate">{ent.fields.length} columns</span>
              </button>
            ))}
          </div>

          {/* Selected Entity Details */}
          {selectedEntity && (
            <div className="lg:col-span-3 flex flex-col gap-5">
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-white font-mono">{selectedEntity.tableName}</span>
                    <span className="font-mono text-xs text-amber-400 bg-amber-950 px-2 py-0.5 rounded border border-amber-900/60">
                      {selectedEntity.id}
                    </span>
                  </div>
                  <div className="flex gap-1.5">
                    {selectedEntity.relatedReqIds.map(rId => (
                      <span key={rId} className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 font-mono text-[10px] border border-blue-900">
                        {rId}
                      </span>
                    ))}
                  </div>
                </div>
                <p className="text-xs text-slate-300">{selectedEntity.description}</p>
                {selectedEntity.normalizationNotes && (
                  <div className="text-[11px] text-slate-400 font-mono bg-slate-950 p-2.5 rounded-lg border border-slate-800 mt-1">
                    Normalization: {selectedEntity.normalizationNotes}
                  </div>
                )}
              </div>

              {/* Fields Table */}
              <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    <tr>
                      <th className="py-3 px-4">Column Name</th>
                      <th className="py-3 px-4">Data Type</th>
                      <th className="py-3 px-3">Keys / Constraints</th>
                      <th className="py-3 px-3">Nullable</th>
                      <th className="py-3 px-4">Description</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 font-mono">
                    {selectedEntity.fields.map(field => (
                      <tr key={field.name} className="hover:bg-slate-850">
                        <td className="py-3 px-4 font-bold text-white flex items-center gap-1.5">
                          {field.isPrimary && <Key size={13} className="text-amber-400 shrink-0" />}
                          {field.isForeign && <Link2 size={13} className="text-blue-400 shrink-0" />}
                          <span>{field.name}</span>
                        </td>
                        <td className="py-3 px-4 text-emerald-400 font-bold">{field.type}</td>
                        <td className="py-3 px-3">
                          <div className="flex flex-wrap gap-1 font-sans">
                            {field.isPrimary && (
                              <span className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 text-[10px] font-bold border border-amber-800">
                                PK
                              </span>
                            )}
                            {field.isForeign && field.references && (
                              <span className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 text-[10px] font-mono border border-blue-800">
                                FK &rarr; {field.references.table}.{field.references.field}
                              </span>
                            )}
                            {field.isUnique && !field.isPrimary && (
                              <span className="px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 text-[10px] border border-purple-800">
                                UNIQUE
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 px-3 font-sans">
                          {field.isNullable ? (
                            <span className="text-slate-400 text-[11px]">YES</span>
                          ) : (
                            <span className="text-rose-400 text-[11px] font-semibold">NOT NULL</span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-sans text-slate-300 text-xs">{field.description}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ERD TAB */}
      {activeTab === 'erd' && (
        <MermaidViewer chart={database.erdMermaid} title="Entity-Relationship Diagram (ERD)" />
      )}

      {/* SQL DDL TAB */}
      {activeTab === 'sql' && (
        <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
          <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400">PostgreSQL Schema Definition</span>
            <button
              onClick={handleCopySql}
              className="text-xs text-blue-400 hover:text-white flex items-center gap-1"
            >
              <Copy size={12} />
              <span>Copy</span>
            </button>
          </div>
          <pre className="p-5 text-xs text-slate-200 font-mono overflow-x-auto bg-slate-950/70 leading-relaxed max-h-[500px]">
            {database.sqlDdl}
          </pre>
        </div>
      )}
    </div>
  );
};
