/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Project, FullBlueprint, CoverageMetrics } from '../../types/blueprint';
import { MetricCard } from '../common/MetricCard';
import { Layers, ShieldCheck, CheckCircle2, GitBranch, ArrowRight, Database, Globe, Download, Sparkles, Terminal } from 'lucide-react';

interface DashboardOverviewProps {
  project: Project;
  blueprint: FullBlueprint;
  metrics: CoverageMetrics;
  onNavigateTab: (tab: string) => void;
}

export const DashboardOverview: React.FC<DashboardOverviewProps> = ({
  project,
  blueprint,
  metrics,
  onNavigateTab
}) => {
  return (
    <div className="flex flex-col gap-6">
      {/* Hero Project Banner */}
      <div className="p-8 rounded-2xl bg-gradient-to-r from-slate-900 via-blue-950/40 to-slate-900 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xl">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Verified Blueprint v{blueprint.version}
            </span>
            <span className="text-xs text-slate-400 font-mono">TraceSpec Engine Verified</span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight">{blueprint.overview.title}</h1>
          <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">{blueprint.overview.description}</p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            onClick={() => onNavigateTab('graph')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-lg shadow-blue-600/30 transition cursor-pointer"
          >
            <GitBranch size={14} />
            <span>Traceability Graph</span>
          </button>
          <button
            onClick={() => onNavigateTab('export')}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-850 hover:bg-slate-800 text-slate-200 border border-slate-700 text-xs font-bold transition cursor-pointer"
          >
            <Download size={14} />
            <span>Export Package</span>
          </button>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          label="Total Requirements"
          value={metrics.totalRequirements}
          subValue={`${metrics.approvedCount} Approved · ${metrics.draftCount} Draft`}
          icon={<Layers size={18} />}
          variant="blue"
        />
        <MetricCard
          label="Specification Coverage"
          value={`${metrics.specCoveragePercent}%`}
          subValue={metrics.orphanedRequirements.length === 0 ? 'Zero orphaned reqs' : `${metrics.orphanedRequirements.length} unlinked`}
          icon={<Database size={18} />}
          variant="emerald"
        />
        <MetricCard
          label="Test Verification Coverage"
          value={`${metrics.testCoveragePercent}%`}
          subValue={`${blueprint.testCases.length} QA test specs`}
          icon={<CheckCircle2 size={18} />}
          variant="amber"
        />
        <MetricCard
          label="TraceSpec Rule Pass Rate"
          value={`${metrics.rulePassRate}%`}
          subValue={metrics.brokenReferences === 0 ? 'Relational integrity intact' : `${metrics.brokenReferences} FK issues`}
          icon={<ShieldCheck size={18} />}
          variant="rose"
        />
      </div>

      {/* Scope, Audience & Assumptions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Functional Scope</span>
          <p className="text-xs text-slate-300 leading-relaxed">{blueprint.overview.scope}</p>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Target Stakeholders</span>
          <div className="flex flex-wrap gap-1.5 mt-1">
            {blueprint.overview.targetAudience.map((aud, i) => (
              <span key={i} className="px-2.5 py-1 rounded-lg bg-slate-950 text-slate-200 text-xs border border-slate-800 font-medium">
                {aud}
              </span>
            ))}
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Key Architectural Assumptions</span>
          <ul className="space-y-1.5 text-xs text-slate-300 mt-1">
            {blueprint.overview.keyAssumptions.map((assump, i) => (
              <li key={i} className="flex items-start gap-1.5">
                <span className="text-blue-400">•</span>
                <span>{assump}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* System Modules & Implementation Tasks */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* System Modules */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white">System Modules ({blueprint.systemModules.length})</h3>
            <button onClick={() => onNavigateTab('architecture')} className="text-xs text-blue-400 hover:text-blue-300">
              View Architecture &rarr;
            </button>
          </div>
          <div className="space-y-3">
            {blueprint.systemModules.map(mod => (
              <div key={mod.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white">{mod.name}</span>
                  <span className="font-mono text-[10px] text-blue-400">{mod.id}</span>
                </div>
                <p className="text-xs text-slate-400">{mod.description}</p>
                <div className="flex items-center gap-1.5 pt-1 text-[11px] text-slate-500 font-mono">
                  <span>Components: {mod.components.join(', ')}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Implementation Tasks & Developer Prompts */}
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white">Implementation Tasks &amp; Dev Prompts</h3>
            <span className="text-xs text-slate-500 font-mono">{blueprint.implementationTasks.length} tasks</span>
          </div>
          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {blueprint.implementationTasks.map(task => (
              <div key={task.id} className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-200">{task.title}</span>
                  <span className="px-2 py-0.5 rounded text-[10px] uppercase font-mono bg-slate-900 text-purple-300 border border-purple-900/60">
                    {task.phase}
                  </span>
                </div>
                <div className="p-2.5 rounded bg-slate-900 border border-slate-850 text-[11px] text-slate-300 font-mono leading-relaxed flex items-start gap-2">
                  <Terminal size={13} className="text-blue-400 shrink-0 mt-0.5" />
                  <span>{task.promptInstructions}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
