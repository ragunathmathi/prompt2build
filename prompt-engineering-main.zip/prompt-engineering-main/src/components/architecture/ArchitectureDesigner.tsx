/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ArchitectureDesign, ArchitectureComponent } from '../../types/blueprint';
import { MermaidViewer } from '../common/MermaidViewer';
import { StatusBadge } from '../common/StatusBadge';
import { Layers, Edit3, Check, RefreshCw, ArrowRight } from 'lucide-react';

interface ArchitectureDesignerProps {
  architecture: ArchitectureDesign;
  onUpdateArchitecture: (updated: ArchitectureDesign) => void;
}

export const ArchitectureDesigner: React.FC<ArchitectureDesignerProps> = ({
  architecture,
  onUpdateArchitecture
}) => {
  const [isEditingDiagram, setIsEditingDiagram] = useState(false);
  const [diagramCode, setDiagramCode] = useState(architecture.mermaidCode);
  const [activeTab, setActiveTab] = useState<'diagram' | 'components' | 'dataflow'>('diagram');

  const handleSaveDiagram = () => {
    onUpdateArchitecture({
      ...architecture,
      mermaidCode: diagramCode
    });
    setIsEditingDiagram(false);
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Overview Card */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Layers size={18} className="text-blue-400" />
            <h3 className="text-base font-bold text-white">System Architecture &amp; Data Flow</h3>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-md bg-blue-950 text-blue-300 font-medium border border-blue-800">
            {architecture.style}
          </span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed font-sans">{architecture.summary}</p>
      </div>

      {/* Tabs */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('diagram')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'diagram' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Architecture Flowchart (Mermaid)
          </button>
          <button
            onClick={() => setActiveTab('components')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'components' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Components &amp; Dependencies ({architecture.components.length})
          </button>
          <button
            onClick={() => setActiveTab('dataflow')}
            className={`px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'dataflow' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            Data Flow Protocol ({architecture.dataFlow.length})
          </button>
        </div>

        {activeTab === 'diagram' && (
          <button
            onClick={() => setIsEditingDiagram(!isEditingDiagram)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-300 font-semibold transition"
          >
            <Edit3 size={13} />
            <span>{isEditingDiagram ? 'Preview Diagram' : 'Edit Mermaid Syntax'}</span>
          </button>
        )}
      </div>

      {/* DIAGRAM TAB */}
      {activeTab === 'diagram' && (
        <div className="flex flex-col gap-4">
          {isEditingDiagram ? (
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Mermaid Source Editor
                </span>
                <button
                  onClick={handleSaveDiagram}
                  className="flex items-center gap-1 px-3 py-1 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold"
                >
                  <Check size={12} />
                  <span>Save Diagram Changes</span>
                </button>
              </div>
              <textarea
                rows={12}
                value={diagramCode}
                onChange={e => setDiagramCode(e.target.value)}
                className="w-full p-4 rounded-lg bg-slate-950 border border-slate-700 text-xs text-blue-300 font-mono leading-relaxed focus:outline-none focus:border-blue-500"
              />
            </div>
          ) : (
            <MermaidViewer chart={architecture.mermaidCode} title="System Architecture & Component Flow" />
          )}
        </div>
      )}

      {/* COMPONENTS TAB */}
      {activeTab === 'components' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {architecture.components.map(comp => (
            <div key={comp.id} className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs font-bold text-sky-400 bg-sky-950/60 px-2 py-0.5 rounded border border-sky-800">
                    {comp.id}
                  </span>
                  <StatusBadge label={comp.layer} variant="layer" />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">{comp.name}</h4>
                <p className="text-xs text-slate-300 leading-relaxed mb-3">{comp.description}</p>
                <div className="text-xs text-slate-400 font-mono">
                  Stack: <span className="text-slate-200">{comp.technology}</span>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex flex-col gap-2 text-[11px]">
                {comp.dependencies && comp.dependencies.length > 0 && (
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500">Dependencies:</span>
                    <div className="flex gap-1">
                      {comp.dependencies.map(dep => (
                        <span key={dep} className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                          {dep}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <span className="text-slate-500">Satisfies Reqs:</span>
                  <div className="flex gap-1">
                    {comp.relatedReqIds.map(rId => (
                      <span key={rId} className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 font-mono text-[10px] border border-blue-900">
                        {rId}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* DATA FLOW TAB */}
      {activeTab === 'dataflow' && (
        <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">From</th>
                <th className="py-3 px-4">To</th>
                <th className="py-3 px-4">Description</th>
                <th className="py-3 px-4">Protocol</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {architecture.dataFlow.map((flow, idx) => (
                <tr key={idx} className="hover:bg-slate-850">
                  <td className="py-3.5 px-4 font-mono font-bold text-blue-400">{flow.from}</td>
                  <td className="py-3.5 px-4 font-mono font-bold text-emerald-400">{flow.to}</td>
                  <td className="py-3.5 px-4 text-slate-300">{flow.description}</td>
                  <td className="py-3.5 px-4">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[11px]">
                      {flow.protocol}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
