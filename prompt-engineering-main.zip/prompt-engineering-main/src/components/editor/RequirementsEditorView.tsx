/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { FullBlueprint, Requirement } from '../../types/blueprint';
import { StatusBadge } from '../common/StatusBadge';
import { Search, Plus, Edit3, ShieldAlert, CheckCircle2, Filter, Layers, Users } from 'lucide-react';
import { ChangeImpactModal } from '../impact/ChangeImpactModal';

interface RequirementsEditorViewProps {
  blueprint: FullBlueprint;
  onUpdateRequirement: (req: Requirement) => void;
  onSelectRequirementForTrace?: (reqId: string) => void;
}

export const RequirementsEditorView: React.FC<RequirementsEditorViewProps> = ({
  blueprint,
  onUpdateRequirement,
  onSelectRequirementForTrace
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'requirements' | 'stories' | 'roles'>('requirements');
  const [editingReq, setEditingReq] = useState<Requirement | null>(null);

  const filteredReqs = blueprint.requirements.filter(req => {
    const matchesSearch =
      req.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      req.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = selectedType === 'all' || req.type === selectedType;
    const matchesPriority = selectedPriority === 'all' || req.priority === selectedPriority;

    return matchesSearch && matchesType && matchesPriority;
  });

  return (
    <div className="flex flex-col gap-6">
      {/* Tab Navigation */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('requirements')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'requirements'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <span>Requirements ({blueprint.requirements.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('stories')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'stories'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Layers size={14} />
            <span>User Stories ({blueprint.userStories.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('roles')}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
              activeTab === 'roles'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 hover:text-white'
            }`}
          >
            <Users size={14} />
            <span>Roles Matrix ({blueprint.rolesMatrix.length})</span>
          </button>
        </div>
      </div>

      {/* REQUIREMENTS TAB */}
      {activeTab === 'requirements' && (
        <div className="flex flex-col gap-4">
          {/* Filter Bar */}
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3 flex-1 min-w-[260px]">
              <div className="relative flex-1 max-w-sm">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  placeholder="Search requirements by ID or keywords..."
                  className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
                />
              </div>

              <select
                value={selectedType}
                onChange={e => setSelectedType(e.target.value)}
                className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none"
              >
                <option value="all">All Types</option>
                <option value="functional">Functional</option>
                <option value="non-functional">Non-Functional</option>
                <option value="security">Security</option>
              </select>

              <select
                value={selectedPriority}
                onChange={e => setSelectedPriority(e.target.value)}
                className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none"
              >
                <option value="all">All Priorities</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
          </div>

          {/* Requirements Cards */}
          <div className="grid grid-cols-1 gap-3">
            {filteredReqs.map(req => (
              <div
                key={req.id}
                className="p-4 rounded-xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition flex flex-col gap-2.5"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-xs font-bold text-blue-400 bg-blue-950 px-2 py-0.5 rounded border border-blue-900/60">
                      {req.id}
                    </span>
                    <h4 className="text-sm font-bold text-white">{req.title}</h4>
                    <span className="text-[11px] text-slate-500">v{req.version}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <StatusBadge label={req.type} variant="type" />
                    <StatusBadge label={req.priority} variant="priority" />
                    <StatusBadge label={req.status} />

                    <button
                      onClick={() => setEditingReq(req)}
                      className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-amber-300 font-semibold transition ml-2 cursor-pointer"
                      title="Modify requirement and evaluate change impact"
                    >
                      <ShieldAlert size={13} />
                      <span>Impact Edit</span>
                    </button>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed font-sans pl-0.5">{req.description}</p>

                <div className="flex items-center justify-between text-[11px] text-slate-500 pt-2 border-t border-slate-800/80">
                  <div className="flex items-center gap-3">
                    <span>
                      Source: <strong className="text-slate-400 font-medium">{req.source}</strong>
                    </span>
                    <span>
                      Confidence: <strong className="text-emerald-400 font-mono">{Math.round(req.confidence * 100)}%</strong>
                    </span>
                    <span>
                      Category: <strong className="text-slate-400">{req.category}</strong>
                    </span>
                  </div>

                  {onSelectRequirementForTrace && (
                    <button
                      onClick={() => onSelectRequirementForTrace(req.id)}
                      className="text-blue-400 hover:text-blue-300 font-medium"
                    >
                      View in Trace Graph &rarr;
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* USER STORIES TAB */}
      {activeTab === 'stories' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {blueprint.userStories.map(story => (
            <div key={story.id} className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800">
                    {story.id}
                  </span>
                  <span className="text-xs font-semibold text-slate-400">Role: {story.role}</span>
                </div>

                <div className="text-xs text-slate-200 leading-relaxed mb-3">
                  <p>
                    <strong className="text-white">As a</strong> {story.role},
                  </p>
                  <p>
                    <strong className="text-white">I want to</strong> {story.action},
                  </p>
                  <p>
                    <strong className="text-white">So that</strong> {story.benefit}.
                  </p>
                </div>

                {/* Acceptance Criteria */}
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                    Acceptance Criteria:
                  </span>
                  <div className="space-y-1.5">
                    {story.acceptanceCriteria.map((ac, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                        <CheckCircle2 size={13} className="text-emerald-400 shrink-0 mt-0.5" />
                        <span>{ac}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Related requirements */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">Related Requirements:</span>
                <div className="flex gap-1">
                  {story.relatedReqIds.map(rId => (
                    <span key={rId} className="px-1.5 py-0.5 rounded bg-slate-800 text-blue-300 font-mono text-[10px]">
                      {rId}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ROLES MATRIX TAB */}
      {activeTab === 'roles' && (
        <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Scope &amp; Responsibility</th>
                <th className="py-3 px-4">Assigned Permissions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {blueprint.rolesMatrix.map(role => (
                <tr key={role.role} className="hover:bg-slate-850">
                  <td className="py-3.5 px-4 font-bold text-white">{role.role}</td>
                  <td className="py-3.5 px-4 text-slate-300">{role.description}</td>
                  <td className="py-3.5 px-4">
                    <div className="flex flex-wrap gap-1.5">
                      {role.permissions.map(perm => (
                        <span key={perm} className="px-2 py-0.5 rounded bg-slate-800 text-purple-300 font-mono text-[11px] border border-slate-700">
                          {perm}
                        </span>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Change Impact Analysis Modal */}
      {editingReq && (
        <ChangeImpactModal
          blueprint={blueprint}
          initialReq={editingReq}
          isOpen={!!editingReq}
          onClose={() => setEditingReq(null)}
          onApplyChanges={(updatedReq) => {
            onUpdateRequirement(updatedReq);
            setEditingReq(null);
          }}
        />
      )}
    </div>
  );
};
