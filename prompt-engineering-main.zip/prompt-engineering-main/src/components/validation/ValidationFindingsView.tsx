/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ValidationFinding, CoverageMetrics } from '../../types/blueprint';
import { ShieldCheck, AlertCircle, AlertTriangle, CheckCircle, Info, RefreshCw, Wrench } from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';

interface ValidationFindingsViewProps {
  findings: ValidationFinding[];
  metrics: CoverageMetrics;
  onRevalidate: () => void;
  isValidating?: boolean;
}

export const ValidationFindingsView: React.FC<ValidationFindingsViewProps> = ({
  findings,
  metrics,
  onRevalidate,
  isValidating = false
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeSeverity, setActiveSeverity] = useState<string>('all');

  const categories = [
    { id: 'all', label: 'All Checks' },
    { id: 'traceability', label: 'Traceability & Orphans' },
    { id: 'relational_integrity', label: 'Relational & DB Integrity' },
    { id: 'api_consistency', label: 'API Consistency' },
    { id: 'test_coverage', label: 'Verification & Tests' },
    { id: 'syntax', label: 'Syntax & Diagrams' }
  ];

  const filteredFindings = findings.filter(f => {
    if (activeCategory !== 'all' && f.category !== activeCategory) return false;
    if (activeSeverity !== 'all' && f.severity !== activeSeverity) return false;
    return true;
  });

  const criticalCount = findings.filter(f => f.severity === 'critical').length;
  const errorCount = findings.filter(f => f.severity === 'error').length;
  const warningCount = findings.filter(f => f.severity === 'warning').length;

  return (
    <div className="flex flex-col gap-6">
      {/* Top Banner & Metric Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Rule Pass Rate</span>
            <span className="text-2xl font-bold font-mono text-emerald-400">{metrics.rulePassRate}%</span>
          </div>
          <div className="p-2.5 rounded-lg bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
            <ShieldCheck size={22} />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Critical Issues</span>
            <span className="text-2xl font-bold font-mono text-rose-400">{criticalCount}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-rose-950/60 text-rose-400 border border-rose-800/60">
            <AlertCircle size={22} />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Errors</span>
            <span className="text-2xl font-bold font-mono text-amber-400">{errorCount}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-amber-950/60 text-amber-400 border border-amber-800/60">
            <AlertTriangle size={22} />
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">Warnings &amp; Notices</span>
            <span className="text-2xl font-bold font-mono text-sky-400">{warningCount}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-sky-950/60 text-sky-400 border border-sky-800/60">
            <Info size={22} />
          </div>
        </div>
      </div>

      {/* Control Filters */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        {/* Category tabs */}
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
                activeCategory === cat.id
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          {/* Severity filter */}
          <select
            value={activeSeverity}
            onChange={e => setActiveSeverity(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none"
          >
            <option value="all">All Severities</option>
            <option value="critical">Critical</option>
            <option value="error">Error</option>
            <option value="warning">Warning</option>
          </select>

          <button
            onClick={onRevalidate}
            disabled={isValidating}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-white font-medium transition"
          >
            <RefreshCw size={13} className={isValidating ? 'animate-spin text-blue-400' : ''} />
            <span>{isValidating ? 'Checking Rules...' : 'Re-run Verification'}</span>
          </button>
        </div>
      </div>

      {/* Findings List */}
      <div className="flex flex-col gap-3">
        {filteredFindings.length === 0 ? (
          <div className="p-8 rounded-xl bg-slate-900 border border-slate-800 text-center flex flex-col items-center justify-center gap-2">
            <CheckCircle size={32} className="text-emerald-400" />
            <h4 className="text-sm font-bold text-white">All Formal Validation Rules Passed</h4>
            <p className="text-xs text-slate-400 max-w-md">
              No schema violations, missing links, foreign key defects, or orphaned requirements detected in the specification.
            </p>
          </div>
        ) : (
          filteredFindings.map(finding => {
            const isCritical = finding.severity === 'critical';
            const isError = finding.severity === 'error';

            return (
              <div
                key={finding.id}
                className={`p-4 rounded-xl border transition flex flex-col gap-2.5 ${
                  isCritical
                    ? 'bg-rose-950/20 border-rose-900/60'
                    : isError
                    ? 'bg-amber-950/20 border-amber-900/60'
                    : 'bg-slate-900/90 border-slate-800'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-800 border border-slate-700">
                      {finding.ruleId}
                    </span>
                    <StatusBadge label={finding.severity} variant="severity" />
                    <StatusBadge label={finding.status} />
                    <h4 className="text-xs font-bold text-white ml-1">{finding.title}</h4>
                  </div>
                  {finding.affectedNodeIds.length > 0 && (
                    <div className="flex items-center gap-1">
                      {finding.affectedNodeIds.map(nodeId => (
                        <span
                          key={nodeId}
                          className="px-2 py-0.5 rounded bg-slate-800 font-mono text-[10px] text-blue-300 border border-slate-700"
                        >
                          {nodeId}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <p className="text-xs text-slate-300 leading-relaxed pl-1">{finding.description}</p>

                {finding.suggestedFix && (
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs flex items-start gap-2 text-slate-400">
                    <Wrench size={14} className="text-blue-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-slate-300 font-semibold">Recommended Fix: </strong>
                      {finding.suggestedFix}
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
