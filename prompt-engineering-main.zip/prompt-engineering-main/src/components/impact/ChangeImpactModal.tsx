/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Requirement, FullBlueprint, ChangeImpactReport } from '../../types/blueprint';
import { TraceSpecEngine } from '../../services/tracespecEngine';
import { AlertTriangle, CheckCircle, XCircle, ArrowRight, ShieldAlert, FileText, Check, RotateCcw } from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';

interface ChangeImpactModalProps {
  blueprint: FullBlueprint;
  initialReq: Requirement;
  isOpen: boolean;
  onClose: () => void;
  onApplyChanges: (updatedReq: Requirement, report: ChangeImpactReport) => void;
}

export const ChangeImpactModal: React.FC<ChangeImpactModalProps> = ({
  blueprint,
  initialReq,
  isOpen,
  onClose,
  onApplyChanges
}) => {
  const [editedTitle, setEditedTitle] = useState(initialReq.title);
  const [editedDesc, setEditedDesc] = useState(initialReq.description);
  const [editedPriority, setEditedPriority] = useState(initialReq.priority);
  const [editedType, setEditedType] = useState(initialReq.type);
  const [isAnalyzed, setIsAnalyzed] = useState(false);
  const [impactReport, setImpactReport] = useState<ChangeImpactReport | null>(null);

  if (!isOpen) return null;

  const currentEditedReq: Requirement = {
    ...initialReq,
    title: editedTitle,
    description: editedDesc,
    priority: editedPriority,
    type: editedType,
    status: 'modified'
  };

  const handleRunAnalysis = () => {
    const report = TraceSpecEngine.analyzeChangeImpact(blueprint, initialReq, currentEditedReq);
    setImpactReport(report);
    setIsAnalyzed(true);
  };

  const handleConfirm = () => {
    if (impactReport) {
      onApplyChanges(currentEditedReq, impactReport);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-4xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-950/60 text-amber-400 border border-amber-800/60">
              <ShieldAlert size={18} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Requirement Change Impact Analysis (TraceSpec)</span>
                <span className="font-mono text-xs px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-800">
                  {initialReq.id}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Deterministic graph traversal calculates blast radius and revalidation requirements before committing updates.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <XCircle size={18} />
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-6">
          {/* Step 1: Edit Form */}
          <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-4">
            <div className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
              <span>Edit Requirement Criteria</span>
              <span className="text-[11px] text-slate-500 font-mono">Version v{initialReq.version}</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <label className="text-xs font-semibold text-slate-400 block mb-1">Requirement Title</label>
                <input
                  type="text"
                  value={editedTitle}
                  onChange={e => {
                    setEditedTitle(e.target.value);
                    setIsAnalyzed(false);
                  }}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-400 block mb-1">Priority</label>
                <select
                  value={editedPriority}
                  onChange={e => {
                    setEditedPriority(e.target.value as any);
                    setIsAnalyzed(false);
                  }}
                  className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
                >
                  <option value="critical">Critical</option>
                  <option value="high">High</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-400 block mb-1">Detailed Specification</label>
              <textarea
                rows={3}
                value={editedDesc}
                onChange={e => {
                  setEditedDesc(e.target.value);
                  setIsAnalyzed(false);
                }}
                className="w-full px-3 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500 font-mono leading-relaxed"
              />
            </div>

            <div className="flex justify-end">
              <button
                onClick={handleRunAnalysis}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-600/30 transition"
              >
                <ShieldAlert size={14} />
                <span>Simulate &amp; Compute Blast Radius</span>
              </button>
            </div>
          </div>

          {/* Step 2: Impact Analysis Report */}
          {impactReport && (
            <div className="flex flex-col gap-5">
              {/* Diff summary banner */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-0.5">
                    Detected Modifications
                  </span>
                  <p className="text-xs text-slate-300 font-medium">{impactReport.diffSummary}</p>
                </div>

                {/* Blast Radius Score Badge */}
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Blast Radius</span>
                    <span className="text-lg font-bold font-mono text-white">
                      {impactReport.blastRadiusScore} / 100
                    </span>
                  </div>
                  <div
                    className={`w-12 h-12 rounded-full border-4 flex items-center justify-center font-bold text-xs ${
                      impactReport.blastRadiusScore > 60
                        ? 'border-rose-500 text-rose-400 bg-rose-950/30'
                        : impactReport.blastRadiusScore > 35
                        ? 'border-amber-500 text-amber-400 bg-amber-950/30'
                        : 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                    }`}
                  >
                    {impactReport.blastRadiusScore}%
                  </div>
                </div>
              </div>

              {/* Directly & Indirectly Affected Artifacts */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Directly Affected */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between mb-3">
                    <span>Directly Linked Artifacts</span>
                    <span className="text-[11px] font-mono text-amber-400">
                      {impactReport.directlyAffectedArtifacts.length} items
                    </span>
                  </span>
                  <div className="flex flex-col gap-2 max-h-48 overflow-y-auto pr-1">
                    {impactReport.directlyAffectedArtifacts.length === 0 ? (
                      <span className="text-xs text-slate-500 italic">No direct technical links.</span>
                    ) : (
                      impactReport.directlyAffectedArtifacts.map(art => (
                        <div key={art.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-mono font-bold text-blue-400">{art.id}</span>
                            <StatusBadge label={art.type} variant="type" />
                          </div>
                          <div className="text-slate-300 font-medium truncate">{art.title}</div>
                          <div className="text-[11px] text-slate-500 mt-1">{art.impactReason}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Secondary Ripple Dependencies */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between mb-3">
                    <span>Indirect Cascade Artifacts</span>
                    <span className="text-[11px] font-mono text-sky-400">
                      {impactReport.indirectlyAffectedArtifacts.length} items
                    </span>
                  </span>
                  <div className="flex flex-col gap-2 max-h-48 overflow-y-auto pr-1">
                    {impactReport.indirectlyAffectedArtifacts.length === 0 ? (
                      <span className="text-xs text-slate-500 italic">No secondary dependencies detected.</span>
                    ) : (
                      impactReport.indirectlyAffectedArtifacts.map(art => (
                        <div key={art.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-mono font-bold text-sky-400">{art.id}</span>
                            <StatusBadge label={art.type} variant="type" />
                          </div>
                          <div className="text-slate-300 font-medium truncate">{art.title}</div>
                          <div className="text-[10px] text-slate-500 font-mono mt-1">
                            Path: {art.dependencyPath.join(' -> ')}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Recommended Regression Tests */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                  Targeted Regression Test Suite ({impactReport.suggestedRegressionTests.length})
                </span>
                <div className="flex flex-wrap gap-2">
                  {impactReport.suggestedRegressionTests.map(tId => (
                    <span
                      key={tId}
                      className="px-2.5 py-1 rounded-md bg-purple-950/70 border border-purple-800/80 text-purple-300 text-xs font-mono font-semibold flex items-center gap-1.5"
                    >
                      <CheckCircle size={13} className="text-purple-400" />
                      {tId}
                    </span>
                  ))}
                </div>
              </div>

              {/* Proposed Technical Updates */}
              {impactReport.proposedModifications.length > 0 && (
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                    Proposed Technical Adaptations
                  </span>
                  <div className="space-y-2">
                    {impactReport.proposedModifications.map((mod, idx) => (
                      <div key={idx} className="p-2.5 rounded bg-slate-900 border border-slate-800 text-xs flex items-start gap-2">
                        <span className="font-mono text-emerald-400 font-bold shrink-0">{mod.artifactId}:</span>
                        <span className="text-slate-300">{mod.proposedChange}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-slate-800 bg-slate-950 flex items-center justify-between">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-semibold transition"
          >
            Cancel
          </button>
          <div className="flex items-center gap-3">
            {impactReport && (
              <button
                onClick={handleConfirm}
                className="flex items-center gap-2 px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 transition"
              >
                <Check size={14} />
                <span>Accept &amp; Commit Requirement Changes</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
