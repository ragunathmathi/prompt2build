/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  subValue?: string;
  trend?: 'up' | 'down' | 'neutral' | 'good' | 'alert';
  icon?: React.ReactNode;
  variant?: 'blue' | 'emerald' | 'amber' | 'rose' | 'slate';
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  subValue,
  icon,
  variant = 'blue'
}) => {
  const borderVariants = {
    blue: 'border-blue-900/50 bg-blue-950/20 text-blue-400',
    emerald: 'border-emerald-900/50 bg-emerald-950/20 text-emerald-400',
    amber: 'border-amber-900/50 bg-amber-950/20 text-amber-400',
    rose: 'border-rose-900/50 bg-rose-950/20 text-rose-400',
    slate: 'border-slate-800 bg-slate-900/50 text-slate-400'
  };

  return (
    <div className={`p-4 rounded-xl border ${borderVariants[variant]} flex flex-col justify-between transition hover:border-slate-700`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-medium text-slate-400 uppercase tracking-wider">{label}</span>
        {icon && <div className="p-1.5 rounded-lg bg-slate-800/80 text-slate-300">{icon}</div>}
      </div>
      <div>
        <div className="text-2xl font-bold text-white tracking-tight">{value}</div>
        {subValue && <div className="text-xs text-slate-400 mt-1">{subValue}</div>}
      </div>
    </div>
  );
};
