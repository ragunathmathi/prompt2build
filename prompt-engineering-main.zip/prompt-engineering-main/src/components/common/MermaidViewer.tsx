/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from 'react';
import mermaid from 'mermaid';
import { Copy, Check, RefreshCw, ZoomIn, ZoomOut, Maximize2 } from 'lucide-react';

interface MermaidViewerProps {
  chart: string;
  className?: string;
  title?: string;
}

export const MermaidViewer: React.FC<MermaidViewerProps> = ({ chart, className = '', title }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [svgContent, setSvgContent] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [scale, setScale] = useState(1);
  const renderId = useRef(`mermaid-${Math.random().toString(36).substring(2, 9)}`);

  useEffect(() => {
    mermaid.initialize({
      startOnLoad: false,
      theme: 'dark',
      themeVariables: {
        darkMode: true,
        background: '#0f172a',
        primaryColor: '#3b82f6',
        primaryTextColor: '#f8fafc',
        primaryBorderColor: '#60a5fa',
        lineColor: '#94a3b8',
        secondaryColor: '#1e293b',
        tertiaryColor: '#0f172a'
      },
      securityLevel: 'loose'
    });

    const renderChart = async () => {
      if (!chart.trim()) return;
      try {
        setError(null);
        renderId.current = `mermaid-${Math.random().toString(36).substring(2, 9)}`;
        const { svg } = await mermaid.render(renderId.current, chart.trim());
        setSvgContent(svg);
      } catch (err: any) {
        console.warn('Mermaid rendering error:', err);
        setError(err?.message || 'Could not render diagram. Review syntax or view raw code.');
      }
    };

    renderChart();
  }, [chart]);

  const handleCopy = () => {
    navigator.clipboard.writeText(chart);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`flex flex-col rounded-xl border border-slate-700 bg-slate-900 overflow-hidden ${className}`}>
      {/* Header bar */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-800 bg-slate-950/80">
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></span>
          {title || 'Mermaid Diagram'}
        </span>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setScale(s => Math.max(0.6, s - 0.15))}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs transition"
            title="Zoom Out"
          >
            <ZoomOut size={14} />
          </button>
          <span className="text-[11px] text-slate-500 font-mono w-10 text-center">{Math.round(scale * 100)}%</span>
          <button
            onClick={() => setScale(s => Math.min(2.0, s + 0.15))}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs transition"
            title="Zoom In"
          >
            <ZoomIn size={14} />
          </button>
          <button
            onClick={() => setScale(1)}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 text-xs transition"
            title="Reset Zoom"
          >
            <RefreshCw size={14} />
          </button>
          <div className="h-4 w-px bg-slate-800 mx-1"></div>
          <button
            onClick={handleCopy}
            className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800/80 hover:bg-slate-700 rounded-lg border border-slate-700 transition"
          >
            {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
            <span>{copied ? 'Copied' : 'Copy Code'}</span>
          </button>
        </div>
      </div>

      {/* Render Canvas or Textual Fallback */}
      <div className="relative min-h-[320px] max-h-[550px] overflow-auto p-6 flex items-center justify-center bg-slate-950/40">
        {error ? (
          <div className="w-full max-w-lg p-4 rounded-lg bg-amber-950/30 border border-amber-800/60 text-amber-300 text-xs flex flex-col gap-2">
            <div className="font-semibold flex items-center gap-2">
              <span>⚠️ Diagram Syntax Fallback</span>
            </div>
            <p className="text-slate-400">
              The diagram specification contains an unsupported declaration or character. Displaying formatted source code:
            </p>
            <pre className="bg-slate-900 p-3 rounded text-[11px] text-slate-200 overflow-x-auto font-mono border border-slate-800">
              {chart}
            </pre>
          </div>
        ) : svgContent ? (
          <div
            ref={containerRef}
            style={{ transform: `scale(${scale})`, transformOrigin: 'center center', transition: 'transform 0.15s ease-out' }}
            className="w-full flex justify-center items-center select-none"
            dangerouslySetInnerHTML={{ __html: svgContent }}
          />
        ) : (
          <div className="flex flex-col items-center gap-2 text-slate-500 text-xs">
            <RefreshCw size={18} className="animate-spin text-blue-500" />
            <span>Rendering diagram...</span>
          </div>
        )}
      </div>
    </div>
  );
};
