/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';

interface StatusBadgeProps {
  label: string;
  variant?: 'type' | 'priority' | 'status' | 'layer' | 'severity';
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ label, variant = 'status', className = '' }) => {
  const norm = (label || '').toLowerCase();

  let colorClasses = 'bg-slate-800 text-slate-300 border-slate-700';

  if (variant === 'priority') {
    if (norm === 'critical') colorClasses = 'bg-rose-950/60 text-rose-300 border-rose-800/60';
    else if (norm === 'high') colorClasses = 'bg-amber-950/60 text-amber-300 border-amber-800/60';
    else if (norm === 'medium') colorClasses = 'bg-blue-950/60 text-blue-300 border-blue-800/60';
    else if (norm === 'low') colorClasses = 'bg-slate-800 text-slate-400 border-slate-700';
  } else if (variant === 'type') {
    if (norm === 'functional') colorClasses = 'bg-indigo-950/60 text-indigo-300 border-indigo-800/60';
    else if (norm === 'non-functional') colorClasses = 'bg-purple-950/60 text-purple-300 border-purple-800/60';
    else if (norm === 'security') colorClasses = 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60';
    else if (norm === 'data' || norm === 'integration') colorClasses = 'bg-cyan-950/60 text-cyan-300 border-cyan-800/60';
  } else if (variant === 'severity') {
    if (norm === 'critical') colorClasses = 'bg-rose-950/80 text-rose-300 border-rose-700';
    else if (norm === 'error') colorClasses = 'bg-red-950/70 text-red-300 border-red-800';
    else if (norm === 'warning') colorClasses = 'bg-amber-950/60 text-amber-300 border-amber-800';
    else if (norm === 'info') colorClasses = 'bg-sky-950/60 text-sky-300 border-sky-800';
  } else if (variant === 'layer') {
    if (norm === 'frontend') colorClasses = 'bg-sky-950/60 text-sky-300 border-sky-800/60';
    else if (norm === 'backend') colorClasses = 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60';
    else if (norm === 'database') colorClasses = 'bg-amber-950/60 text-amber-300 border-amber-800/60';
    else if (norm === 'cache') colorClasses = 'bg-red-950/60 text-red-300 border-red-800/60';
    else if (norm === 'auth') colorClasses = 'bg-purple-950/60 text-purple-300 border-purple-800/60';
  } else {
    // Default status
    if (norm === 'approved' || norm === 'passed' || norm === 'active' || norm === 'verified') {
      colorClasses = 'bg-emerald-950/60 text-emerald-300 border-emerald-800/60';
    } else if (norm === 'failed') {
      colorClasses = 'bg-rose-950/60 text-rose-300 border-rose-800/60';
    } else if (norm === 'needs_review' || norm === 'modified' || norm === 'draft') {
      colorClasses = 'bg-amber-950/60 text-amber-300 border-amber-800/60';
    } else if (norm === 'not_executed' || norm === 'unexecuted') {
      colorClasses = 'bg-slate-800/80 text-slate-400 border-slate-700';
    }
  }

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded-md text-[11px] font-medium border uppercase tracking-wider ${colorClasses} ${className}`}
    >
      {label}
    </span>
  );
};
