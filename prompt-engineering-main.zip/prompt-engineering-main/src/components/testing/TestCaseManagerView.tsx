/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TestCase, FullBlueprint } from '../../types/blueprint';
import { CheckCircle2, Download, Search, Play, Filter, ShieldCheck, AlertCircle } from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { ExportService } from '../../services/exportService';

interface TestCaseManagerViewProps {
  blueprint: FullBlueprint;
  onUpdateTestCase?: (updated: TestCase) => void;
}

export const TestCaseManagerView: React.FC<TestCaseManagerViewProps> = ({ blueprint }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedTestId, setSelectedTestId] = useState<string>(blueprint.testCases[0]?.id || '');

  const filteredTests = blueprint.testCases.filter(tc => {
    const matchesSearch =
      tc.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tc.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      tc.expectedResult.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === 'all' || tc.type === typeFilter;
    return matchesSearch && matchesType;
  });

  const selectedTest = blueprint.testCases.find(t => t.id === selectedTestId) || blueprint.testCases[0];

  const handleExportCsv = () => {
    const csv = ExportService.generateTestCasesCsv(blueprint);
    ExportService.downloadFile('test_cases.csv', csv, 'text/csv');
  };

  const handleExportJson = () => {
    const json = JSON.stringify(blueprint.testCases, null, 2);
    ExportService.downloadFile('test_cases.json', json, 'application/json');
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <CheckCircle2 size={18} className="text-purple-400" />
            <h3 className="text-base font-bold text-white">Verification Test Suite &amp; Acceptance Scenarios</h3>
          </div>
          <p className="text-xs text-slate-400">
            Formal verification specifications mapped 1-to-1 against requirements. Distinctly marks specification-defined test cases.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 transition"
          >
            <Download size={13} />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handleExportJson}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md transition"
          >
            <Download size={13} />
            <span>Export JSON</span>
          </button>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Filter tests by ID, title, or assertion..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none"
          >
            <option value="all">All Test Types</option>
            <option value="functional">Functional</option>
            <option value="security">Security &amp; RBAC</option>
            <option value="boundary">Boundary / SLA</option>
            <option value="integration">Integration</option>
          </select>
        </div>

        <span className="text-xs font-mono text-slate-400">
          Showing {filteredTests.length} of {blueprint.testCases.length} specifications
        </span>
      </div>

      {/* Main Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Test List Sidebar */}
        <div className="lg:col-span-2 flex flex-col gap-2.5">
          {filteredTests.map(tc => (
            <div
              key={tc.id}
              onClick={() => setSelectedTestId(tc.id)}
              className={`p-4 rounded-xl border text-left cursor-pointer transition flex flex-col gap-2 ${
                selectedTest?.id === tc.id
                  ? 'bg-purple-950/40 border-purple-500 text-white shadow-md'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850'
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs font-bold text-purple-300">{tc.id}</span>
                  <StatusBadge label={tc.type} />
                </div>
                <StatusBadge label={tc.executionStatus} />
              </div>

              <h4 className="text-xs font-bold text-slate-200 line-clamp-1">{tc.title}</h4>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-800/80">
                <div className="flex gap-1">
                  {tc.relatedReqIds.map(rId => (
                    <span key={rId} className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 font-mono text-[10px] border border-blue-900">
                      {rId}
                    </span>
                  ))}
                </div>
                <StatusBadge label={tc.priority} variant="priority" />
              </div>
            </div>
          ))}
        </div>

        {/* Selected Test Detail Card */}
        {selectedTest && (
          <div className="lg:col-span-2 flex flex-col gap-4 p-6 rounded-2xl bg-slate-900 border border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-bold text-purple-400 bg-purple-950 px-2 py-0.5 rounded border border-purple-800">
                  {selectedTest.id}
                </span>
                <StatusBadge label={selectedTest.type} />
              </div>
              <StatusBadge label={selectedTest.executionStatus} />
            </div>

            <h3 className="text-sm font-bold text-white">{selectedTest.title}</h3>

            {/* Preconditions */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Preconditions &amp; Environment
              </span>
              <ul className="space-y-1">
                {selectedTest.preconditions.map((pre, idx) => (
                  <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="text-purple-400 font-bold">•</span>
                    <span>{pre}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Input Data */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Test Input Fixtures / Trigger
              </span>
              <div className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-300">
                {selectedTest.inputData}
              </div>
            </div>

            {/* Execution Steps */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Procedural Steps
              </span>
              <ol className="space-y-1.5 font-sans">
                {selectedTest.steps.map((step, idx) => (
                  <li key={idx} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="font-mono text-[11px] text-purple-400 font-bold shrink-0">{idx + 1}.</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            {/* Expected Result */}
            <div>
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Expected Verification Assertion
              </span>
              <div className="p-3 rounded-lg bg-emerald-950/40 border border-emerald-800/80 text-xs text-emerald-300 font-medium">
                {selectedTest.expectedResult}
              </div>
            </div>

            {/* Traceability Metadata */}
            <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center gap-3 text-xs">
              <div>
                <span className="text-slate-500 mr-1.5">Related Requirements:</span>
                {selectedTest.relatedReqIds.map(rId => (
                  <span key={rId} className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 font-mono text-[11px] border border-blue-900 mr-1">
                    {rId}
                  </span>
                ))}
              </div>
              {selectedTest.relatedApiIds && selectedTest.relatedApiIds.length > 0 && (
                <div>
                  <span className="text-slate-500 mr-1.5">Target APIs:</span>
                  {selectedTest.relatedApiIds.map(apiId => (
                    <span key={apiId} className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 font-mono text-[11px] border border-emerald-900 mr-1">
                      {apiId}
                    </span>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
