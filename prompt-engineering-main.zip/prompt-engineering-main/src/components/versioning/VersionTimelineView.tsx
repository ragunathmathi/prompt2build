/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Project, FullBlueprint } from '../../types/blueprint';
import { History, GitCommit, RotateCcw, Plus, Check, ArrowRight, Layers } from 'lucide-react';
import { StorageService } from '../../services/storageService';

interface VersionTimelineViewProps {
  project: Project;
  onVersionRestored: (updatedProject: Project) => void;
  onSnapshotCreated: (updatedProject: Project) => void;
}

export const VersionTimelineView: React.FC<VersionTimelineViewProps> = ({
  project,
  onVersionRestored,
  onSnapshotCreated
}) => {
  const [commitMessage, setCommitMessage] = useState('');
  const [isCreatingSnapshot, setIsCreatingSnapshot] = useState(false);
  const [comparingVersion, setComparingVersion] = useState<string | null>(null);

  const versions = project.versions || [];
  const currentBlueprint = project.blueprint;

  const handleCreateSnapshot = () => {
    if (!commitMessage.trim()) return;
    const updated = StorageService.createVersionSnapshot(project.id, commitMessage.trim());
    if (updated) {
      onSnapshotCreated(updated);
      setCommitMessage('');
      setIsCreatingSnapshot(false);
    }
  };

  const handleRestore = (verString: string) => {
    const updated = StorageService.restoreVersion(project.id, verString);
    if (updated) {
      onVersionRestored(updated);
    }
  };

  const targetSnapshot = versions.find(v => v.version === comparingVersion)?.snapshot;

  return (
    <div className="flex flex-col gap-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <History size={18} className="text-blue-400" />
            <h3 className="text-base font-bold text-white">Blueprint Versioning &amp; Historical Immutability</h3>
          </div>
          <p className="text-xs text-slate-400">
            Current Active Version: <strong className="text-white font-mono">{project.currentVersion}</strong>.
            Create immutable snapshots and restore previous architectural states with full traceability preservation.
          </p>
        </div>

        <button
          onClick={() => setIsCreatingSnapshot(!isCreatingSnapshot)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md transition"
        >
          <GitCommit size={14} />
          <span>Commit Version Snapshot</span>
        </button>
      </div>

      {/* Snapshot Creation Form */}
      {isCreatingSnapshot && (
        <div className="p-5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-3">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Commit Current Blueprint State
          </span>
          <div className="flex gap-3">
            <input
              type="text"
              value={commitMessage}
              onChange={e => setCommitMessage(e.target.value)}
              placeholder="e.g. Added 48h attendance locking check constraint and dean alert endpoint..."
              className="flex-1 px-4 py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500 font-sans"
            />
            <button
              onClick={handleCreateSnapshot}
              disabled={!commitMessage.trim()}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center gap-1.5"
            >
              <Check size={14} />
              <span>Snapshot</span>
            </button>
          </div>
        </div>
      )}

      {/* Version History List */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Timeline Column */}
        <div className="md:col-span-1 flex flex-col gap-3">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
            Version Commits ({versions.length + 1})
          </span>

          {/* Current Working Version Card */}
          <div className="p-4 rounded-xl bg-blue-950/40 border-2 border-blue-500/80 text-white flex flex-col gap-1.5 shadow-md">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-blue-300">{project.currentVersion} (HEAD)</span>
              <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-blue-600 text-white">Active</span>
            </div>
            <p className="text-xs text-slate-300 font-medium">Current working specification</p>
            <span className="text-[10px] text-slate-400 font-mono">
              Updated: {new Date(project.updatedAt).toLocaleTimeString()}
            </span>
          </div>

          {/* Past Versions */}
          {versions.map(ver => (
            <div
              key={ver.version}
              className={`p-4 rounded-xl border transition flex flex-col gap-2 ${
                comparingVersion === ver.version
                  ? 'bg-slate-800 border-white'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-xs font-bold text-slate-300">v{ver.version}</span>
                <span className="text-[10px] text-slate-500 font-mono">
                  {new Date(ver.createdAt).toLocaleDateString()}
                </span>
              </div>
              <p className="text-xs text-slate-300 line-clamp-2">{ver.commitMessage}</p>

              <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                <button
                  onClick={() => setComparingVersion(ver.version === comparingVersion ? null : ver.version)}
                  className="text-blue-400 hover:text-white text-[11px] font-medium"
                >
                  {comparingVersion === ver.version ? 'Hide Diff' : 'Compare Diff'}
                </button>
                <button
                  onClick={() => handleRestore(ver.version)}
                  className="flex items-center gap-1 text-[11px] text-amber-400 hover:text-amber-300 font-medium"
                >
                  <RotateCcw size={11} />
                  <span>Restore</span>
                </button>
              </div>
            </div>
          ))}

          {versions.length === 0 && (
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-500 italic text-center">
              No previous version commits created yet. Use &quot;Commit Version Snapshot&quot; above.
            </div>
          )}
        </div>

        {/* Diff Comparison View */}
        <div className="md:col-span-2">
          {comparingVersion && targetSnapshot && currentBlueprint ? (
            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Specification Diff: Active (v{currentBlueprint.version}) vs Snapshot (v{targetSnapshot.version})
                </h4>
                <button
                  onClick={() => setComparingVersion(null)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Close
                </button>
              </div>

              {/* Requirement count diff */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Active Version Reqs</span>
                  <span className="font-mono text-base font-bold text-white">
                    {currentBlueprint.requirements.length} requirements
                  </span>
                </div>
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-500 uppercase block">Snapshot Version Reqs</span>
                  <span className="font-mono text-base font-bold text-slate-300">
                    {targetSnapshot.requirements.length} requirements
                  </span>
                </div>
              </div>

              {/* Added or Modified Requirements */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Requirement State Comparison
                </span>
                <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                  {currentBlueprint.requirements.map(req => {
                    const snapReq = targetSnapshot.requirements.find(r => r.id === req.id);
                    const isNew = !snapReq;
                    const isChanged = snapReq && snapReq.description !== req.description;

                    return (
                      <div
                        key={req.id}
                        className={`p-3 rounded-lg border text-xs flex flex-col gap-1 ${
                          isNew
                            ? 'bg-emerald-950/20 border-emerald-800 text-emerald-200'
                            : isChanged
                            ? 'bg-amber-950/20 border-amber-800 text-amber-200'
                            : 'bg-slate-950 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold">{req.id}: {req.title}</span>
                          <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800">
                            {isNew ? 'Added in Head' : isChanged ? 'Modified' : 'Unchanged'}
                          </span>
                        </div>
                        {isChanged && snapReq && (
                          <div className="text-[11px] text-slate-400 font-mono mt-1 pt-1 border-t border-slate-800">
                            Prior: {snapReq.description}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[300px] rounded-2xl bg-slate-900 border border-slate-800 p-8 flex flex-col items-center justify-center text-center text-slate-500 gap-2">
              <History size={32} className="text-slate-600" />
              <h4 className="text-sm font-bold text-slate-400">Select a Version Snapshot</h4>
              <p className="text-xs max-w-sm">
                Click &quot;Compare Diff&quot; on any previous snapshot to view side-by-side requirement mutations and schema evolution.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
