/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ApiEndpoint, FullBlueprint } from '../../types/blueprint';
import { Globe, Download, Copy, Check, Lock, Unlock, ShieldAlert, Code2 } from 'lucide-react';
import { ExportService } from '../../services/exportService';

interface ApiBlueprintViewProps {
  blueprint: FullBlueprint;
  onUpdateEndpoints?: (endpoints: ApiEndpoint[]) => void;
}

export const ApiBlueprintView: React.FC<ApiBlueprintViewProps> = ({ blueprint }) => {
  const [selectedEndpointId, setSelectedEndpointId] = useState<string>(blueprint.apiEndpoints[0]?.id || '');
  const [activeTab, setActiveTab] = useState<'endpoints' | 'openapi'>('endpoints');
  const [copiedOpenApi, setCopiedOpenApi] = useState(false);

  const selectedEndpoint = blueprint.apiEndpoints.find(a => a.id === selectedEndpointId) || blueprint.apiEndpoints[0];

  const openApiJson = ExportService.generateOpenApiJson(blueprint);

  const handleCopyOpenApi = () => {
    navigator.clipboard.writeText(openApiJson);
    setCopiedOpenApi(true);
    setTimeout(() => setCopiedOpenApi(false), 2000);
  };

  const handleDownloadOpenApi = () => {
    ExportService.downloadFile('openapi.json', openApiJson, 'application/json');
  };

  const methodColors: Record<string, string> = {
    GET: 'bg-blue-950 text-blue-300 border-blue-800',
    POST: 'bg-emerald-950 text-emerald-300 border-emerald-800',
    PUT: 'bg-amber-950 text-amber-300 border-amber-800',
    PATCH: 'bg-purple-950 text-purple-300 border-purple-800',
    DELETE: 'bg-rose-950 text-rose-300 border-rose-800'
  };

  return (
    <div className="flex flex-col gap-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2.5 mb-1">
            <Globe size={18} className="text-emerald-400" />
            <h3 className="text-base font-bold text-white">RESTful API Blueprint &amp; OpenAPI 3.0 Specification</h3>
          </div>
          <p className="text-xs text-slate-400">
            Validated HTTP endpoints with request/response schemas, RBAC authentication, and error codes linked to REQ-xxx.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyOpenApi}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 transition"
          >
            {copiedOpenApi ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
            <span>{copiedOpenApi ? 'Copied' : 'Copy OpenAPI JSON'}</span>
          </button>
          <button
            onClick={handleDownloadOpenApi}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shadow-md transition"
          >
            <Download size={13} />
            <span>Download openapi.json</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('endpoints')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
            activeTab === 'endpoints' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Globe size={14} />
          <span>API Endpoints ({blueprint.apiEndpoints.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('openapi')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition ${
            activeTab === 'openapi' ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Code2 size={14} />
          <span>OpenAPI 3.0 Document</span>
        </button>
      </div>

      {/* ENDPOINTS TAB */}
      {activeTab === 'endpoints' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Endpoint List Sidebar */}
          <div className="lg:col-span-1 flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">Endpoints</span>
            {blueprint.apiEndpoints.map(api => (
              <button
                key={api.id}
                onClick={() => setSelectedEndpointId(api.id)}
                className={`p-3 rounded-xl border text-left transition flex flex-col gap-1.5 ${
                  selectedEndpoint?.id === api.id
                    ? 'bg-emerald-950/40 border-emerald-500 text-white shadow-md'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                      methodColors[api.method] || 'bg-slate-800 text-slate-300'
                    }`}
                  >
                    {api.method}
                  </span>
                  <span className="font-mono text-[10px] text-slate-500">{api.id}</span>
                </div>
                <div className="font-mono text-xs text-white truncate">{api.path}</div>
                <span className="text-[11px] text-slate-400 line-clamp-1">{api.summary}</span>
              </button>
            ))}
          </div>

          {/* Selected Endpoint Inspector */}
          {selectedEndpoint && (
            <div className="lg:col-span-3 flex flex-col gap-5">
              <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span
                      className={`font-mono text-xs font-bold px-2 py-1 rounded border ${
                        methodColors[selectedEndpoint.method]
                      }`}
                    >
                      {selectedEndpoint.method}
                    </span>
                    <span className="font-mono text-sm font-bold text-white">{selectedEndpoint.path}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-slate-400 bg-slate-800 px-2 py-0.5 rounded border border-slate-700">
                      {selectedEndpoint.id}
                    </span>
                    {selectedEndpoint.authRequired ? (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-300 bg-amber-950/70 border border-amber-800 px-2 py-0.5 rounded">
                        <Lock size={12} />
                        <span>Auth Required</span>
                      </span>
                    ) : (
                      <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-300 bg-emerald-950/70 border border-emerald-800 px-2 py-0.5 rounded">
                        <Unlock size={12} />
                        <span>Public</span>
                      </span>
                    )}
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed">{selectedEndpoint.description}</p>

                {/* Roles and links */}
                <div className="flex flex-wrap items-center gap-4 pt-2 border-t border-slate-800 text-[11px]">
                  <div>
                    <span className="text-slate-500 mr-1.5">Authorized Roles:</span>
                    <strong className="text-purple-300 font-mono">
                      {selectedEndpoint.rolesAllowed.join(', ')}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-500 mr-1.5">Satisfies Reqs:</span>
                    {selectedEndpoint.relatedReqIds.map(rId => (
                      <span key={rId} className="px-1.5 py-0.5 rounded bg-blue-950 text-blue-300 font-mono text-[10px] border border-blue-900 mr-1">
                        {rId}
                      </span>
                    ))}
                  </div>
                  {selectedEndpoint.relatedDbEntityIds && selectedEndpoint.relatedDbEntityIds.length > 0 && (
                    <div>
                      <span className="text-slate-500 mr-1.5">DB Entities:</span>
                      {selectedEndpoint.relatedDbEntityIds.map(dbId => (
                        <span key={dbId} className="px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 font-mono text-[10px] border border-amber-900 mr-1">
                          {dbId}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Request Parameters & Body */}
              {selectedEndpoint.requestBodySchema && (
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col gap-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                    Request Body JSON Schema
                  </span>
                  <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs text-emerald-300 font-mono overflow-x-auto">
                    {selectedEndpoint.requestBodySchema}
                  </pre>
                </div>
              )}

              {/* Status Responses Table */}
              <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
                <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 text-xs font-bold text-slate-400 uppercase tracking-wider">
                  HTTP Response Status Codes &amp; Errors
                </div>
                <div className="divide-y divide-slate-800">
                  {selectedEndpoint.responses.map(resp => (
                    <div key={resp.statusCode} className="p-4 flex items-start gap-3">
                      <span
                        className={`font-mono text-xs font-bold px-2 py-0.5 rounded border shrink-0 ${
                          resp.statusCode >= 200 && resp.statusCode < 300
                            ? 'bg-emerald-950 text-emerald-300 border-emerald-800'
                            : resp.statusCode >= 400 && resp.statusCode < 500
                            ? 'bg-amber-950 text-amber-300 border-amber-800'
                            : 'bg-rose-950 text-rose-300 border-rose-800'
                        }`}
                      >
                        {resp.statusCode}
                      </span>
                      <div className="flex-1">
                        <div className="text-xs font-bold text-white mb-0.5">{resp.description}</div>
                        {resp.schema && (
                          <pre className="text-[11px] text-slate-400 font-mono bg-slate-950 p-2 rounded border border-slate-800 mt-1 overflow-x-auto">
                            {resp.schema}
                          </pre>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Error cases */}
              {selectedEndpoint.errorCases && selectedEndpoint.errorCases.length > 0 && (
                <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col gap-2">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <ShieldAlert size={14} className="text-amber-400" />
                    <span>Explicit Error Handlers</span>
                  </span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-1">
                    {selectedEndpoint.errorCases.map((err, idx) => (
                      <div key={idx} className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-xs flex flex-col gap-1">
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-rose-400 font-bold">{err.code}</span>
                          <span className="font-mono text-[10px] text-slate-500">HTTP {err.statusCode}</span>
                        </div>
                        <span className="text-slate-300">{err.message}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* OPENAPI TAB */}
      {activeTab === 'openapi' && (
        <div className="rounded-xl bg-slate-900 border border-slate-800 overflow-hidden">
          <div className="px-4 py-2.5 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
            <span className="text-xs font-mono text-slate-400">OpenAPI 3.0.0 Specification Output</span>
            <button onClick={handleCopyOpenApi} className="text-xs text-blue-400 hover:text-white flex items-center gap-1">
              <Copy size={12} />
              <span>Copy</span>
            </button>
          </div>
          <pre className="p-5 text-xs text-emerald-300 font-mono overflow-x-auto bg-slate-950/70 leading-relaxed max-h-[500px]">
            {openApiJson}
          </pre>
        </div>
      )}
    </div>
  );
};
