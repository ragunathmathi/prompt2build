/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { ClarificationQuestion, Project } from '../../types/blueprint';
import { GeminiService, DiscoveryResult } from '../../services/geminiService';
import { Sparkles, ArrowRight, HelpCircle, Check, SkipForward, Layers, Cpu, Compass } from 'lucide-react';

interface RequirementDiscoveryViewProps {
  onBlueprintGenerated: (newProject: Project) => void;
  activeProject?: Project;
}

const PRESET_IDEAS = [
  {
    title: 'College Attendance Management System',
    prompt: 'Create a college attendance management system where teachers mark attendance for course sections, and students view their daily attendance and cumulative percentage with threshold warnings.'
  },
  {
    title: 'E-Commerce Order Fulfillment & Inventory',
    prompt: 'Build an e-commerce order fulfillment platform where buyers place orders, inventory stock is locked atomically during checkout, payments trigger packing slips, and shipment tracking updates via webhooks.'
  },
  {
    title: 'Telemedicine Patient Consultation Portal',
    prompt: 'A HIPAA-compliant telemedicine platform where patients book consultations with doctors, join video sessions, and receive digital prescriptions stored securely in an electronic health record.'
  }
];

export const RequirementDiscoveryView: React.FC<RequirementDiscoveryViewProps> = ({
  onBlueprintGenerated,
  activeProject
}) => {
  const [prompt, setPrompt] = useState(activeProject?.description || '');
  const [projectTitle, setProjectTitle] = useState(activeProject?.name || '');
  const [step, setStep] = useState<'input' | 'clarifications' | 'generating'>('input');
  const [isDiscovering, setIsDiscovering] = useState(false);
  const [discoveryData, setDiscoveryData] = useState<DiscoveryResult | null>(null);
  const [clarifications, setClarifications] = useState<ClarificationQuestion[]>([]);
  const [generationProgress, setGenerationProgress] = useState<string>('');

  const handleStartDiscovery = async () => {
    if (!prompt.trim()) return;
    setIsDiscovering(true);

    try {
      const data = await GeminiService.discoverRequirements(prompt);
      setDiscoveryData(data);
      if (!projectTitle) {
        setProjectTitle(data.projectTitle);
      }

      const formattedQuestions: ClarificationQuestion[] = data.clarificationQuestions.map(q => ({
        ...q,
        category: (q.category as any) || 'business_rule',
        selectedOption: q.assumedDefault,
        isSkipped: false
      }));

      setClarifications(formattedQuestions);
      setStep('clarifications');
    } catch (e) {
      console.error(e);
    } finally {
      setIsDiscovering(false);
    }
  };

  const handleSelectOption = (questionId: string, option: string) => {
    setClarifications(prev =>
      prev.map(q => (q.id === questionId ? { ...q, selectedOption: option, isSkipped: false } : q))
    );
  };

  const handleSkipQuestion = (questionId: string) => {
    setClarifications(prev =>
      prev.map(q => (q.id === questionId ? { ...q, isSkipped: true, selectedOption: q.assumedDefault } : q))
    );
  };

  const handleGenerateFinalBlueprint = async () => {
    setStep('generating');
    setGenerationProgress('Executing Stage 1: Role Analysis & Formal Requirements Decomposition...');

    try {
      setTimeout(() => {
        setGenerationProgress('Executing Stage 2: Layered Architecture & Mermaid Flowchart Synthesis...');
      }, 700);

      setTimeout(() => {
        setGenerationProgress('Executing Stage 3: Relational Database Schema & Foreign Key Constraints...');
      }, 1400);

      setTimeout(() => {
        setGenerationProgress('Executing Stage 4: RESTful API Endpoint Definitions & OpenAPI Schemas...');
      }, 2100);

      setTimeout(() => {
        setGenerationProgress('Executing Stage 5: Verification Matrix, Test Cases, & TraceSpec Graph Verification...');
      }, 2800);

      const blueprint = await GeminiService.generateBlueprint({
        projectId: activeProject?.id || `proj-${Date.now()}`,
        projectTitle: projectTitle || 'Verified Software System',
        prompt,
        clarifications
      });

      const newProject: Project = {
        id: blueprint.projectId,
        name: projectTitle || blueprint.overview.title,
        description: prompt,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'verified',
        currentVersion: 'v1.0',
        tags: ['Verified', 'TraceSpec'],
        clarifications,
        blueprint
      };

      setTimeout(() => {
        onBlueprintGenerated(newProject);
      }, 3500);
    } catch (err) {
      console.error(err);
      setStep('clarifications');
    }
  };

  return (
    <div className="flex flex-col gap-6 max-w-5xl mx-auto">
      {/* Top Stepper Indicator */}
      <div className="flex items-center justify-between p-4 rounded-xl bg-slate-900 border border-slate-800">
        <div className="flex items-center gap-3">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
              step === 'input' ? 'bg-blue-600 text-white' : 'bg-emerald-600 text-white'
            }`}
          >
            1
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Natural Language Idea</span>
            <span className="text-[11px] text-slate-400">Describe the software vision</span>
          </div>
        </div>

        <ArrowRight size={16} className="text-slate-600" />

        <div className="flex items-center gap-3">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
              step === 'clarifications'
                ? 'bg-blue-600 text-white'
                : step === 'generating'
                ? 'bg-emerald-600 text-white'
                : 'bg-slate-800 text-slate-400'
            }`}
          >
            2
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Smart Clarification</span>
            <span className="text-[11px] text-slate-400">Resolve missing roles &amp; rules</span>
          </div>
        </div>

        <ArrowRight size={16} className="text-slate-600" />

        <div className="flex items-center gap-3">
          <div
            className={`w-7 h-7 rounded-full flex items-center justify-center font-bold text-xs ${
              step === 'generating' ? 'bg-blue-600 text-white animate-pulse' : 'bg-slate-800 text-slate-400'
            }`}
          >
            3
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Verified Blueprint</span>
            <span className="text-[11px] text-slate-400">TraceSpec validation &amp; export</span>
          </div>
        </div>
      </div>

      {/* STEP 1: Natural Language Input */}
      {step === 'input' && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Compass size={18} className="text-blue-400" />
              <h3 className="text-base font-bold text-white">Enter Your Software Concept</h3>
            </div>
            <p className="text-xs text-slate-400">
              Prompt2Blueprint will parse your natural language input, identify missing stakeholder roles,
              detect potential ambiguities, and construct an end-to-end verifiable specification.
            </p>
          </div>

          <div className="flex flex-col gap-3">
            <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Project Description / Problem Statement
            </label>
            <textarea
              rows={5}
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="e.g. Create a college attendance management system where teachers mark attendance for course sections and students view their percentage with 75% warnings..."
              className="w-full p-4 rounded-xl bg-slate-950 border border-slate-700 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-sans leading-relaxed resize-y"
            />
          </div>

          {/* Preset Prompts */}
          <div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
              Or Select A Sample Academic Scenario:
            </span>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {PRESET_IDEAS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setPrompt(preset.prompt);
                    setProjectTitle(preset.title);
                  }}
                  className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-blue-500/80 hover:bg-slate-800/60 text-left transition flex flex-col justify-between gap-2"
                >
                  <span className="text-xs font-bold text-slate-200">{preset.title}</span>
                  <span className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                    {preset.prompt}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              onClick={handleStartDiscovery}
              disabled={isDiscovering || !prompt.trim()}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-blue-600/30 transition cursor-pointer"
            >
              {isDiscovering ? <Cpu size={16} className="animate-spin" /> : <Sparkles size={16} />}
              <span>{isDiscovering ? 'Analyzing Requirements...' : 'Run Smart Discovery & Clarify'}</span>
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Clarification Questions */}
      {step === 'clarifications' && (
        <div className="flex flex-col gap-6">
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span>Smart Requirement Discovery Findings</span>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800">
                    Ambiguities Isolated
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  The AI discovered potential specification gaps. Select your preferences or accept labelled defaults.
                </p>
              </div>

              <button
                onClick={() => setStep('input')}
                className="text-xs text-slate-400 hover:text-white underline"
              >
                Edit Description
              </button>
            </div>

            {/* Project Title Field */}
            <div>
              <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1">
                Project Title
              </label>
              <input
                type="text"
                value={projectTitle}
                onChange={e => setProjectTitle(e.target.value)}
                className="w-full px-4 py-2 rounded-lg bg-slate-950 border border-slate-700 text-sm text-white focus:outline-none focus:border-blue-500"
              />
            </div>

            {/* Questions list */}
            <div className="flex flex-col gap-4 mt-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Clarification Questions ({clarifications.length})
              </span>

              {clarifications.map((q, idx) => (
                <div key={q.id} className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-blue-950 text-blue-400 font-mono text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5 border border-blue-800">
                        {idx + 1}
                      </span>
                      <div>
                        <h4 className="text-xs font-bold text-white">{q.question}</h4>
                        <p className="text-[11px] text-slate-400 mt-0.5">{q.explanation}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => handleSkipQuestion(q.id)}
                      className={`text-[11px] px-2.5 py-1 rounded-md border font-medium transition flex items-center gap-1 shrink-0 ${
                        q.isSkipped
                          ? 'bg-amber-950/60 border-amber-800 text-amber-300'
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      <SkipForward size={12} />
                      <span>{q.isSkipped ? 'Assumed Default' : 'Skip & Assume'}</span>
                    </button>
                  </div>

                  {/* Multiple choice options */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 pt-1">
                    {q.options.map((opt, optIdx) => {
                      const isSelected = q.selectedOption === opt && !q.isSkipped;
                      return (
                        <button
                          key={optIdx}
                          type="button"
                          onClick={() => handleSelectOption(q.id, opt)}
                          className={`p-2.5 rounded-lg border text-left text-xs transition flex items-start gap-2 ${
                            isSelected
                              ? 'bg-blue-600/20 border-blue-500 text-blue-200 font-medium'
                              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          <span
                            className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0 mt-0.5 ${
                              isSelected ? 'border-blue-400 bg-blue-500' : 'border-slate-600'
                            }`}
                          >
                            {isSelected && <Check size={10} className="text-white" />}
                          </span>
                          <span className="leading-snug">{opt}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-slate-800">
              <button
                onClick={() => setStep('input')}
                className="px-4 py-2 rounded-lg border border-slate-700 text-slate-400 hover:text-white text-xs font-semibold"
              >
                Back to Idea
              </button>
              <button
                onClick={handleGenerateFinalBlueprint}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-600/30 transition cursor-pointer"
              >
                <Layers size={15} />
                <span>Generate Verified Software Blueprint</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* STEP 3: Multi-Stage Generation Progress */}
      {step === 'generating' && (
        <div className="p-12 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col items-center justify-center text-center gap-5">
          <div className="relative">
            <div className="w-16 h-16 rounded-full border-4 border-blue-500/20 border-t-blue-500 animate-spin"></div>
            <Sparkles size={24} className="text-blue-400 absolute inset-0 m-auto" />
          </div>

          <div className="space-y-2">
            <h3 className="text-base font-bold text-white">Synthesizing Verified Specification</h3>
            <p className="text-xs text-blue-400 font-mono transition-all duration-300">
              {generationProgress}
            </p>
          </div>

          <div className="w-full max-w-md bg-slate-950 p-4 rounded-xl border border-slate-800 text-left font-mono text-[11px] text-slate-400 space-y-1.5">
            <div className="flex items-center gap-2 text-emerald-400">
              <Check size={13} /> <span>Prompt Engineering Pipeline initialized</span>
            </div>
            <div className="flex items-center gap-2 text-emerald-400">
              <Check size={13} /> <span>Atomic Requirements &amp; User Stories generated</span>
            </div>
            <div className="flex items-center gap-2 text-blue-400 animate-pulse">
              <span>›</span> <span>Synthesizing Architecture &amp; Database Foreign Keys...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
