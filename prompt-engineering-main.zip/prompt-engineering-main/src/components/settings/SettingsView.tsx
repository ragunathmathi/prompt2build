/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { PromptPipelineService } from '../../services/promptPipeline';
import { GeminiService } from '../../services/geminiService';
import { Settings, Cpu, FileCode, CheckCircle, ShieldCheck, Terminal, Server } from 'lucide-react';

export const SettingsView: React.FC = () => {
  const [healthStatus, setHealthStatus] = useState<any>(null);
  const [activeTemplateId, setActiveTemplateId] = useState<string>('TPL-DISCOVERY-V1');
  const templates = PromptPipelineService.getTemplates();

  useEffect(() => {
    GeminiService.checkHealth().then(setHealthStatus);
  }, []);

  const activeTemplate = templates.find(t => t.id === activeTemplateId) || templates[0];

  return (
    <div className="flex flex-col gap-6">
      {/* AI Provider Status */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Cpu size={18} className="text-blue-400" />
            <h3 className="text-base font-bold text-white">AI Provider &amp; Model Configuration</h3>
          </div>
          <span className="px-2.5 py-1 rounded text-xs font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>{healthStatus?.aiProvider || 'gemini-3.8-flash'}</span>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Primary Model</span>
              <h4 className="text-sm font-bold text-white font-mono mt-0.5">gemini-3.8-flash</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Server-side execution via @google/genai TypeScript SDK with structured output validation.
              </p>
            </div>
            <div className="text-[10px] text-emerald-400 font-mono mt-3 flex items-center gap-1">
              <CheckCircle size={12} />
              <span>Full-Stack Proxy Active</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Deterministic Demo Mode</span>
              <h4 className="text-sm font-bold text-white font-mono mt-0.5">Built-in Fallback</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Ensures 100% operational reliability for academic demonstrations even without live external API quota.
              </p>
            </div>
            <div className="text-[10px] text-blue-400 font-mono mt-3 flex items-center gap-1">
              <ShieldCheck size={12} />
              <span>Always Available</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Local / Ollama Compatible</span>
              <h4 className="text-sm font-bold text-white font-mono mt-0.5">REST Adapter</h4>
              <p className="text-[11px] text-slate-400 mt-1">
                Configured with standard schema definitions for zero-leakage enterprise environments.
              </p>
            </div>
            <div className="text-[10px] text-slate-500 font-mono mt-3 flex items-center gap-1">
              <Server size={12} />
              <span>Local Bridge Ready</span>
            </div>
          </div>
        </div>
      </div>

      {/* Versioned Prompt Engineering Pipeline */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col gap-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <FileCode size={18} className="text-purple-400" />
            <div>
              <h3 className="text-base font-bold text-white">Prompt Engineering Pipeline &amp; Versioned Templates</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Inspect modular system instructions used to orchestrate task decomposition and structured output generation.
              </p>
            </div>
          </div>
          <span className="text-xs text-slate-400 font-mono">{templates.length} Active Templates</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Template Selector */}
          <div className="flex flex-col gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">Pipeline Stages</span>
            {templates.map(tpl => (
              <button
                key={tpl.id}
                onClick={() => setActiveTemplateId(tpl.id)}
                className={`p-3 rounded-xl border text-left transition flex flex-col gap-1 ${
                  activeTemplate.id === tpl.id
                    ? 'bg-purple-950/40 border-purple-500 text-white shadow-md'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-850'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-purple-300">{tpl.id}</span>
                  <span className="text-[10px] font-mono text-slate-500">v{tpl.version}</span>
                </div>
                <span className="text-xs font-medium text-slate-200 line-clamp-1">{tpl.name}</span>
                <span className="text-[11px] text-slate-500 line-clamp-1">{tpl.description}</span>
              </button>
            ))}
          </div>

          {/* Template Inspector */}
          <div className="md:col-span-2 flex flex-col gap-3">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="font-mono text-xs text-purple-400 font-bold">{activeTemplate.id}</span>
                <h4 className="text-sm font-bold text-white mt-0.5">{activeTemplate.name}</h4>
                <p className="text-xs text-slate-400 mt-1">{activeTemplate.description}</p>
              </div>
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 text-xs font-mono text-slate-300">
                v{activeTemplate.version}
              </span>
            </div>

            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col gap-2">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                System Prompt Template Content
              </span>
              <pre className="p-4 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-200 font-mono leading-relaxed overflow-x-auto whitespace-pre-wrap max-h-72">
                {activeTemplate.template}
              </pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
