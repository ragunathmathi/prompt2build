/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { FullBlueprint } from '../../types/blueprint';
import { TraceSpecEngine } from '../../services/tracespecEngine';
import { ExportService } from '../../services/exportService';
import { Search, Download, Check, AlertTriangle, ShieldCheck, XCircle } from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';

interface TraceMatrixTableProps {
  blueprint: FullBlueprint;
  onSelectRequirement?: (reqId: string) => void;
}

export const TraceMatrixTable: React.FC<TraceMatrixTableProps> = ({ blueprint, onSelectRequirement }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [coverageFilter, setCoverageFilter] = useState<'all' | 'untested' | 'orphaned' | 'complete'>('all');

  const graph = useMemo(() => TraceSpecEngine.buildGraph(blueprint), [blueprint]);

  // Aggregate matrix rows
  const matrixRows = useMemo(() => {
    return blueprint.requirements.map(req => {
      const stories: string[] = [];
      const archs: string[] = [];
      const dbs: string[] = [];
      const apis: string[] = [];
      const tests: string[] = [];
      const tasks: string[] = [];

      graph.edges.forEach(e => {
        if (e.target === req.id) {
          if (e.source.startsWith('US-')) stories.push(e.source);
          else if (e.source.startsWith('ARCH-')) archs.push(e.source);
          else if (e.source.startsWith('DB-')) dbs.push(e.source);
          else if (e.source.startsWith('API-')) apis.push(e.source);
          else if (e.source.startsWith('TEST-')) tests.push(e.source);
          else if (e.source.startsWith('TASK-')) tasks.push(e.source);
        }
      });

      const isSpecCovered = archs.length > 0 || dbs.length > 0 || apis.length > 0;
      const isTestCovered = tests.length > 0;
      const isComplete = isSpecCovered && isTestCovered;
      const isOrphan = !isSpecCovered;

      return {
        req,
        stories,
        archs,
        dbs,
        apis,
        tests,
        tasks,
        isSpecCovered,
        isTestCovered,
        isComplete,
        isOrphan
      };
    });
  }, [blueprint, graph]);

  // Filter rows
  const filteredRows = useMemo(() => {
    return matrixRows.filter(row => {
      const matchesSearch =
        row.req.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.req.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        row.req.category.toLowerCase().includes(searchTerm.toLowerCase());

      if (!matchesSearch) return false;

      if (coverageFilter === 'untested') return !row.isTestCovered;
      if (coverageFilter === 'orphaned') return row.isOrphan;
      if (coverageFilter === 'complete') return row.isComplete;
      return true;
    });
  }, [matrixRows, searchTerm, coverageFilter]);

  const handleExportCsv = () => {
    const csv = ExportService.generateTraceMatrixCsv(blueprint);
    ExportService.downloadFile(`traceability_matrix_${blueprint.projectId}.csv`, csv, 'text/csv');
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 rounded-xl border border-slate-800 overflow-hidden">
      {/* Table Toolbar */}
      <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3 flex-1 min-w-[280px]">
          <div className="relative flex-1 max-w-sm">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              placeholder="Filter by Req ID, title, or category..."
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {/* Quick Filters */}
          <div className="flex items-center rounded-lg border border-slate-700 bg-slate-900 p-0.5 text-xs">
            <button
              onClick={() => setCoverageFilter('all')}
              className={`px-2.5 py-1 rounded-md transition font-medium ${coverageFilter === 'all' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              All ({matrixRows.length})
            </button>
            <button
              onClick={() => setCoverageFilter('untested')}
              className={`px-2.5 py-1 rounded-md transition font-medium ${coverageFilter === 'untested' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Untested ({matrixRows.filter(r => !r.isTestCovered).length})
            </button>
            <button
              onClick={() => setCoverageFilter('orphaned')}
              className={`px-2.5 py-1 rounded-md transition font-medium ${coverageFilter === 'orphaned' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Orphaned ({matrixRows.filter(r => r.isOrphan).length})
            </button>
            <button
              onClick={() => setCoverageFilter('complete')}
              className={`px-2.5 py-1 rounded-md transition font-medium ${coverageFilter === 'complete' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Verified ({matrixRows.filter(r => r.isComplete).length})
            </button>
          </div>
        </div>

        <button
          onClick={handleExportCsv}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs text-slate-200 transition"
        >
          <Download size={13} />
          <span>Export Matrix CSV</span>
        </button>
      </div>

      {/* 2D Matrix Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-950/80 sticky top-0 border-b border-slate-800 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            <tr>
              <th className="py-3 px-4">Requirement</th>
              <th className="py-3 px-3">Type / Priority</th>
              <th className="py-3 px-3">Architecture</th>
              <th className="py-3 px-3">Database</th>
              <th className="py-3 px-3">API Endpoints</th>
              <th className="py-3 px-3">Test Cases</th>
              <th className="py-3 px-4 text-center">Spec Covered</th>
              <th className="py-3 px-4 text-center">Test Covered</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {filteredRows.map(row => (
              <tr
                key={row.req.id}
                onClick={() => onSelectRequirement && onSelectRequirement(row.req.id)}
                className="hover:bg-slate-800/40 transition cursor-pointer"
              >
                {/* Requirement Info */}
                <td className="py-3 px-4 font-sans max-w-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-blue-400 text-xs">{row.req.id}</span>
                    <span className="text-slate-200 font-medium truncate">{row.req.title}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">{row.req.category}</div>
                </td>

                {/* Type & Priority */}
                <td className="py-3 px-3">
                  <div className="flex flex-col gap-1">
                    <StatusBadge label={row.req.type} variant="type" />
                    <StatusBadge label={row.req.priority} variant="priority" />
                  </div>
                </td>

                {/* Architecture components */}
                <td className="py-3 px-3">
                  {row.archs.length === 0 ? (
                    <span className="text-slate-600 text-[11px]">-</span>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {row.archs.map(id => (
                        <span key={id} className="px-1.5 py-0.5 rounded bg-sky-950 border border-sky-800/60 text-sky-300 text-[10px]">
                          {id}
                        </span>
                      ))}
                    </div>
                  )}
                </td>

                {/* Database entities */}
                <td className="py-3 px-3">
                  {row.dbs.length === 0 ? (
                    <span className="text-slate-600 text-[11px]">-</span>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {row.dbs.map(id => (
                        <span key={id} className="px-1.5 py-0.5 rounded bg-amber-950 border border-amber-800/60 text-amber-300 text-[10px]">
                          {id}
                        </span>
                      ))}
                    </div>
                  )}
                </td>

                {/* API endpoints */}
                <td className="py-3 px-3">
                  {row.apis.length === 0 ? (
                    <span className="text-slate-600 text-[11px]">-</span>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {row.apis.map(id => (
                        <span key={id} className="px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-800/60 text-emerald-300 text-[10px]">
                          {id}
                        </span>
                      ))}
                    </div>
                  )}
                </td>

                {/* Test cases */}
                <td className="py-3 px-3">
                  {row.tests.length === 0 ? (
                    <span className="text-rose-400 font-sans text-[11px] flex items-center gap-1">
                      <AlertTriangle size={11} /> None
                    </span>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {row.tests.map(id => (
                        <span key={id} className="px-1.5 py-0.5 rounded bg-purple-950 border border-purple-800/60 text-purple-300 text-[10px]">
                          {id}
                        </span>
                      ))}
                    </div>
                  )}
                </td>

                {/* Spec Covered status */}
                <td className="py-3 px-4 text-center font-sans">
                  {row.isSpecCovered ? (
                    <span className="inline-flex items-center gap-1 text-emerald-400 text-xs font-semibold">
                      <Check size={14} /> Yes
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-rose-400 text-xs font-semibold">
                      <XCircle size={14} /> No
                    </span>
                  )}
                </td>

                {/* Test Covered status */}
                <td className="py-3 px-4 text-center font-sans">
                  {row.isTestCovered ? (
                    <span className="inline-flex items-center gap-1 text-emerald-400 text-xs font-semibold">
                      <ShieldCheck size={14} /> Yes
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-amber-400 text-xs font-semibold">
                      <AlertTriangle size={14} /> Missing
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {filteredRows.length === 0 && (
          <div className="p-8 text-center text-slate-500 text-xs">
            No requirements match the active filter criteria.
          </div>
        )}
      </div>
    </div>
  );
};
