/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { TraceGraph, TraceNode, TraceEdge, TraceNodeType } from '../../types/blueprint';
import { ZoomIn, ZoomOut, RefreshCw, Filter, Layers, Database, Globe, CheckCircle2, FileText, CheckSquare, AlertCircle } from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';

interface TraceGraphViewerProps {
  graph: TraceGraph;
  onSelectNode?: (node: TraceNode) => void;
  selectedNodeId?: string | null;
}

const NODE_COLORS: Record<TraceNodeType, { bg: string; border: string; text: string; icon: any }> = {
  requirement: { bg: 'bg-indigo-950/80', border: 'border-indigo-500', text: 'text-indigo-300', icon: FileText },
  user_story: { bg: 'bg-cyan-950/80', border: 'border-cyan-500', text: 'text-cyan-300', icon: Layers },
  architecture: { bg: 'bg-sky-950/80', border: 'border-sky-500', text: 'text-sky-300', icon: Layers },
  database: { bg: 'bg-amber-950/80', border: 'border-amber-500', text: 'text-amber-300', icon: Database },
  api: { bg: 'bg-emerald-950/80', border: 'border-emerald-500', text: 'text-emerald-300', icon: Globe },
  test_case: { bg: 'bg-purple-950/80', border: 'border-purple-500', text: 'text-purple-300', icon: CheckCircle2 },
  task: { bg: 'bg-slate-800/80', border: 'border-slate-500', text: 'text-slate-300', icon: CheckSquare }
};

export const TraceGraphViewer: React.FC<TraceGraphViewerProps> = ({
  graph,
  onSelectNode,
  selectedNodeId: externalSelectedNodeId
}) => {
  const [internalSelectedId, setInternalSelectedId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [filterTypes, setFilterTypes] = useState<Record<TraceNodeType, boolean>>({
    requirement: true,
    user_story: true,
    architecture: true,
    database: true,
    api: true,
    test_case: true,
    task: true
  });

  const selectedId = externalSelectedNodeId !== undefined ? externalSelectedNodeId : internalSelectedId;

  // Filter nodes
  const visibleNodes = useMemo(() => {
    return graph.nodes.filter(n => filterTypes[n.type]);
  }, [graph.nodes, filterTypes]);

  const visibleNodeIds = useMemo(() => new Set(visibleNodes.map(n => n.id)), [visibleNodes]);

  // Filter edges
  const visibleEdges = useMemo(() => {
    return graph.edges.filter(e => visibleNodeIds.has(e.source) && visibleNodeIds.has(e.target));
  }, [graph.edges, visibleNodeIds]);

  // Layout algorithm: Arrange nodes by columns based on node type
  const columns: { type: TraceNodeType; title: string; nodes: TraceNode[] }[] = useMemo(() => {
    const cols: Record<TraceNodeType, TraceNode[]> = {
      requirement: [],
      user_story: [],
      architecture: [],
      database: [],
      api: [],
      test_case: [],
      task: []
    };

    visibleNodes.forEach(node => {
      if (cols[node.type]) {
        cols[node.type].push(node);
      }
    });

    const result: { type: TraceNodeType; title: string; nodes: TraceNode[] }[] = [
      { type: 'requirement', title: 'Requirements', nodes: cols.requirement },
      { type: 'user_story', title: 'User Stories', nodes: cols.user_story },
      { type: 'architecture', title: 'Architecture', nodes: cols.architecture },
      { type: 'database', title: 'Database Entities', nodes: cols.database },
      { type: 'api', title: 'API Endpoints', nodes: cols.api },
      { type: 'test_case', title: 'Test Cases', nodes: cols.test_case },
      { type: 'task', title: 'Tasks', nodes: cols.task }
    ];

    return result.filter(c => filterTypes[c.type]);
  }, [visibleNodes, filterTypes]);

  const selectedNode = useMemo(() => {
    return graph.nodes.find(n => n.id === selectedId) || null;
  }, [graph.nodes, selectedId]);

  // Edges related to selected node
  const activeEdges = useMemo(() => {
    if (!selectedId) return [];
    return visibleEdges.filter(e => e.source === selectedId || e.target === selectedId);
  }, [visibleEdges, selectedId]);

  const connectedNodeIds = useMemo(() => {
    const ids = new Set<string>();
    activeEdges.forEach(e => {
      ids.add(e.source);
      ids.add(e.target);
    });
    return ids;
  }, [activeEdges]);

  const toggleFilter = (type: TraceNodeType) => {
    setFilterTypes(prev => ({ ...prev, [type]: !prev[type] }));
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 rounded-xl border border-slate-800 overflow-hidden">
      {/* Control bar */}
      <div className="p-3 border-b border-slate-800 bg-slate-900/90 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Filter size={15} className="text-slate-400" />
          <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">Node Layers:</span>
          {(Object.keys(filterTypes) as TraceNodeType[]).map(type => {
            const active = filterTypes[type];
            return (
              <button
                key={type}
                onClick={() => toggleFilter(type)}
                className={`text-[11px] px-2.5 py-1 rounded-md border font-medium transition flex items-center gap-1.5 ${
                  active
                    ? `${NODE_COLORS[type].bg} ${NODE_COLORS[type].border} ${NODE_COLORS[type].text}`
                    : 'bg-slate-800/40 text-slate-500 border-slate-700/50'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${active ? 'bg-current' : 'bg-slate-600'}`}></span>
                {type.replace('_', ' ')}
              </button>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">
            {visibleNodes.length} nodes · {visibleEdges.length} edges
          </span>
          <div className="h-4 w-px bg-slate-700 mx-1"></div>
          <button
            onClick={() => setZoom(z => Math.max(0.6, z - 0.1))}
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="Zoom Out"
          >
            <ZoomOut size={15} />
          </button>
          <span className="text-[11px] font-mono text-slate-400 w-10 text-center">{Math.round(zoom * 100)}%</span>
          <button
            onClick={() => setZoom(z => Math.min(1.5, z + 0.1))}
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="Zoom In"
          >
            <ZoomIn size={15} />
          </button>
          <button
            onClick={() => setZoom(1)}
            className="p-1.5 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
            title="Reset Zoom"
          >
            <RefreshCw size={15} />
          </button>
        </div>
      </div>

      {/* Main graph canvas & Selected Node Inspector */}
      <div className="flex-1 flex overflow-hidden">
        {/* Canvas Area */}
        <div className="flex-1 overflow-auto p-6 bg-radial from-slate-900/60 to-slate-950">
          <div
            style={{ transform: `scale(${zoom})`, transformOrigin: 'top left' }}
            className="flex gap-8 min-w-max pb-12 transition-transform duration-100"
          >
            {columns.map(col => (
              <div key={col.type} className="flex flex-col gap-3 min-w-[220px] max-w-[260px]">
                {/* Column header */}
                <div className="flex items-center justify-between pb-2 border-b border-slate-800 px-1">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <span className={`w-2 h-2 rounded-full ${NODE_COLORS[col.type].border.replace('border-', 'bg-')}`}></span>
                    {col.title}
                  </span>
                  <span className="text-[11px] text-slate-500 font-mono">{col.nodes.length}</span>
                </div>

                {/* Nodes list */}
                <div className="flex flex-col gap-2.5">
                  {col.nodes.map(node => {
                    const isSelected = selectedId === node.id;
                    const isConnected = connectedNodeIds.has(node.id);
                    const isMuted = selectedId && !isSelected && !isConnected;

                    return (
                      <div
                        key={node.id}
                        onClick={() => {
                          const newId = isSelected ? null : node.id;
                          setInternalSelectedId(newId);
                          if (onSelectNode) {
                            onSelectNode(isSelected ? (null as any) : node);
                          }
                        }}
                        className={`p-3 rounded-lg border cursor-pointer transition-all duration-150 flex flex-col gap-1.5 ${
                          isSelected
                            ? 'ring-2 ring-white border-white bg-slate-800 shadow-xl shadow-blue-950/50'
                            : isConnected
                            ? `${NODE_COLORS[node.type].bg} ${NODE_COLORS[node.type].border} ring-1 ring-blue-400/50`
                            : isMuted
                            ? 'opacity-35 bg-slate-900/40 border-slate-800'
                            : `${NODE_COLORS[node.type].bg} border-slate-700/80 hover:border-slate-500 hover:bg-slate-850`
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white font-mono">{node.label}</span>
                          <StatusBadge label={node.status || node.category || node.type} />
                        </div>
                        <p className="text-[11px] text-slate-300 line-clamp-2 leading-relaxed">
                          {node.subLabel}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Node Details Drawer */}
        {selectedNode && (
          <div className="w-80 border-l border-slate-800 bg-slate-900/95 p-5 flex flex-col justify-between overflow-y-auto">
            <div>
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Node Inspector</span>
                <button
                  onClick={() => {
                    setInternalSelectedId(null);
                    if (onSelectNode) onSelectNode(null as any);
                  }}
                  className="text-slate-400 hover:text-white text-xs px-2 py-0.5 rounded bg-slate-800"
                >
                  Close
                </button>
              </div>

              <div className="flex items-center gap-2 mb-2">
                <span className="text-sm font-bold text-white font-mono">{selectedNode.label}</span>
                <StatusBadge label={selectedNode.type} variant="type" />
              </div>

              <div className="text-xs text-slate-300 font-medium mb-4 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                {selectedNode.subLabel}
              </div>

              {/* Connected Relationships */}
              <div className="mb-4">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                  Traceability Links ({activeEdges.length})
                </span>
                <div className="flex flex-col gap-2 max-h-60 overflow-y-auto pr-1">
                  {activeEdges.length === 0 ? (
                    <div className="p-2.5 rounded bg-rose-950/30 border border-rose-800/60 text-rose-300 text-xs flex items-center gap-1.5">
                      <AlertCircle size={14} />
                      <span>Orphan Node: No linked technical artifacts or tests.</span>
                    </div>
                  ) : (
                    activeEdges.map(edge => {
                      const isIncoming = edge.target === selectedNode.id;
                      const otherNodeId = isIncoming ? edge.source : edge.target;
                      const otherNode = graph.nodes.find(n => n.id === otherNodeId);

                      return (
                        <div
                          key={edge.id}
                          className="p-2 rounded bg-slate-950/70 border border-slate-800 flex flex-col gap-1 text-[11px]"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-blue-400 font-semibold">{otherNodeId}</span>
                            <span className="text-[10px] text-slate-500 uppercase">{edge.type}</span>
                          </div>
                          <span className="text-slate-400 line-clamp-1">
                            {otherNode?.subLabel || otherNode?.label || otherNodeId}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Raw attributes */}
              {selectedNode.data && (
                <div>
                  <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                    Properties
                  </span>
                  <pre className="text-[10px] bg-slate-950 p-2.5 rounded border border-slate-800 text-slate-400 overflow-x-auto font-mono max-h-40">
                    {JSON.stringify(selectedNode.data, null, 2)}
                  </pre>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
