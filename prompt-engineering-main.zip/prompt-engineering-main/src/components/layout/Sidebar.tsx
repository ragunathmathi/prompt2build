/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  Compass,
  FileText,
  Layers,
  Database,
  Globe,
  CheckCircle2,
  GitBranch,
  Table,
  ShieldAlert,
  ShieldCheck,
  History,
  Download,
  Award,
  Settings
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  unresolvedCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, onSelectTab, unresolvedCount = 0 }) => {
  const navSections = [
    {
      title: 'Core Specification',
      items: [
        { id: 'dashboard', label: 'Overview & Scope', icon: LayoutDashboard },
        { id: 'discovery', label: 'Requirement Discovery', icon: Compass },
        { id: 'requirements', label: 'Requirements & Stories', icon: FileText },
        { id: 'architecture', label: 'Architecture Designer', icon: Layers },
        { id: 'database', label: 'Database Blueprint', icon: Database },
        { id: 'api', label: 'REST API & OpenAPI', icon: Globe },
        { id: 'testing', label: 'Verification & Test Suite', icon: CheckCircle2 }
      ]
    },
    {
      title: 'TraceSpec Engine (Innovation)',
      items: [
        { id: 'graph', label: 'Traceability Graph', icon: GitBranch, badge: 'Live' },
        { id: 'matrix', label: '2D Traceability Matrix', icon: Table },
        { id: 'impact', label: 'Change Impact Analysis', icon: ShieldAlert },
        {
          id: 'validation',
          label: 'Specification Validation',
          icon: ShieldCheck,
          badge: unresolvedCount > 0 ? `${unresolvedCount} issues` : undefined,
          badgeColor: unresolvedCount > 0 ? 'bg-amber-950 text-amber-300 border-amber-800' : undefined
        }
      ]
    },
    {
      title: 'Management & Research',
      items: [
        { id: 'versioning', label: 'Versioning & Timeline', icon: History },
        { id: 'export', label: 'Export & Package Center', icon: Download },
        { id: 'evaluation', label: 'Research Benchmark Suite', icon: Award, badge: 'Eval' },
        { id: 'settings', label: 'Prompt Pipeline & Settings', icon: Settings }
      ]
    }
  ];

  return (
    <aside className="w-64 border-r border-slate-800 bg-slate-950/70 p-4 flex flex-col justify-between overflow-y-auto shrink-0 select-none">
      <div className="space-y-6">
        {navSections.map((section, sIdx) => (
          <div key={sIdx} className="space-y-1.5">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-3 block">
              {section.title}
            </span>
            <div className="space-y-1">
              {section.items.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition cursor-pointer ${
                      isActive
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-600/20'
                        : 'text-slate-400 hover:text-white hover:bg-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon size={16} className={isActive ? 'text-white' : 'text-slate-400'} />
                      <span className="truncate">{item.label}</span>
                    </div>

                    {item.badge && (
                      <span
                        className={`text-[9px] font-mono px-1.5 py-0.5 rounded border ${
                          item.badgeColor || (isActive ? 'bg-blue-700 text-white border-blue-500' : 'bg-slate-900 text-slate-400 border-slate-700')
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer Info */}
      <div className="pt-4 border-t border-slate-800/80 text-[10px] text-slate-500 flex flex-col gap-1 px-1">
        <div className="flex items-center justify-between font-mono">
          <span>TraceSpec Engine</span>
          <span className="text-emerald-400">Deterministic</span>
        </div>
        <span>Final-Year Academic Framework</span>
      </div>
    </aside>
  );
};
