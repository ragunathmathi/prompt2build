/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Project } from '../../types/blueprint';
import { GeminiService } from '../../services/geminiService';
import { Sparkles, Plus, FolderGit2, CheckCircle2, ChevronDown, Cpu, ShieldCheck } from 'lucide-react';

interface NavbarProps {
  projects: Project[];
  activeProject: Project;
  onSelectProject: (projectId: string) => void;
  onNewProject: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  projects,
  activeProject,
  onSelectProject,
  onNewProject
}) => {
  const [healthStatus, setHealthStatus] = useState<any>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    GeminiService.checkHealth().then(setHealthStatus);
  }, []);

  return (
    <header className="h-16 border-b border-slate-800 bg-slate-950/90 backdrop-blur-md px-6 flex items-center justify-between sticky top-0 z-40 select-none">
      {/* Brand Identity */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-blue-500/20 text-white font-bold">
          <Sparkles size={18} />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-base font-extrabold tracking-tight text-white">Prompt2Blueprint</span>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-blue-500/20 text-blue-300 border border-blue-500/30">
              TraceSpec Engine
            </span>
          </div>
          <span className="text-[11px] text-slate-400 block -mt-0.5">
            Verified Software Specification &amp; Traceability Framework
          </span>
        </div>
      </div>

      {/* Center: Project Switcher */}
      <div className="relative">
        <button
          onClick={() => setIsDropdownOpen(!isDropdownOpen)}
          className="flex items-center gap-2.5 px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 transition"
        >
          <FolderGit2 size={15} className="text-blue-400" />
          <div className="text-left">
            <span className="text-xs font-bold text-white block max-w-[200px] truncate">
              {activeProject?.name || 'Select Project'}
            </span>
            <span className="text-[10px] text-slate-400 font-mono block">
              {activeProject?.currentVersion || 'v1.0'} · {activeProject?.status || 'active'}
            </span>
          </div>
          <ChevronDown size={14} className="text-slate-400 ml-1" />
        </button>

        {isDropdownOpen && (
          <div className="absolute left-1/2 -translate-x-1/2 mt-2 w-72 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl py-2 z-50">
            <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-800">
              Switch Project
            </div>
            <div className="max-h-56 overflow-y-auto py-1">
              {projects.map(p => (
                <button
                  key={p.id}
                  onClick={() => {
                    onSelectProject(p.id);
                    setIsDropdownOpen(false);
                  }}
                  className={`w-full px-3 py-2 text-left text-xs flex items-center justify-between hover:bg-slate-800/80 transition ${
                    activeProject.id === p.id ? 'bg-blue-600/20 text-blue-300 font-bold' : 'text-slate-300'
                  }`}
                >
                  <span className="truncate">{p.name}</span>
                  <span className="font-mono text-[10px] text-slate-500">{p.currentVersion}</span>
                </button>
              ))}
            </div>
            <div className="pt-2 px-2 border-t border-slate-800">
              <button
                onClick={() => {
                  setIsDropdownOpen(false);
                  onNewProject();
                }}
                className="w-full flex items-center justify-center gap-1.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition"
              >
                <Plus size={13} />
                <span>Create New Project</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Right Controls: AI Provider status + New Project CTA */}
      <div className="flex items-center gap-3">
        <div className="hidden md:flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span className="text-slate-300">{healthStatus?.aiProvider || 'gemini-3.8-flash'}</span>
        </div>

        <button
          onClick={onNewProject}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-600/30 transition cursor-pointer"
        >
          <Plus size={14} />
          <span>New Specification</span>
        </button>
      </div>
    </header>
  );
};
