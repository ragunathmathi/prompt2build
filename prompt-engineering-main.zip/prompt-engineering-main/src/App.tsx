/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Project, FullBlueprint, Requirement, ValidationFinding, CoverageMetrics, ChangeImpactReport } from './types/blueprint';
import { StorageService } from './services/storageService';
import { TraceSpecEngine } from './services/tracespecEngine';
import { SAMPLE_PROJECT_ATTENDANCE } from './services/sampleProjects';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardOverview } from './components/dashboard/DashboardOverview';
import { RequirementDiscoveryView } from './components/discovery/RequirementDiscoveryView';
import { RequirementsEditorView } from './components/editor/RequirementsEditorView';
import { ArchitectureDesigner } from './components/architecture/ArchitectureDesigner';
import { DatabaseBlueprintView } from './components/database/DatabaseBlueprintView';
import { ApiBlueprintView } from './components/api/ApiBlueprintView';
import { TestCaseManagerView } from './components/testing/TestCaseManagerView';
import { TraceGraphViewer } from './components/tracespec/TraceGraphViewer';
import { TraceMatrixTable } from './components/tracespec/TraceMatrixTable';
import { ChangeImpactModal } from './components/impact/ChangeImpactModal';
import { ValidationFindingsView } from './components/validation/ValidationFindingsView';
import { VersionTimelineView } from './components/versioning/VersionTimelineView';
import { ExportCenterView } from './components/export/ExportCenterView';
import { ResearchEvaluationView } from './components/evaluation/ResearchEvaluationView';
import { SettingsView } from './components/settings/SettingsView';
import { Plus, X, Sparkles, AlertCircle } from 'lucide-react';

export default function App() {
  const [projects, setProjects] = useState<Project[]>(() => StorageService.getProjects());
  const [activeProjectId, setActiveProjectId] = useState<string>(() => StorageService.getActiveProjectId());
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedTraceNodeId, setSelectedTraceNodeId] = useState<string | null>(null);
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState<boolean>(false);
  const [newProjectPrompt, setNewProjectPrompt] = useState<string>('');
  const [newProjectName, setNewProjectName] = useState<string>('');
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [activeEditingReq, setActiveEditingReq] = useState<Requirement | null>(null);

  // Sync active project
  const activeProject: Project = useMemo(() => {
    const found = projects.find(p => p.id === activeProjectId);
    return found || projects[0] || SAMPLE_PROJECT_ATTENDANCE;
  }, [projects, activeProjectId]);

  const activeBlueprint: FullBlueprint = useMemo(() => {
    return activeProject.blueprint || SAMPLE_PROJECT_ATTENDANCE.blueprint!;
  }, [activeProject]);

  // Compute TraceSpec graph, validation findings, and coverage metrics
  const { graph, findings, metrics } = useMemo(() => {
    const g = TraceSpecEngine.buildGraph(activeBlueprint);
    const f = TraceSpecEngine.validateBlueprint(activeBlueprint, g);
    const m = TraceSpecEngine.computeCoverage(activeBlueprint, g);
    return { graph: g, findings: f, metrics: m };
  }, [activeBlueprint]);

  const handleSelectProject = (id: string) => {
    setActiveProjectId(id);
    StorageService.setActiveProjectId(id);
    setSelectedTraceNodeId(null);
  };

  const handleSaveBlueprint = (updatedBp: FullBlueprint) => {
    const updatedProj: Project = {
      ...activeProject,
      blueprint: updatedBp,
      updatedAt: new Date().toISOString()
    };
    StorageService.saveProject(updatedProj);
    setProjects(StorageService.getProjects());
  };

  const handleUpdateRequirement = (updatedReq: Requirement) => {
    const updatedProj = StorageService.updateRequirement(activeProject.id, updatedReq);
    if (updatedProj) {
      setProjects(StorageService.getProjects());
    }
  };

  const handleApplyChangeImpact = (updatedReq: Requirement, report: ChangeImpactReport) => {
    // Commit requirement mutation and mark affected artifacts as review needed
    if (!activeProject.blueprint) return;

    const bp = JSON.parse(JSON.stringify(activeProject.blueprint)) as FullBlueprint;
    const idx = bp.requirements.findIndex(r => r.id === updatedReq.id);
    if (idx >= 0) {
      bp.requirements[idx] = updatedReq;
    }

    // Mark test cases suggested for regression
    report.suggestedRegressionTests.forEach(testId => {
      const tIdx = bp.testCases.findIndex(t => t.id === testId);
      if (tIdx >= 0) {
        bp.testCases[tIdx].executionStatus = 'unexecuted';
      }
    });

    bp.updatedAt = new Date().toISOString();
    handleSaveBlueprint(bp);
  };

  const handleCreateNewProject = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!newProjectName.trim()) return;

    const id = `proj-${Date.now()}`;
    const newProj: Project = {
      id,
      name: newProjectName.trim(),
      description: newProjectPrompt.trim() || newProjectName.trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: 'draft',
      currentVersion: 'v1.0',
      tags: ['Custom'],
      blueprint: {
        ...SAMPLE_PROJECT_ATTENDANCE.blueprint!,
        id: `bp-${Date.now()}`,
        projectId: id,
        version: '1.0',
        overview: {
          ...SAMPLE_PROJECT_ATTENDANCE.blueprint!.overview,
          title: newProjectName.trim(),
          description: newProjectPrompt.trim() || newProjectName.trim()
        }
      }
    };

    StorageService.saveProject(newProj);
    const list = StorageService.getProjects();
    setProjects(list);
    setActiveProjectId(id);
    StorageService.setActiveProjectId(id);
    setIsNewProjectModalOpen(false);
    setNewProjectName('');
    setNewProjectPrompt('');
    setActiveTab('discovery');
  };

  const handleSelectReqForTrace = (reqId: string) => {
    setSelectedTraceNodeId(reqId);
    setActiveTab('graph');
  };

  const handleRevalidate = () => {
    setIsValidating(true);
    setTimeout(() => {
      setIsValidating(false);
    }, 400);
  };

  const unresolvedDefects = findings.filter(f => f.severity === 'critical' || f.severity === 'error').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased">
      {/* Top Navbar */}
      <Navbar
        projects={projects}
        activeProject={activeProject}
        onSelectProject={handleSelectProject}
        onNewProject={() => setIsNewProjectModalOpen(true)}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          unresolvedCount={unresolvedDefects}
        />

        {/* Content Body */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-slate-950">
          {activeTab === 'dashboard' && (
            <DashboardOverview
              project={activeProject}
              blueprint={activeBlueprint}
              metrics={metrics}
              onNavigateTab={setActiveTab}
            />
          )}

          {activeTab === 'discovery' && (
            <RequirementDiscoveryView
              activeProject={activeProject}
              onBlueprintGenerated={newProj => {
                StorageService.saveProject(newProj);
                setProjects(StorageService.getProjects());
                setActiveProjectId(newProj.id);
                StorageService.setActiveProjectId(newProj.id);
                setActiveTab('dashboard');
              }}
            />
          )}

          {activeTab === 'requirements' && (
            <RequirementsEditorView
              blueprint={activeBlueprint}
              onUpdateRequirement={handleUpdateRequirement}
              onSelectRequirementForTrace={handleSelectReqForTrace}
            />
          )}

          {activeTab === 'architecture' && (
            <ArchitectureDesigner
              architecture={activeBlueprint.architecture}
              onUpdateArchitecture={arch => {
                handleSaveBlueprint({
                  ...activeBlueprint,
                  architecture: arch
                });
              }}
            />
          )}

          {activeTab === 'database' && (
            <DatabaseBlueprintView
              database={activeBlueprint.database}
              onUpdateDatabase={db => {
                handleSaveBlueprint({
                  ...activeBlueprint,
                  database: db
                });
              }}
            />
          )}

          {activeTab === 'api' && (
            <ApiBlueprintView
              blueprint={activeBlueprint}
              onUpdateEndpoints={apis => {
                handleSaveBlueprint({
                  ...activeBlueprint,
                  apiEndpoints: apis
                });
              }}
            />
          )}

          {activeTab === 'testing' && (
            <TestCaseManagerView blueprint={activeBlueprint} />
          )}

          {activeTab === 'graph' && (
            <div className="h-[calc(100vh-140px)] flex flex-col gap-3">
              <div className="flex items-center justify-between px-1">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>TraceSpec Engine: End-to-End Requirement Traceability Graph</span>
                    <span className="text-xs px-2 py-0.5 rounded bg-blue-950 text-blue-300 font-mono border border-blue-800">
                      Persistent Graph
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Interactive multi-layer graph tracking REQ &rarr; US &rarr; ARCH &rarr; DB &rarr; API &rarr; TEST relationships.
                  </p>
                </div>
              </div>
              <div className="flex-1">
                <TraceGraphViewer
                  graph={graph}
                  selectedNodeId={selectedTraceNodeId}
                  onSelectNode={n => setSelectedTraceNodeId(n ? n.id : null)}
                />
              </div>
            </div>
          )}

          {activeTab === 'matrix' && (
            <div className="h-[calc(100vh-140px)] flex flex-col gap-3">
              <div>
                <h3 className="text-base font-bold text-white">2D Requirement Traceability Matrix (RTM)</h3>
                <p className="text-xs text-slate-400">
                  Calculated directly from stored graph edges to isolate untested and orphaned requirements.
                </p>
              </div>
              <div className="flex-1">
                <TraceMatrixTable
                  blueprint={activeBlueprint}
                  onSelectRequirement={handleSelectReqForTrace}
                />
              </div>
            </div>
          )}

          {activeTab === 'impact' && (
            <div className="flex flex-col gap-6">
              <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">Requirement Change Impact Analysis (Blast Radius)</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Select any requirement below to edit its specification, compute forward and indirect blast radius,
                    and review proposed regression test suites before committing changes.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {activeBlueprint.requirements.map(req => (
                  <div
                    key={req.id}
                    className="p-5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between gap-3 hover:border-slate-700 transition"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-xs font-bold text-blue-400">{req.id}</span>
                        <span className="text-[10px] text-slate-500 font-mono">v{req.version}</span>
                      </div>
                      <h4 className="text-xs font-bold text-white">{req.title}</h4>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-2">{req.description}</p>
                    </div>

                    <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                      <span className="text-[11px] text-slate-500 font-medium">{req.category}</span>
                      <button
                        onClick={() => setActiveEditingReq(req)}
                        className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition shadow-sm cursor-pointer"
                      >
                        Analyze Change Impact
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {activeEditingReq && (
                <ChangeImpactModal
                  blueprint={activeBlueprint}
                  initialReq={activeEditingReq}
                  isOpen={!!activeEditingReq}
                  onClose={() => setActiveEditingReq(null)}
                  onApplyChanges={(updatedReq, report) => {
                    handleApplyChangeImpact(updatedReq, report);
                    setActiveEditingReq(null);
                  }}
                />
              )}
            </div>
          )}

          {activeTab === 'validation' && (
            <ValidationFindingsView
              findings={findings}
              metrics={metrics}
              onRevalidate={handleRevalidate}
              isValidating={isValidating}
            />
          )}

          {activeTab === 'versioning' && (
            <VersionTimelineView
              project={activeProject}
              onSnapshotCreated={proj => {
                setProjects(StorageService.getProjects());
              }}
              onVersionRestored={proj => {
                setProjects(StorageService.getProjects());
                setActiveProjectId(proj.id);
              }}
            />
          )}

          {activeTab === 'export' && (
            <ExportCenterView
              blueprint={activeBlueprint}
              findings={findings}
              metrics={metrics}
            />
          )}

          {activeTab === 'evaluation' && (
            <ResearchEvaluationView />
          )}

          {activeTab === 'settings' && (
            <SettingsView />
          )}
        </main>
      </div>

      {/* New Project Modal */}
      {isNewProjectModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl p-6 flex flex-col gap-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles size={18} className="text-blue-400" />
                <h3 className="text-base font-bold text-white">Initialize New Specification Project</h3>
              </div>
              <button
                onClick={() => setIsNewProjectModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleCreateNewProject} className="flex flex-col gap-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1">
                  Project Title
                </label>
                <input
                  type="text"
                  required
                  value={newProjectName}
                  onChange={e => setNewProjectName(e.target.value)}
                  placeholder="e.g. Campus Placement & Internship Portal"
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-1">
                  Natural Language Vision / Problem Statement
                </label>
                <textarea
                  rows={4}
                  value={newProjectPrompt}
                  onChange={e => setNewProjectPrompt(e.target.value)}
                  placeholder="Describe your software concept in natural language..."
                  className="w-full px-3 py-2 rounded-lg bg-slate-950 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500 leading-relaxed font-sans"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewProjectModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-700 text-xs text-slate-300 hover:bg-slate-800 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!newProjectName.trim()}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold shadow-md shadow-blue-600/30 transition"
                >
                  <Plus size={14} />
                  <span>Create Workspace</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
