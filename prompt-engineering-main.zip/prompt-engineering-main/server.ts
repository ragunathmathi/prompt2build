/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import { TraceSpecEngine } from './src/services/tracespecEngine.ts';
import { SAMPLE_PROJECT_ATTENDANCE } from './src/services/sampleProjects.ts';
import { BENCHMARK_DATASETS } from './src/services/evaluationService.ts';
import { FullBlueprint, Requirement } from './src/types/blueprint.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side Gemini initialization
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health & Config endpoint
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'online',
    hasApiKey: !!apiKey,
    aiProvider: apiKey ? 'gemini-3.8-flash' : 'deterministic-demo-engine',
    timestamp: new Date().toISOString()
  });
});

// Smart Requirement Discovery endpoint
app.post('/api/generate/discovery', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt || typeof prompt !== 'string') {
      return res.status(400).json({ error: 'Prompt is required.' });
    }

    // If Gemini is available, call gemini-3.8-flash with structured output
    if (aiClient) {
      try {
        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `Analyze the following natural language software idea and generate:
1. Formal Project Title
2. Extracted Scope Summary
3. 3 to 4 targeted clarification questions covering stakeholder roles, authentication/authorization, data persistence, and key business rules.

User software idea:
"${prompt}"`,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                projectTitle: { type: Type.STRING },
                scopeSummary: { type: Type.STRING },
                detectedRoles: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                },
                clarificationQuestions: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      category: { type: Type.STRING },
                      question: { type: Type.STRING },
                      options: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                      },
                      assumedDefault: { type: Type.STRING },
                      explanation: { type: Type.STRING }
                    },
                    required: ['id', 'category', 'question', 'options', 'assumedDefault', 'explanation']
                  }
                }
              },
              required: ['projectTitle', 'scopeSummary', 'detectedRoles', 'clarificationQuestions']
            }
          }
        });

        if (response.text) {
          const parsed = JSON.parse(response.text.trim());
          return res.json({
            success: true,
            source: 'gemini-3.8-flash',
            data: parsed
          });
        }
      } catch (geminiError: any) {
        console.warn('Gemini API call failed, falling back to deterministic discovery:', geminiError?.message || geminiError);
      }
    }

    // Deterministic fallback / Demo discovery
    const isAttendance = prompt.toLowerCase().includes('attend') || prompt.toLowerCase().includes('college') || prompt.toLowerCase().includes('school');
    const isEcommerce = prompt.toLowerCase().includes('shop') || prompt.toLowerCase().includes('order') || prompt.toLowerCase().includes('cart');

    let title = 'Custom Software Platform';
    let scopeSummary = `Formal software specification generated from natural language: "${prompt}"`;
    let detectedRoles = ['Administrator', 'Standard User', 'Auditor'];
    let clarificationQuestions = [
      {
        id: 'CLAR-01',
        category: 'role',
        question: 'What level of role-based access control (RBAC) is required?',
        options: ['Single Admin + Standard Users', 'Multi-tier Hierarchical Roles (Admin, Manager, User, Guest)', 'Self-service Public Access with Owner Isolation'],
        assumedDefault: 'Multi-tier Hierarchical Roles (Admin, Manager, User, Guest)',
        explanation: 'Enforces separation of duties and access permissions.'
      },
      {
        id: 'CLAR-02',
        category: 'auth',
        question: 'Which authentication standard should be implemented?',
        options: ['Email & Password with JWT Tokens', 'OAuth 2.0 / SSO (Google Workspace, SAML)', 'Passwordless Magic Link + TOTP Multi-factor'],
        assumedDefault: 'Email & Password with JWT Tokens',
        explanation: 'Provides fast initial development with secure cryptographic verification.'
      },
      {
        id: 'CLAR-03',
        category: 'data_ownership',
        question: 'What is the data retention and audit requirement?',
        options: ['Full Immutable Audit Log for all state modifications', 'Soft-deletes only without audit logging', 'Standard CRUD with immediate hard deletes'],
        assumedDefault: 'Full Immutable Audit Log for all state modifications',
        explanation: 'Essential for requirement traceability and compliance verification.'
      }
    ];

    if (isAttendance) {
      title = 'College Attendance Management System';
      scopeSummary = 'Automated attendance tracking system for faculty roll-call, real-time student percentage calculation, 75% threshold alerting, and leave requests.';
      detectedRoles = ['Faculty Instructor', 'Student', 'Academic Advisor', 'Department Head'];
      clarificationQuestions = SAMPLE_PROJECT_ATTENDANCE.clarifications || clarificationQuestions;
    } else if (isEcommerce) {
      title = 'E-Commerce Order Fulfillment & Inventory System';
      scopeSummary = 'High-concurrency order placement, inventory reservation locks, payment gateway webhook verification, and shipment carrier integration.';
      detectedRoles = ['Customer', 'Warehouse Dispatcher', 'Inventory Manager', 'Platform Admin'];
      clarificationQuestions = [
        {
          id: 'CLAR-01',
          category: 'business_rule',
          question: 'How should inventory stock reservation be handled during checkout?',
          options: ['Lock stock atomically for 15 minutes during payment', 'Deduct stock only after webhook payment confirmation', 'Allow backorders if out of stock'],
          assumedDefault: 'Lock stock atomically for 15 minutes during payment',
          explanation: 'Prevents race-condition overselling during peak traffic.'
        },
        {
          id: 'CLAR-02',
          category: 'auth',
          question: 'What authentication flow should customer accounts follow?',
          options: ['OAuth 2.0 (Google/Apple) + Email Password with JWT', 'Guest checkout with email verification code', 'Enterprise SSO'],
          assumedDefault: 'OAuth 2.0 (Google/Apple) + Email Password with JWT',
          explanation: 'Standard e-commerce user convenience.'
        }
      ];
    }

    return res.json({
      success: true,
      source: 'deterministic-engine',
      data: {
        projectTitle: title,
        scopeSummary,
        detectedRoles,
        clarificationQuestions
      }
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Discovery analysis failed.' });
  }
});

// Full Specification Generation endpoint
app.post('/api/generate/blueprint', async (req, res) => {
  try {
    const { projectId, projectTitle, prompt, clarifications } = req.body;

    if (aiClient) {
      try {
        const promptText = `You are an elite Software Architect and Specification Engineer.
Generate a complete, production-grade, highly structured software blueprint for:
Project Title: ${projectTitle || 'Software Project'}
Original Prompt: "${prompt}"
Clarification Responses: ${JSON.stringify(clarifications || [])}

You MUST generate:
1. Overview with scope, target audience, assumptions.
2. User roles matrix with permissions.
3. 8-12 Atomic Requirements with IDs (REQ-001, REQ-002, etc.), types (functional, non-functional, security), priority (critical, high, medium), and source.
4. User Stories (US-001...) with role, action, benefit, acceptance criteria, and relatedReqIds.
5. System Modules (MOD-01...).
6. Architecture components (ARCH-001...) with layers, dependencies, and valid Mermaid flowchart diagram.
7. Database entities (DB-001...) with tables, columns, types, primary keys, foreign keys (referencing table and field), constraints, SQL DDL, and ER Mermaid diagram.
8. REST API endpoints (API-001...) with method, path, auth requirement, allowed roles, parameters, request body schema, status codes, and relatedReqIds/relatedDbEntityIds.
9. Verification Test Cases (TEST-001...) with preconditions, steps, expected results, priority, and relatedReqIds/relatedApiIds.
10. Implementation Tasks (TASK-001...) with developer prompt instructions.
11. Security Requirements (SEC-001...).

CRITICAL: Every technical artifact (Component, DB entity, API endpoint, Test case) MUST include explicit 'relatedReqIds' referencing valid REQ-xxx IDs.`;

        const response = await aiClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: promptText,
          config: {
            responseMimeType: 'application/json',
          }
        });

        if (response.text) {
          const generated = JSON.parse(response.text.trim());
          const fullBlueprint: FullBlueprint = {
            id: `bp-${Date.now()}`,
            projectId: projectId || `proj-${Date.now()}`,
            version: '1.0',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            overview: generated.overview || {
              title: projectTitle || 'Generated Blueprint',
              description: prompt,
              scope: 'Full-stack software application specification.',
              targetAudience: ['Users', 'Administrators'],
              keyAssumptions: ['Standard cloud deployment.']
            },
            rolesMatrix: generated.rolesMatrix || [
              { role: 'Administrator', description: 'System Admin', permissions: ['*'] },
              { role: 'User', description: 'Standard User', permissions: ['read:own', 'write:own'] }
            ],
            requirements: generated.requirements || [],
            userStories: generated.userStories || [],
            businessRules: generated.businessRules || [],
            systemModules: generated.systemModules || [],
            architecture: generated.architecture || {
              summary: 'Modern 3-tier architecture.',
              style: 'Modular Micro-services',
              mermaidCode: 'flowchart TD\n  Client[Frontend SPA] --> Gateway[API Gateway]\n  Gateway --> DB[(PostgreSQL)]',
              components: [],
              dataFlow: []
            },
            database: generated.database || {
              entities: [],
              relationships: [],
              sqlDdl: '-- DDL generated',
              erdMermaid: 'erDiagram'
            },
            apiEndpoints: generated.apiEndpoints || [],
            testCases: generated.testCases || [],
            implementationTasks: generated.implementationTasks || [],
            securityRequirements: generated.securityRequirements || []
          };

          return res.json({
            success: true,
            source: 'gemini-3.8-flash',
            blueprint: fullBlueprint
          });
        }
      } catch (geminiError: any) {
        console.warn('Gemini blueprint generation failed, using deterministic generation:', geminiError?.message || geminiError);
      }
    }

    // Deterministic High-Fidelity Blueprint Fallback
    const baseBlueprint = JSON.parse(JSON.stringify(SAMPLE_PROJECT_ATTENDANCE.blueprint));
    baseBlueprint.id = `bp-${Date.now()}`;
    baseBlueprint.projectId = projectId || `proj-${Date.now()}`;
    baseBlueprint.version = '1.0';
    baseBlueprint.createdAt = new Date().toISOString();
    baseBlueprint.updatedAt = new Date().toISOString();

    if (projectTitle && !projectTitle.toLowerCase().includes('attendance')) {
      baseBlueprint.overview.title = projectTitle;
      baseBlueprint.overview.description = prompt;
    }

    res.json({
      success: true,
      source: 'deterministic-engine',
      blueprint: baseBlueprint
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Blueprint generation failed.' });
  }
});

// TraceSpec Engine Validation API
app.post('/api/tracespec/validate', (req, res) => {
  try {
    const { blueprint } = req.body;
    if (!blueprint) {
      return res.status(400).json({ error: 'Blueprint is required.' });
    }

    const graph = TraceSpecEngine.buildGraph(blueprint);
    const findings = TraceSpecEngine.validateBlueprint(blueprint, graph);
    const metrics = TraceSpecEngine.computeCoverage(blueprint, graph);

    res.json({
      success: true,
      graph,
      findings,
      metrics
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Validation failed.' });
  }
});

// Change Impact Analysis API
app.post('/api/tracespec/impact', (req, res) => {
  try {
    const { blueprint, previousReq, newReq } = req.body;
    if (!blueprint || !previousReq || !newReq) {
      return res.status(400).json({ error: 'blueprint, previousReq, and newReq are required.' });
    }

    const report = TraceSpecEngine.analyzeChangeImpact(blueprint, previousReq, newReq);
    res.json({
      success: true,
      report
    });
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Change impact analysis failed.' });
  }
});

// Evaluation Benchmarks API
app.get('/api/evaluation/benchmarks', (_req, res) => {
  res.json({
    success: true,
    benchmarks: BENCHMARK_DATASETS
  });
});

// In development, hook up Vite middleware; in production serve dist
if (process.env.NODE_ENV !== 'production') {
  const { createServer } = await import('vite');
  const vite = await createServer({
    server: { middlewareMode: true },
    appType: 'custom',
  });
  app.use(vite.middlewares);
  app.get('*', async (req, res, next) => {
    if (req.originalUrl.startsWith('/api')) {
      return next();
    }
    try {
      const url = req.originalUrl;
      const indexPath = path.resolve(__dirname, 'index.html');
      let template = fs.readFileSync(indexPath, 'utf-8');
      template = await vite.transformIndexHtml(url, template);
      res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
    } catch (e) {
      next(e);
    }
  });
} else {
  app.use(express.static(path.join(__dirname, 'dist')));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
  });
}

app.listen(Number(PORT), '0.0.0.0', () => {
  console.log(`Prompt2Blueprint Full-Stack Server running on port ${PORT}`);
});
